"""ioBroker Adapter."""
