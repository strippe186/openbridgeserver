"""Home Assistant Adapter."""
