"""History API — Phase 5

GET /api/v1/history/{id}?from=&to=&limit=
GET /api/v1/history/{id}/aggregate?fn=avg&interval=1h&from=&to=
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime, timedelta
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from fastapi.security import APIKeyHeader, HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel

from obs.api.auth import Principal, get_current_principal
from obs.api.authz import AuthzAction
from obs.api.authz_service import filter_authorized_datapoints
from obs.api.v1.datapoints import _has_explicit_datapoint_read_deny, _page_context_allows_datapoint_read
from obs.api.v1.sessions import validate_session
from obs.core.registry import get_registry
from obs.db.database import Database, get_db
from obs.history.factory import get_history_plugin

router = APIRouter(tags=["history"])
DEFAULT_HISTORY_WINDOW_HOURS = 24 * 7
MIN_HISTORY_WINDOW_HOURS = 1
MAX_HISTORY_WINDOW_HOURS = 24 * 365
_history_bearer = HTTPBearer(auto_error=False)
_history_api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)


# ---------------------------------------------------------------------------
# Response models
# ---------------------------------------------------------------------------


class HistoryPoint(BaseModel):
    ts: str
    v: Any
    u: str | None
    q: str
    a: str | None = None  # source_adapter


class AggregatedPoint(BaseModel):
    bucket: str
    v: Any
    n: int | None = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _parse_ts(s: str | None, default: datetime) -> datetime:
    if not s:
        return default
    try:
        return datetime.fromisoformat(s)
    except ValueError:
        raise HTTPException(
            status.HTTP_422_UNPROCESSABLE_CONTENT,
            f"Invalid timestamp: {s!r}",
        )


def _format_utc_bucket(bucket: Any) -> str:
    """Return aggregate bucket timestamps as UTC ISO strings matching raw history."""
    if isinstance(bucket, datetime):
        dt = bucket
    else:
        try:
            dt = datetime.fromisoformat(str(bucket))
        except ValueError:
            return str(bucket)

    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    else:
        dt = dt.astimezone(UTC)
    return dt.isoformat().replace("+00:00", "Z")


async def _get_default_history_window_hours(db: Database) -> int:
    """Read configurable default window from app_settings."""
    row = await db.fetchone("SELECT value FROM app_settings WHERE key = 'history.default_window_hours'")
    if not row or row["value"] is None:
        return DEFAULT_HISTORY_WINDOW_HOURS
    try:
        hours = int(row["value"])
    except (TypeError, ValueError):
        return DEFAULT_HISTORY_WINDOW_HOURS
    return max(MIN_HISTORY_WINDOW_HOURS, min(hours, MAX_HISTORY_WINDOW_HOURS))


async def _optional_history_principal(
    credentials: HTTPAuthorizationCredentials | None = Depends(_history_bearer),
    api_key: str | None = Depends(_history_api_key_header),
    db: Database = Depends(get_db),
) -> Principal | None:
    if credentials is None and api_key is None:
        return None
    try:
        return await get_current_principal(credentials=credentials, api_key=api_key, db=db)
    except HTTPException:
        return None


async def _resolve_page_access_with_node(db: Database, node_id: str) -> tuple[str, str | None]:
    """Return the effective access level and the node that defines it."""
    current_id: str | None = node_id
    while current_id:
        row = await db.fetchone(
            """SELECT vn.parent_id, avp.access_mode
               FROM visu_nodes AS vn
               LEFT JOIN authz_visu_page_policies AS avp ON avp.node_id = vn.id
               WHERE vn.id = ?""",
            (current_id,),
        )
        if not row:
            return "private", None
        if row["access_mode"] is not None:
            return row["access_mode"], current_id
        current_id = row["parent_id"]
    return "public", None


async def _resolve_page_access(db: Database, node_id: str) -> str:
    """Traversiert die parent_id-Kette und gibt das effektive Access-Level zurück."""
    access, _ = await _resolve_page_access_with_node(db, node_id)
    return access


async def _check_history_access(
    request: Request,
    user: str | None,
    db: Database,
) -> None:
    """JWT oder gültiger Session-Token (protected/public Seite) erlaubt History-Zugriff."""
    if user is not None:
        return  # JWT vorhanden → immer erlaubt

    page_id = request.headers.get("X-Page-Id")
    if not page_id:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, detail="Authentication required")

    access, defining_node_id = await _resolve_page_access_with_node(db, page_id)

    if access in ("public", "readonly"):
        return  # Öffentliche Seite → History-Lesen erlaubt
    if access == "protected":
        session_token = request.headers.get("X-Session-Token")
        validate_id = defining_node_id or page_id
        if session_token and validate_session(session_token, validate_id):
            return
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, detail="Valid session token required")
    # private oder unbekannt
    raise HTTPException(status.HTTP_401_UNAUTHORIZED, detail="Authentication required")


async def _check_datapoint_read_access(
    db: Database,
    principal: Principal | None,
    dp_id: uuid.UUID,
    request: Request,
) -> None:
    if principal is None:
        if await _page_context_allows_datapoint_read(db, request, dp_id, None):
            return
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"DataPoint {dp_id} not found")

    allowed = await filter_authorized_datapoints(
        db,
        principal,
        [str(dp_id)],
        action=AuthzAction.READ,
    )
    if str(dp_id) in allowed:
        return
    if await _has_explicit_datapoint_read_deny(db, principal, dp_id):
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"DataPoint {dp_id} not found")
    if await _page_context_allows_datapoint_read(db, request, dp_id, principal):
        return
    raise HTTPException(status.HTTP_404_NOT_FOUND, f"DataPoint {dp_id} not found")


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@router.get("/{dp_id}", response_model=list[HistoryPoint])
async def query_history(
    dp_id: uuid.UUID,
    from_ts: str | None = Query(None, alias="from"),
    to_ts: str | None = Query(None, alias="to"),
    limit: int = Query(10000, ge=1, le=100000),
    request: Request = None,
    principal: Principal | None = Depends(_optional_history_principal),
    db: Database = Depends(get_db),
) -> list[HistoryPoint]:
    await _check_history_access(request, principal.subject if principal else None, db)
    if get_registry().get(dp_id) is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"DataPoint {dp_id} not found")
    await _check_datapoint_read_access(db, principal, dp_id, request)

    now = datetime.now(UTC)
    window_hours = await _get_default_history_window_hours(db)
    from_dt = _parse_ts(from_ts, now - timedelta(hours=window_hours))
    to_dt = _parse_ts(to_ts, now)

    plugin = get_history_plugin()
    rows = await plugin.query(dp_id, from_dt, to_dt, limit)
    return [HistoryPoint(**r) for r in rows]


@router.get("/{dp_id}/aggregate", response_model=list[AggregatedPoint])
async def aggregate_history(
    dp_id: uuid.UUID,
    fn: str = Query("avg", description="avg | min | max | last"),
    interval: str = Query("1h", description="1m | 5m | 15m | 30m | 1h | 6h | 12h | 1d"),
    from_ts: str | None = Query(None, alias="from"),
    to_ts: str | None = Query(None, alias="to"),
    request: Request = None,
    principal: Principal | None = Depends(_optional_history_principal),
    db: Database = Depends(get_db),
) -> list[AggregatedPoint]:
    await _check_history_access(request, principal.subject if principal else None, db)
    if get_registry().get(dp_id) is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"DataPoint {dp_id} not found")
    await _check_datapoint_read_access(db, principal, dp_id, request)
    if fn not in ("avg", "min", "max", "last"):
        raise HTTPException(
            status.HTTP_422_UNPROCESSABLE_CONTENT,
            "fn must be one of: avg, min, max, last",
        )

    now = datetime.now(UTC)
    window_hours = await _get_default_history_window_hours(db)
    from_dt = _parse_ts(from_ts, now - timedelta(hours=window_hours))
    to_dt = _parse_ts(to_ts, now)

    plugin = get_history_plugin()
    rows = await plugin.aggregate(dp_id, fn, interval, from_dt, to_dt)
    return [AggregatedPoint(bucket=_format_utc_bucket(r.get("bucket")), v=r.get("v"), n=r.get("n")) for r in rows]
