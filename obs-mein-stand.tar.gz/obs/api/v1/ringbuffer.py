"""RingBuffer API.

Filterset schema (#431):
    Filtersets are flat — one filter criteria per set. Multiple sets can be active
    in the topbar simultaneously; the multi-query endpoint OR-unions their hits
    and annotates each entry with the IDs of the sets it matched.

The DB column is named ``filter_json`` (a serialized :class:`FilterCriteria`),
explicitly distinct from the legacy ``query_json`` column which previously stored
a complete :class:`RingBufferQueryV2` (filters + sort + pagination). Renaming
makes the semantic shift unambiguous: a filterset now stores filter *criteria*,
while sort and pagination remain owned by the caller of the query endpoint.
"""

from __future__ import annotations

import asyncio
import csv
import json
import logging
import re
import shutil
import tempfile
import time
import uuid
from contextlib import suppress
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Literal

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query, Request, status
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator

from obs.api.audit import audit_payload_sha256
from obs.api.auth import Principal, get_admin_user, get_current_principal, get_current_user
from obs.api.authz import AuthzAction, AuthzTarget, RoleGrant, authorize
from obs.api.authz_service import filter_authorized_datapoints, load_role_grants
from obs.api.v1.application_audit import audit_application_contract, write_application_success
from obs.api.v1.services.knx_traceability import resolve_device_pas_to_group_addresses
from obs.db.database import Database, get_db
from obs.ringbuffer.persisted_config import (
    LEGACY_DECISION_DISCARDED,
    LEGACY_DECISION_KEEP,
    LEGACY_DECISION_MIGRATED,
    LEGACY_DECISION_PENDING,
    LEGACY_DECISION_SKIPPED,
    LEGACY_DECISIONS_PROTECTED,
    LEGACY_DECISIONS_TERMINAL,
    ensure_legacy_migration_decision,
    finalize_committed_migration_decision,
    load_legacy_migration_decision,
    load_persisted_ringbuffer_config,
    persist_legacy_migration_decision,
    persist_ringbuffer_config,
    repair_pending_keep_migration_decision,
)
from obs.ringbuffer.ringbuffer import (
    RingBufferStorageDeleteIncompleteError,
    RowLazyExportCursor,
    _is_sqlite_memory_path,
    default_ringbuffer_disk_path,
    delete_ringbuffer_storage_files,
    derive_segment_max_age,
    derive_segment_max_bytes,
    derive_segment_max_rows,
    get_optional_ringbuffer,
    get_ringbuffer,
    init_ringbuffer,
    is_ringbuffer_enabled,
    reset_ringbuffer,
    set_ringbuffer_enabled,
)
from obs.ringbuffer.store.config import (
    SEGMENT_MAX_AGE_MIN,
    SegmentConfig,
    StoreRetentionConfig,
    validate_explicit_segment_bounds,
    validate_store_config,
)

logger = logging.getLogger(__name__)

router = APIRouter(tags=["ringbuffer"])

_FILTERSET_QUERY_LIMIT_CAP = 2000
_FILTERSET_QUERY_OFFSET_CAP = 5000
_FILTERSET_MULTI_QUERY_SET_CAP = 50
_FILTERSET_MULTI_QUERY_PER_SET_LIMIT = 2000

_CSV_EXPORT_MAX_ROWS = 100000
_CSV_EXPORT_CHUNK_SIZE = 1000
_CSV_EXPORT_QUERY_TIMEOUT_SECONDS = 3.0
_CSV_EXPORT_TOTAL_TIMEOUT_SECONDS = 20.0
_CSV_EXPORT_SPOOL_MAX_BYTES = 1_000_000
_CSV_EXPORT_HEADERS = (
    "id",
    "ts",
    "datapoint_id",
    "name",
    "topic",
    "old_value_json",
    "new_value_json",
    "source_adapter",
    "quality",
    "metadata_version",
    "metadata_json",
)

_CONFIGURE_LOCK = asyncio.Lock()
# Serialisiert konkurrierende Legacy-Migrations-Entscheidungen (#968, Q0qIM): sonst könnten
# ein ``discard`` und ein ``keep`` aus zwei Admin-Tabs beide den initialen Terminal-Check
# passieren, und der non-terminale keep-Write nach dem bereits durchgelaufenen discard die
# terminale ``discarded``-Entscheidung wieder überschreiben.
_LEGACY_DECISION_LOCK = asyncio.Lock()

_COLOR_RE = re.compile(r"^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$")
_DEFAULT_COLOR = "#3b82f6"


def _ringbuffer_disk_path() -> str:
    from obs.config import get_settings

    return default_ringbuffer_disk_path(get_settings().database.path)


def _subscribe_ringbuffer(rb: Any) -> None:
    from obs.core.event_bus import DataValueEvent, get_event_bus

    try:
        get_event_bus().subscribe(DataValueEvent, rb.handle_value_event)
    except RuntimeError:
        pass


def _unsubscribe_ringbuffer(rb: Any) -> None:
    from obs.core.event_bus import DataValueEvent, get_event_bus

    try:
        get_event_bus().unsubscribe(DataValueEvent, rb.handle_value_event)
    except RuntimeError:
        pass


def _segment_limit_source(configured: int | None, effective: int | None) -> Literal["explicit", "derived", "disabled"]:
    if configured is not None:
        return "explicit"
    if effective is not None:
        return "derived"
    return "disabled"


def _segment_contract_stats(
    *,
    max_entries: int | None,
    max_file_size_bytes: int | None,
    max_age: int | None,
    segment_max_bytes: int | None,
    segment_max_rows: int | None,
    segment_max_age: int | None,
) -> dict[str, Any]:
    effective_segment_max_bytes = segment_max_bytes if segment_max_bytes is not None else derive_segment_max_bytes(max_file_size_bytes)
    effective_segment_max_rows = segment_max_rows if segment_max_rows is not None else derive_segment_max_rows(max_entries)
    effective_segment_max_age = segment_max_age if segment_max_age is not None else derive_segment_max_age(max_age)
    return {
        "effective_segment_max_bytes": effective_segment_max_bytes,
        "effective_segment_max_rows": effective_segment_max_rows,
        "effective_segment_max_age": effective_segment_max_age,
        "segment_max_bytes_source": _segment_limit_source(segment_max_bytes, effective_segment_max_bytes),
        "segment_max_rows_source": _segment_limit_source(segment_max_rows, effective_segment_max_rows),
        "segment_max_age_source": _segment_limit_source(segment_max_age, effective_segment_max_age),
        "retention_unbounded": max_entries is None and max_file_size_bytes is None and max_age is None,
    }


async def _disabled_stats(db: Database) -> RingBufferStats:
    cfg = await load_persisted_ringbuffer_config(db, storage_path=_ringbuffer_disk_path())
    return RingBufferStats(
        enabled=False,
        total=0,
        oldest_ts=None,
        newest_ts=None,
        storage="file",
        max_entries=cfg["max_entries"],
        effective_retention_seconds=None,
        max_file_size_bytes=cfg["max_file_size_bytes"],
        max_age=cfg["max_age"],
        segment_max_bytes=cfg.get("segment_max_bytes"),
        segment_max_rows=cfg.get("segment_max_rows"),
        segment_max_age=cfg.get("segment_max_age"),
        file_size_bytes=0,
        **_segment_contract_stats(
            max_entries=cfg["max_entries"],
            max_file_size_bytes=cfg["max_file_size_bytes"],
            max_age=cfg["max_age"],
            segment_max_bytes=cfg.get("segment_max_bytes"),
            segment_max_rows=cfg.get("segment_max_rows"),
            segment_max_age=cfg.get("segment_max_age"),
        ),
    )


def _now_iso() -> str:
    return datetime.now(UTC).isoformat()


def _new_id() -> str:
    return str(uuid.uuid4())


def _principal_from_dependency(value: Principal | str) -> Principal:
    if isinstance(value, Principal):
        return value
    if not isinstance(value, str):
        return Principal(subject="admin", type="user", is_admin=True)
    return Principal(
        subject=value,
        type="api_key" if value.startswith("api_key:") else "user",
        is_admin=value == "admin",
    )


def _is_admin_principal(principal: Principal) -> bool:
    return principal.type == "user" and principal.is_admin


async def _readable_datapoint_ids(db: Database, principal: Principal, datapoint_ids: list[str]) -> list[str]:
    ordered_ids = list(dict.fromkeys(datapoint_ids))
    if not ordered_ids:
        return []
    if _is_admin_principal(principal):
        return ordered_ids
    return await filter_authorized_datapoints(db, principal, ordered_ids, action=AuthzAction.READ)


# ---------------------------------------------------------------------------
# Query models (v2 — used by /query and /export/csv)
# ---------------------------------------------------------------------------


class RingBufferEntryOut(BaseModel):
    id: int
    ts: str
    datapoint_id: str
    name: str | None
    topic: str
    old_value: Any
    new_value: Any
    source_adapter: str
    quality: str
    metadata_version: int
    metadata: dict[str, Any]
    unit: str | None = None


class RingBufferMultiEntryOut(RingBufferEntryOut):
    """Entry plus the list of filterset IDs the entry matched in a multi-query.

    Each entry appears at most once even if it matches multiple sets — the
    ``matched_set_ids`` list captures the OR-union membership.
    """

    matched_set_ids: list[str]


class RingBufferPrognosis(BaseModel):
    """Datengetriebene Wachstums-/Retention-Prognose (#919).

    Bis zum ersten verwertbaren geschlossenen v2-Segment stammt sie aus einer
    vorläufigen, mindestens fünf Sekunden langen Live-Stichprobe des aktiven
    Segments; danach aus den stabileren geschlossenen Segmenten.
    """

    sample_segment_count: int = 0
    source: Literal["active", "closed"] | None = None
    provisional: bool = False
    bytes_per_hour: float | None = None
    rows_per_hour: float | None = None
    avg_segment_seconds: float | None = None
    estimated_retention_seconds: float | None = None
    effective_segment_max_bytes: float | None = None
    observed_seconds: float | None = None
    observed_rows: int | None = None
    ready_after_seconds: float | None = None
    idle_seconds: float | None = None


class RingBufferStats(BaseModel):
    enabled: bool = True
    total: int
    oldest_ts: str | None
    newest_ts: str | None
    storage: str
    max_entries: int | None
    effective_retention_seconds: int | None = None
    max_file_size_bytes: int | None
    max_age: int | None
    file_size_bytes: int
    # Persistierte Segment-Rotations-Config (#919/#938) — damit der Config-Dialog
    # die GESPEICHERTEN Werte hydratisiert (nicht die runtime-abgeleiteten).
    segment_max_bytes: int | None = None
    segment_max_rows: int | None = None
    segment_max_age: int | None = None
    effective_segment_max_bytes: int | None = None
    effective_segment_max_rows: int | None = None
    effective_segment_max_age: int | None = None
    segment_max_bytes_source: Literal["explicit", "derived", "disabled"] = "disabled"
    segment_max_rows_source: Literal["explicit", "derived", "disabled"] = "disabled"
    segment_max_age_source: Literal["explicit", "derived", "disabled"] = "disabled"
    retention_unbounded: bool = False
    last_recovery_at: str | None = None
    last_recovery_file_count: int = 0
    # Segmentierter Store (#919) — nur im segmentierten Modus befüllt (``common``
    # + ``backend_extra`` aus ``store.stats()``); im Legacy-Modus ``None``, damit
    # die bestehende Stats-Form unverändert bleibt.
    store: dict[str, Any] | None = None
    # Datengetriebene Prognose (#919) — nur im segmentierten Modus befüllt.
    prognosis: RingBufferPrognosis | None = None


class RingBufferConfig(BaseModel):
    enabled: bool = True
    storage: str = "file"
    max_entries: int | None = Field(default=None, ge=1)
    max_file_size_bytes: int | None = Field(default=None, ge=1)
    max_age: int | None = Field(default=None, ge=0)
    # Segmentierter Store (#919) – PARTIAL-UPDATE-Feld (Codex #951 [P2]).
    # Der deployte Default ist segmentiert; das GUI zeigt keinen Legacy-Toggle
    # mehr. Das Schema darf daher KEINEN ``false``-Default bewerben – sonst
    # serialisieren generierte Clients / Admin-Skripte beim Aendern UNRELATED
    # Config ein ``segmented:false`` mit und bauen den laufenden Monitor in den
    # Legacy-Single-File-Pfad zurueck (v2-Segment-Historie nicht mehr lesbar).
    # ``None`` (= nicht gesetzt) bedeutet "unveraendert lassen": der Resolver
    # behaelt den persistierten/deployten Wert. Nur ein EXPLIZITES ``true``/``false``
    # schaltet um (bewusster Opt-in/Opt-out). Eine Umschaltung greift beim
    # naechsten RingBuffer-(Neu-)Start bzw. sofort via Modus-Switch-Rebuild.
    segmented: bool | None = None
    # Segment-Parameter (#930) – Rotation, getrennt von den Retention-Feldern
    # oben.
    segment_max_bytes: int | None = Field(default=None, ge=1)
    segment_max_rows: int | None = Field(default=None, ge=1)
    segment_max_age: int | None = Field(default=None, ge=1)


class RingBufferTimeFilterV2(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    from_ts: str | None = Field(default=None, alias="from")
    to_ts: str | None = Field(default=None, alias="to")
    from_relative_seconds: int | None = None
    to_relative_seconds: int | None = None


class RingBufferAdapterFilterV2(BaseModel):
    model_config = ConfigDict(extra="forbid")

    any_of: list[str] = Field(default_factory=list)


class RingBufferDatapointFilterV2(BaseModel):
    model_config = ConfigDict(extra="forbid")

    ids: list[str] = Field(default_factory=list)


class RingBufferValueFilterV2(BaseModel):
    model_config = ConfigDict(extra="forbid")

    operator: Literal["eq", "ne", "gt", "gte", "lt", "lte", "between", "contains", "regex"]
    value: Any | None = None
    lower: Any | None = None
    upper: Any | None = None
    pattern: str | None = None
    ignore_case: bool = False


class RingBufferMetadataFilterV2(BaseModel):
    model_config = ConfigDict(extra="forbid")

    tags_any_of: list[str] = Field(default_factory=list)
    adapter_types_any_of: list[str] = Field(default_factory=list)
    adapter_instance_ids_any_of: list[str] = Field(default_factory=list)
    group_addresses_any_of: list[str] = Field(default_factory=list)
    topics_any_of: list[str] = Field(default_factory=list)
    entity_ids_any_of: list[str] = Field(default_factory=list)
    register_types_any_of: list[str] = Field(default_factory=list)
    register_addresses_any_of: list[str] = Field(default_factory=list)


class RingBufferFiltersV2(BaseModel):
    model_config = ConfigDict(extra="forbid")

    q: str = ""
    time: RingBufferTimeFilterV2 | None = None
    adapters: RingBufferAdapterFilterV2 | None = None
    datapoints: RingBufferDatapointFilterV2 | None = None
    values: list[RingBufferValueFilterV2] | None = None
    metadata: RingBufferMetadataFilterV2 | None = None


class RingBufferSortV2(BaseModel):
    model_config = ConfigDict(extra="forbid")

    field: Literal["id", "ts"] = "id"
    order: Literal["asc", "desc"] = "desc"


class RingBufferPaginationV2(BaseModel):
    model_config = ConfigDict(extra="forbid")

    limit: int = Field(default=100, ge=1, le=10000)
    offset: int = Field(default=0, ge=0)


class RingBufferQueryV2(BaseModel):
    model_config = ConfigDict(extra="forbid")

    filters: RingBufferFiltersV2 = Field(default_factory=RingBufferFiltersV2)
    sort: RingBufferSortV2 = Field(default_factory=RingBufferSortV2)
    pagination: RingBufferPaginationV2 = Field(default_factory=RingBufferPaginationV2)


# ---------------------------------------------------------------------------
# Filterset models — flat schema (#431)
# ---------------------------------------------------------------------------


class NodeRef(BaseModel):
    """Reference to a node in a hierarchy tree (e.g. KNX function/spaces tree).

    ``include_descendants`` decides whether descendant nodes count as matches —
    expansion to concrete datapoint IDs is performed by the consumer.
    """

    model_config = ConfigDict(extra="forbid")

    tree_id: str
    node_id: str
    include_descendants: bool = True


class FilterCriteria(BaseModel):
    """Flat filter criteria for a single filterset (#431).

    Field-internal lists are OR-combined; the criteria as a whole are AND-combined.
    The time filter is *not* part of the criteria — it is supplied at query time
    so the same filterset works across different time windows.
    """

    model_config = ConfigDict(extra="forbid")

    hierarchy_nodes: list[NodeRef] = Field(default_factory=list)
    datapoints: list[str] = Field(default_factory=list)
    devices: list[str] = Field(default_factory=list)
    tags: list[str] = Field(default_factory=list)
    adapters: list[str] = Field(default_factory=list)
    q: str | None = None
    value_filter: RingBufferValueFilterV2 | None = None


def _is_empty_criteria(c: FilterCriteria | None) -> bool:
    """A FilterCriteria with no populated field. Used to skip ad-hoc sets
    that have no filter configured yet — UX feedback (#36): such a set must
    show *nothing* in the table, not *everything*.
    """
    if c is None:
        return True
    if c.hierarchy_nodes or c.datapoints or c.devices or c.tags or c.adapters:
        return False
    if c.q and c.q.strip():
        return False
    return not (c.value_filter and c.value_filter.operator)


def _color_must_be_hex(value: str) -> str:
    if not isinstance(value, str) or not _COLOR_RE.match(value):
        raise ValueError("color must be a hex color like #3b82f6 or #abc")
    return value


class RingBufferFiltersetIn(BaseModel):
    """Input model for POST /filtersets and PUT /filtersets/{id}."""

    model_config = ConfigDict(extra="forbid")

    name: str
    description: str = ""
    dsl_version: int = Field(default=2, ge=1)
    is_active: bool = True
    color: str = _DEFAULT_COLOR
    topbar_active: bool = False
    topbar_order: int = 0
    filter: FilterCriteria = Field(default_factory=FilterCriteria)

    @field_validator("color")
    @classmethod
    def _validate_color(cls, value: str) -> str:
        return _color_must_be_hex(value)


class RingBufferFiltersetUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str | None = None
    description: str | None = None
    dsl_version: int | None = Field(default=None, ge=1)
    is_active: bool | None = None
    color: str | None = None
    topbar_active: bool | None = None
    topbar_order: int | None = None
    filter: FilterCriteria | None = None

    @field_validator("color")
    @classmethod
    def _validate_color(cls, value: str | None) -> str | None:
        if value is None:
            return None
        return _color_must_be_hex(value)


class RingBufferFiltersetCloneRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str | None = None


class RingBufferFiltersetOut(BaseModel):
    id: str
    name: str
    description: str
    dsl_version: int
    is_active: bool
    color: str
    topbar_active: bool
    topbar_order: int
    filter: FilterCriteria
    created_at: str
    updated_at: str
    # Provenance only. Authorization is exclusively derived from central grants.
    created_by: str | None = None
    can_write: bool = False


class RingBufferFiltersetTopbarPatch(BaseModel):
    """Lightweight per-set toggles for the topbar.

    Carries the optional ``is_active`` flag (filter on/off, the dot-button in
    each chip) alongside the topbar-membership and topbar-order. Any of the
    three may be ``None`` to leave the current value untouched.
    """

    model_config = ConfigDict(extra="forbid")

    topbar_active: bool | None = None
    topbar_order: int | None = None
    is_active: bool | None = None


class RingBufferFiltersetOrderItem(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: str
    topbar_order: int


class RingBufferFiltersetOrderPatch(BaseModel):
    model_config = ConfigDict(extra="forbid")

    items: list[RingBufferFiltersetOrderItem] = Field(default_factory=list)


class RingBufferMultiExportRequest(BaseModel):
    """Request body for ``POST /filtersets/export/csv`` (multi-set CSV export).

    Streams the full OR-union of entries matching any of the active filtersets,
    plus an optional time filter, as a delimiter-separated text file. The
    delimiter, quote character and escape character are configurable — the
    defaults follow RFC 4180. The export is independent of UI pagination.
    """

    model_config = ConfigDict(extra="forbid")

    set_ids: list[str] = Field(default_factory=list)
    time: RingBufferTimeFilterV2 | None = None
    # Single-character delimiter (e.g. ',' for CSV, '\t' for TSV, ';' for
    # German Excel). Always exactly one character.
    delimiter: str = Field(default=",", min_length=1, max_length=1)
    # Quote character around fields that contain the delimiter, the quote
    # character itself, or newlines. Default '"' per RFC 4180.
    quote_char: str = Field(default='"', min_length=1, max_length=1)
    # Escape character for the quote character inside a quoted field. Empty
    # string (default) selects RFC 4180 behaviour: the quote char inside a
    # quoted field is doubled. Setting a single character switches the csv
    # writer to backslash-style escaping (doublequote=False).
    escape_char: str = Field(default="", max_length=1)
    encoding: Literal["utf8", "utf8-bom"] = "utf8"
    include_unit: bool = True
    include_matched_set_ids: bool = False


class RingBufferExportSettings(BaseModel):
    """Persisted user defaults for the CSV export dialog (#427)."""

    # `extra="ignore"` so legacy persisted blobs that still carry `format`
    # (csv|tsv) load without raising. The legacy fields are mapped to the
    # new delimiter-based schema in get_ringbuffer_export_settings.
    model_config = ConfigDict(extra="ignore")

    delimiter: str = Field(default=",", min_length=1, max_length=1)
    quote_char: str = Field(default='"', min_length=1, max_length=1)
    escape_char: str = Field(default="", max_length=1)
    encoding: Literal["utf8", "utf8-bom"] = "utf8"
    include_unit: bool = True
    include_matched_set_ids: bool = False


class RingBufferMultiExportCountRequest(BaseModel):
    """Request body for ``POST /filtersets/export/count`` — preflight row count.

    Mirrors the set/time selection of :class:`RingBufferMultiExportRequest` so
    the UI can warn the user before triggering a large download. Format/encoding
    options are intentionally omitted: they do not influence the row count.
    """

    model_config = ConfigDict(extra="forbid")

    set_ids: list[str] = Field(default_factory=list)
    time: RingBufferTimeFilterV2 | None = None


class RingBufferMultiExportCountResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    row_count: int = Field(ge=0)


class RingBufferMultiQueryRequest(BaseModel):
    """Request body for ``POST /filtersets/query`` (multi-set OR-union).

    Behaviour:
        - ``set_ids=[]`` and no ``time`` → returns the most recent entries with
          the default pagination (no filterset filter at all).
        - ``set_ids=[]`` with a ``time`` filter → returns the most recent entries
          inside that time window (still no filterset filter).
        - ``set_ids=[a, b, ...]`` → OR-union of the matching entries across the
          named sets, each entry carrying its ``matched_set_ids``.
        - Unknown / missing set IDs are skipped with a logger warning, never an
          error — the caller may have a stale list after another client deleted
          a set; failing here would break the topbar for everyone.
    """

    model_config = ConfigDict(extra="forbid")

    set_ids: list[str] = Field(default_factory=list)
    time: RingBufferTimeFilterV2 | None = None
    limit: int = Field(default=500, ge=1, le=_FILTERSET_MULTI_QUERY_PER_SET_LIMIT)
    offset: int = Field(default=0, ge=0, le=_FILTERSET_QUERY_OFFSET_CAP)
    sort: RingBufferSortV2 = Field(default_factory=RingBufferSortV2)


# ---------------------------------------------------------------------------
# Filter helpers
# ---------------------------------------------------------------------------


def _decode_filter(raw: str | None) -> FilterCriteria:
    payload: Any = {}
    if raw:
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError:
            payload = {}
    if not isinstance(payload, dict):
        payload = {}
    try:
        return FilterCriteria.model_validate(payload)
    except ValidationError:
        return FilterCriteria()


def _encode_filter(filter_: FilterCriteria) -> str:
    return json.dumps(filter_.model_dump(), separators=(",", ":"))


def _normalize_color(value: str | None) -> str:
    return value if isinstance(value, str) and _COLOR_RE.match(value) else _DEFAULT_COLOR


async def _resolve_hierarchy_to_datapoints(
    hierarchy_nodes: list[NodeRef],
    db: Database,
) -> list[str]:
    """Resolve a list of hierarchy node references to the concrete DataPoint IDs
    linked under them.

    - When ``include_descendants`` is True (default), the entire sub-tree rooted
      at the node is walked via a SQLite recursive CTE and every DP linked to
      *any* node within the sub-tree is returned.
    - When ``include_descendants`` is False, only DPs directly linked to the
      node itself are returned.

    The result is de-duplicated. Unknown / deleted nodes are silently skipped.
    Returns an empty list when ``hierarchy_nodes`` is empty.
    """
    if not hierarchy_nodes:
        return []
    seen: set[str] = set()
    out: list[str] = []
    for node in hierarchy_nodes:
        if node.include_descendants:
            rows = await db.fetchall(
                """WITH RECURSIVE subtree(id) AS (
                       SELECT id FROM hierarchy_nodes WHERE id = ?
                       UNION ALL
                       SELECT hn.id FROM hierarchy_nodes hn
                       JOIN subtree st ON hn.parent_id = st.id
                   )
                   SELECT DISTINCT hdl.datapoint_id AS dp_id
                   FROM hierarchy_datapoint_links hdl
                   WHERE hdl.node_id IN (SELECT id FROM subtree)""",
                (node.node_id,),
            )
        else:
            rows = await db.fetchall(
                "SELECT DISTINCT datapoint_id AS dp_id FROM hierarchy_datapoint_links WHERE node_id = ?",
                (node.node_id,),
            )
        for row in rows:
            dp_id = row["dp_id"]
            if dp_id not in seen:
                seen.add(dp_id)
                out.append(dp_id)
    return out


def _normalize_nonempty(values: list[str]) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for value in values:
        token = value.strip()
        if not token or token in seen:
            continue
        seen.add(token)
        out.append(token)
    return out


async def _resolve_device_pas_to_group_addresses(
    device_pas: list[str],
    db: Database,
) -> list[str]:
    """Resolve physical addresses to KNX group addresses via persisted knxproj tables.

    The helper is schema-tolerant so it keeps working while the KNX device
    import tables are introduced incrementally across sub-issues.
    """
    return await resolve_device_pas_to_group_addresses(device_pas, db)


def _apply_group_addresses_to_filter_query(
    query: RingBufferQueryV2,
    group_addresses: list[str],
) -> RingBufferQueryV2:
    normalized_group_addresses = _normalize_nonempty(group_addresses)
    if not normalized_group_addresses:
        return query

    metadata_payload = query.filters.metadata.model_dump() if query.filters.metadata else {}
    existing = _normalize_nonempty(metadata_payload.get("group_addresses_any_of", []))
    if existing:
        allowed_set = set(normalized_group_addresses)
        allowed = [ga for ga in existing if ga in allowed_set]
        if not allowed:
            allowed = ["__obs_no_matching_group_address__"]
    else:
        allowed = normalized_group_addresses

    metadata_payload["group_addresses_any_of"] = allowed
    return query.model_copy(
        update={"filters": query.filters.model_copy(update={"metadata": RingBufferMetadataFilterV2.model_validate(metadata_payload)})}
    )


async def _build_query_from_filter_criteria(
    filter_: FilterCriteria,
    *,
    time_filter: RingBufferTimeFilterV2 | None,
    db: Database,
    sort: RingBufferSortV2 | None = None,
    limit: int | None = None,
    offset: int | None = None,
) -> RingBufferQueryV2 | None:
    effective_filter = filter_
    if filter_.hierarchy_nodes:
        resolved_dps = await _resolve_hierarchy_to_datapoints(filter_.hierarchy_nodes, db)
        merged = _normalize_nonempty([*filter_.datapoints, *resolved_dps])
        if not merged:
            return None
        effective_filter = filter_.model_copy(update={"datapoints": merged})

    query = _filter_to_query_v2(effective_filter, time_filter)

    if filter_.devices:
        resolved_group_addresses = await _resolve_device_pas_to_group_addresses(filter_.devices, db)
        if not resolved_group_addresses:
            return None
        query = _apply_group_addresses_to_filter_query(query, resolved_group_addresses)

    updates: dict[str, Any] = {}
    if sort is not None:
        updates["sort"] = sort
    if limit is not None or offset is not None:
        updates["pagination"] = query.pagination.model_copy(
            update={
                "limit": limit if limit is not None else query.pagination.limit,
                "offset": offset if offset is not None else query.pagination.offset,
            }
        )
    if updates:
        query = query.model_copy(update=updates)

    return query


def _filter_to_query_v2(filter_: FilterCriteria, time: RingBufferTimeFilterV2 | None) -> RingBufferQueryV2:
    """Translate a flat :class:`FilterCriteria` plus a time filter into the legacy
    :class:`RingBufferQueryV2` shape that :func:`_query_v2_entries` expects.

    hierarchy_nodes is intentionally NOT expanded here — concrete datapoint IDs
    are expected to already be supplied in ``filter.datapoints`` by the caller
    (the frontend resolves hierarchy_nodes via the trees API). For #431 we
    persist the hierarchy_nodes reference verbatim so the UI can re-display it,
    but server-side matching today only uses ``datapoints``.
    """
    filters: dict[str, Any] = {}
    if filter_.q:
        filters["q"] = filter_.q
    if filter_.adapters:
        filters["adapters"] = {"any_of": list(filter_.adapters)}
    if filter_.datapoints:
        filters["datapoints"] = {"ids": list(filter_.datapoints)}
    if filter_.tags:
        filters["metadata"] = {"tags_any_of": list(filter_.tags)}
    if filter_.value_filter is not None:
        filters["values"] = [filter_.value_filter.model_dump()]
    if time is not None:
        filters["time"] = time.model_dump(by_alias=True, exclude_none=True)
    return RingBufferQueryV2.model_validate(
        {
            "filters": filters,
            "sort": {"field": "id", "order": "desc"},
            "pagination": {"limit": _FILTERSET_QUERY_LIMIT_CAP, "offset": 0},
        }
    )


# ---------------------------------------------------------------------------
# CSV helpers
# ---------------------------------------------------------------------------


def _csv_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def _entry_to_csv_row(entry: RingBufferEntryOut) -> dict[str, str]:
    return {
        "id": str(entry.id),
        "ts": entry.ts,
        "datapoint_id": entry.datapoint_id,
        "name": entry.name or "",
        "topic": entry.topic,
        "old_value_json": _csv_json(entry.old_value),
        "new_value_json": _csv_json(entry.new_value),
        "source_adapter": entry.source_adapter,
        "quality": entry.quality,
        "metadata_version": str(entry.metadata_version),
        "metadata_json": _csv_json(entry.metadata),
    }


# ---------------------------------------------------------------------------
# Core query helper (used by /query, /export/csv and the multi-filterset query)
# ---------------------------------------------------------------------------


async def _query_v2_entries(
    body: RingBufferQueryV2,
    *,
    limit_override: int | None = None,
    offset_override: int | None = None,
    candidate_cap_override: int | None = None,
    is_export: bool = False,
    export_store_cursor: RowLazyExportCursor | None = None,
    db: Database | None = None,
    principal: Principal | None = None,
) -> list[RingBufferEntryOut]:
    if not is_ringbuffer_enabled():
        return []

    from obs.core.registry import get_registry

    registry = get_registry()
    registry_entries = list(registry.all())
    name_map: dict[str, str] = {str(dp.id): dp.name for dp in registry_entries}
    unit_map: dict[str, str | None] = {str(dp.id): getattr(dp, "unit", None) for dp in registry_entries}

    q = body.filters.q.strip()
    dp_ids_by_name: list[str] = []
    if q:
        q_lower = q.lower()
        dp_ids_by_name = [str(dp.id) for dp in registry_entries if q_lower in dp.name.lower()]

    adapters = [value.strip() for value in (body.filters.adapters.any_of if body.filters.adapters else []) if value.strip()]
    datapoints = [value.strip() for value in (body.filters.datapoints.ids if body.filters.datapoints else []) if value.strip()]
    value_filters = [value_filter.model_dump() for value_filter in (body.filters.values or [])]
    metadata_filter = body.filters.metadata
    metadata_tags = [value.strip() for value in (metadata_filter.tags_any_of if metadata_filter else []) if value.strip()]
    metadata_adapter_types = [value.strip() for value in (metadata_filter.adapter_types_any_of if metadata_filter else []) if value.strip()]
    metadata_adapter_instances = [
        value.strip() for value in (metadata_filter.adapter_instance_ids_any_of if metadata_filter else []) if value.strip()
    ]
    metadata_group_addresses = [value.strip() for value in (metadata_filter.group_addresses_any_of if metadata_filter else []) if value.strip()]
    metadata_topics = [value.strip() for value in (metadata_filter.topics_any_of if metadata_filter else []) if value.strip()]
    metadata_entity_ids = [value.strip() for value in (metadata_filter.entity_ids_any_of if metadata_filter else []) if value.strip()]
    metadata_register_types = [value.strip() for value in (metadata_filter.register_types_any_of if metadata_filter else []) if value.strip()]
    metadata_register_addresses = [value.strip() for value in (metadata_filter.register_addresses_any_of if metadata_filter else []) if value.strip()]

    if body.filters.adapters and not adapters:
        raise HTTPException(
            status.HTTP_422_UNPROCESSABLE_CONTENT,
            "filters.adapters.any_of must contain at least one adapter",
        )
    if body.filters.datapoints and not datapoints:
        raise HTTPException(
            status.HTTP_422_UNPROCESSABLE_CONTENT,
            "filters.datapoints.ids must contain at least one datapoint id",
        )
    if body.filters.values is not None and not value_filters:
        raise HTTPException(
            status.HTTP_422_UNPROCESSABLE_CONTENT,
            "filters.values must contain at least one value filter rule",
        )
    if metadata_filter and not any(
        (
            metadata_tags,
            metadata_adapter_types,
            metadata_adapter_instances,
            metadata_group_addresses,
            metadata_topics,
            metadata_entity_ids,
            metadata_register_types,
            metadata_register_addresses,
        )
    ):
        raise HTTPException(
            status.HTTP_422_UNPROCESSABLE_CONTENT,
            "filters.metadata must contain at least one metadata filter rule",
        )

    time_filter = body.filters.time
    datapoint_types = {str(dp.id): dp.data_type for dp in registry_entries}
    scoped_datapoints = datapoints
    if db is not None and principal is not None and not _is_admin_principal(principal):
        candidate_ids = datapoints or list(name_map.keys())
        allowed_ids = await _readable_datapoint_ids(db, principal, candidate_ids)
        allowed_set = set(allowed_ids)
        scoped_datapoints = [dp_id for dp_id in datapoints if dp_id in allowed_set] if datapoints else allowed_ids
        dp_ids_by_name = [dp_id for dp_id in dp_ids_by_name if dp_id in allowed_set]
        if not scoped_datapoints:
            return []

    rb = get_ringbuffer()
    try:
        entries = await rb.query_v2(
            q=q,
            adapter_any_of=adapters or None,
            datapoint_ids=scoped_datapoints or None,
            value_filters=value_filters or None,
            metadata_tags_any_of=metadata_tags or None,
            metadata_adapter_types_any_of=metadata_adapter_types or None,
            metadata_adapter_instance_ids_any_of=metadata_adapter_instances or None,
            metadata_group_addresses_any_of=metadata_group_addresses or None,
            metadata_topics_any_of=metadata_topics or None,
            metadata_entity_ids_any_of=metadata_entity_ids or None,
            metadata_register_types_any_of=metadata_register_types or None,
            metadata_register_addresses_any_of=metadata_register_addresses or None,
            datapoint_types=datapoint_types,
            from_ts=time_filter.from_ts if time_filter else None,
            to_ts=time_filter.to_ts if time_filter else None,
            from_relative_seconds=time_filter.from_relative_seconds if time_filter else None,
            to_relative_seconds=time_filter.to_relative_seconds if time_filter else None,
            limit=limit_override if limit_override is not None else body.pagination.limit,
            offset=offset_override if offset_override is not None else body.pagination.offset,
            sort_field=body.sort.field,
            sort_order=body.sort.order,
            dp_ids_by_name=dp_ids_by_name or None,
            candidate_cap_override=candidate_cap_override,
            is_export=is_export,
            export_store_cursor=export_store_cursor,
        )
    except ValueError as exc:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_CONTENT, str(exc)) from exc

    return [
        RingBufferEntryOut(
            id=e.id,
            ts=e.ts,
            datapoint_id=e.datapoint_id,
            name=name_map.get(e.datapoint_id),
            topic=e.topic,
            old_value=e.old_value,
            new_value=e.new_value,
            source_adapter=e.source_adapter,
            quality=e.quality,
            metadata_version=e.metadata_version,
            metadata=e.metadata,
            unit=unit_map.get(e.datapoint_id),
        )
        for e in entries
    ]


# ---------------------------------------------------------------------------
# Filterset DB helpers (flat schema)
# ---------------------------------------------------------------------------


def _row_to_filterset(row: Any, *, user_state: tuple[bool, bool, int] | None = None) -> RingBufferFiltersetOut:
    """Project a DB row into the API model.

    ``user_state`` holds the per-user override
    ``(is_active, topbar_active, topbar_order)`` from
    ``ringbuffer_filterset_user_state``. When absent (no row for this user),
    the set is treated as active and un-pinned for that user. The global
    ``is_active`` / ``topbar_active`` / ``topbar_order`` columns on
    ``ringbuffer_filtersets`` are no longer surfaced via the API (#478 —
    fully isolated per-user view).
    """
    if user_state is not None:
        is_active, topbar_active, topbar_order = user_state
    else:
        is_active, topbar_active, topbar_order = True, False, 0
    created_by = row["created_by"] if "created_by" in row.keys() else None  # noqa: SIM118 -- Row.__contains__ checks values, not keys
    return RingBufferFiltersetOut(
        id=row["id"],
        name=row["name"],
        description=row["description"],
        dsl_version=int(row["dsl_version"]),
        is_active=is_active,
        color=_normalize_color(row["color"] if "color" in row.keys() else None),  # noqa: SIM118 -- Row.__contains__ checks values, not keys
        topbar_active=topbar_active,
        topbar_order=topbar_order,
        filter=_decode_filter(row["filter_json"] if "filter_json" in row.keys() else None),  # noqa: SIM118 -- Row.__contains__ checks values, not keys
        created_at=row["created_at"],
        updated_at=row["updated_at"],
        created_by=created_by,
    )


async def _fetch_user_state(db: Database, username: str, filterset_id: str) -> tuple[bool, bool, int] | None:
    """Return ``(is_active, topbar_active, topbar_order)`` for the user, or ``None``."""
    row = await db.fetchone(
        "SELECT is_active, topbar_active, topbar_order FROM ringbuffer_filterset_user_state WHERE username=? AND filterset_id=?",
        (username, filterset_id),
    )
    if not row:
        return None
    return bool(row["is_active"]), bool(row["topbar_active"]), int(row["topbar_order"])


async def _fetch_filterset(db: Database, filterset_id: str, *, username: str | None = None) -> RingBufferFiltersetOut | None:
    row = await db.fetchone("SELECT * FROM ringbuffer_filtersets WHERE id=?", (filterset_id,))
    if not row:
        return None
    user_state = await _fetch_user_state(db, username, filterset_id) if username else None
    return _row_to_filterset(row, user_state=user_state)


def _filterset_decision(
    principal: Principal,
    filterset_id: str,
    action: AuthzAction,
    grants: list[RoleGrant],
):
    return authorize(
        principal=principal,
        action=action,
        targets=[AuthzTarget(node_type="ringbuffer_filterset", node_id=filterset_id)],
        grants=grants,
    )


async def _filterset_grants(db: Database, principal: Principal) -> list[RoleGrant]:
    if _is_admin_principal(principal):
        return []
    return await load_role_grants(db, principal, node_type="ringbuffer_filterset")


async def _require_explicit_datapoint_scope(
    db: Database,
    principal: Principal,
    criteria: FilterCriteria,
) -> None:
    """Require READ access to every explicitly referenced datapoint."""
    datapoint_ids = list(dict.fromkeys(criteria.datapoints))
    if not datapoint_ids:
        return
    allowed_ids = set(await filter_authorized_datapoints(db, principal, datapoint_ids, action=AuthzAction.READ))
    if set(datapoint_ids) != allowed_ids:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Datapoint read scope required")


async def _require_filterset_access(
    db: Database,
    filterset_id: str,
    principal: Principal,
    action: AuthzAction,
) -> RingBufferFiltersetOut:
    """Return an authorized filterset while concealing out-of-scope IDs."""
    current = await _fetch_filterset(db, filterset_id, username=principal.subject)
    if current is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "ringbuffer filterset not found")
    grants = await _filterset_grants(db, principal)
    if not _filterset_decision(principal, filterset_id, action, grants).allowed:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "ringbuffer filterset not found")
    can_write = _filterset_decision(principal, filterset_id, AuthzAction.WRITE, grants).allowed
    return current.model_copy(update={"can_write": can_write})


async def _visible_filtersets(
    db: Database,
    principal: Principal,
    *,
    rows: list[Any] | None = None,
) -> list[RingBufferFiltersetOut]:
    source_rows = rows if rows is not None else await db.fetchall("SELECT * FROM ringbuffer_filtersets")
    grants = await _filterset_grants(db, principal)
    states = {
        row["filterset_id"]: (bool(row["is_active"]), bool(row["topbar_active"]), int(row["topbar_order"]))
        for row in await db.fetchall(
            "SELECT filterset_id, is_active, topbar_active, topbar_order FROM ringbuffer_filterset_user_state WHERE username=?",
            (principal.subject,),
        )
    }
    result: list[RingBufferFiltersetOut] = []
    for row in source_rows:
        filterset_id = row["id"]
        if not _filterset_decision(principal, filterset_id, AuthzAction.READ, grants).allowed:
            continue
        result.append(
            _row_to_filterset(row, user_state=states.get(filterset_id)).model_copy(
                update={"can_write": _filterset_decision(principal, filterset_id, AuthzAction.WRITE, grants).allowed}
            )
        )
    result.sort(key=lambda fs: (fs.topbar_order, fs.created_at, fs.id))
    return result


async def _upsert_user_state(
    db: Database,
    *,
    username: str,
    filterset_id: str,
    is_active: bool,
    topbar_active: bool,
    topbar_order: int,
) -> None:
    await db.execute(
        """INSERT INTO ringbuffer_filterset_user_state
             (username, filterset_id, is_active, topbar_active, topbar_order)
           VALUES (?, ?, ?, ?, ?)
           ON CONFLICT(username, filterset_id) DO UPDATE SET
             is_active=excluded.is_active,
             topbar_active=excluded.topbar_active,
             topbar_order=excluded.topbar_order""",
        (username, filterset_id, int(is_active), int(topbar_active), int(topbar_order)),
    )


async def _insert_filterset(
    db: Database,
    *,
    payload: RingBufferFiltersetIn,
    principal: Principal,
    request: Request | None = None,
    audit_path: str = "/api/v1/ringbuffer/filtersets",
) -> RingBufferFiltersetOut:
    if principal.type != "user":
        raise HTTPException(status.HTTP_403_FORBIDDEN, "User principal required to create filtersets")
    await _require_explicit_datapoint_scope(db, principal, payload.filter)
    now = _now_iso()
    filterset_id = _new_id()

    async with db.transaction():
        await db.execute(
            """INSERT INTO ringbuffer_filtersets
               (id, name, description, dsl_version, is_active,
                color, topbar_active, topbar_order, filter_json, created_at, updated_at, created_by)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                filterset_id,
                payload.name,
                payload.description,
                payload.dsl_version,
                int(payload.is_active),
                payload.color,
                int(payload.topbar_active),
                int(payload.topbar_order),
                _encode_filter(payload.filter),
                now,
                now,
                # Non-authoritative provenance; no access check reads this column.
                principal.subject,
            ),
        )
        await db.execute(
            """INSERT INTO authz_node_roles
               (principal_type, principal_id, node_type, node_id, role, effect)
               VALUES ('user', ?, 'ringbuffer_filterset', ?, 'owner', 'allow')""",
            (principal.subject, filterset_id),
        )
        if not payload.is_active or payload.topbar_active or payload.topbar_order:
            await _upsert_user_state(
                db,
                username=principal.subject,
                filterset_id=filterset_id,
                is_active=bool(payload.is_active),
                topbar_active=bool(payload.topbar_active),
                topbar_order=int(payload.topbar_order),
            )
        if audit_path == "/api/v1/ringbuffer/filtersets":
            await write_application_success(
                db,
                request,
                principal,
                "POST",
                "/api/v1/ringbuffer/filtersets",
                resource_id=filterset_id,
                commit=False,
            )
        else:
            await write_application_success(
                db,
                request,
                principal,
                "POST",
                "/api/v1/ringbuffer/filtersets/{filterset_id}/clone",
                resource_id=filterset_id,
                commit=False,
            )
    created = await _fetch_filterset(db, filterset_id, username=principal.subject)
    if not created:
        raise RuntimeError("failed to create filterset")
    return created.model_copy(update={"can_write": True})


# ---------------------------------------------------------------------------
# RingBuffer query (existing endpoints — unchanged behaviour)
# ---------------------------------------------------------------------------


@router.get("/", response_model=list[RingBufferEntryOut])
async def query_ringbuffer(
    q: str = Query("", description="Substring in datapoint name, id or source_adapter"),
    adapter: str = Query("", description="Exact source_adapter match"),
    from_ts: str = Query("", alias="from", description="ISO-8601 timestamp (exclusive lower bound)"),
    limit: int = Query(100, ge=1, le=10000),
    _user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(get_db),
) -> list[RingBufferEntryOut]:
    if not is_ringbuffer_enabled():
        return []

    from obs.core.registry import get_registry

    registry = get_registry()
    registry_entries = list(registry.all())
    name_map: dict[str, str] = {str(dp.id): dp.name for dp in registry_entries}
    unit_map: dict[str, str | None] = {str(dp.id): getattr(dp, "unit", None) for dp in registry_entries}
    dp_ids_by_name: list[str] = []
    if q:
        q_lower = q.lower()
        dp_ids_by_name = [str(dp.id) for dp in registry_entries if q_lower in dp.name.lower()]

    principal = _principal_from_dependency(_user)
    scoped_dp_ids: list[str] | None = None
    if not _is_admin_principal(principal):
        allowed_ids = await _readable_datapoint_ids(db, principal, list(name_map.keys()))
        allowed_set = set(allowed_ids)
        scoped_dp_ids = allowed_ids
        dp_ids_by_name = [dp_id for dp_id in dp_ids_by_name if dp_id in allowed_set]
        if not scoped_dp_ids:
            return []

    rb = get_ringbuffer()
    entries = await rb.query_v2(
        q=q,
        adapter_any_of=[adapter] if adapter else None,
        datapoint_ids=scoped_dp_ids or None,
        from_ts=from_ts or None,
        limit=limit,
        offset=0,
        sort_field="id",
        sort_order="desc",
        dp_ids_by_name=dp_ids_by_name or None,
    )
    return [
        RingBufferEntryOut(
            id=e.id,
            ts=e.ts,
            datapoint_id=e.datapoint_id,
            name=name_map.get(e.datapoint_id),
            topic=e.topic,
            old_value=e.old_value,
            new_value=e.new_value,
            source_adapter=e.source_adapter,
            quality=e.quality,
            metadata_version=e.metadata_version,
            metadata=e.metadata,
            unit=unit_map.get(e.datapoint_id),
        )
        for e in entries
    ]


@router.post("/query", response_model=list[RingBufferEntryOut])
async def query_ringbuffer_v2(
    body: RingBufferQueryV2,
    _user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(get_db),
) -> list[RingBufferEntryOut]:
    principal = _principal_from_dependency(_user)
    return await _query_v2_entries(body, db=db, principal=principal)


@router.post("/export/csv")
async def export_ringbuffer_csv(
    body: RingBufferQueryV2,
    background_tasks: BackgroundTasks,
    _user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(get_db),
) -> StreamingResponse:
    # CSV export always returns the full filtered result set independent of UI pagination.
    started = time.monotonic()
    offset = 0
    exported_rows = 0
    # Row-lazy Export-Cursor (#951, Codex :1654): EIN Cursor ueber alle Chunks, damit der
    # segmentierte row-lazy Zweig den Roh-Scan chunk-uebergreifend fortsetzt statt pro Chunk
    # ab Store-``offset`` 0 neu zu scannen (sonst O(n²) Full-Rescans). Fuer Pushdown-/Legacy-
    # /Nicht-row-lazy-Pfade bleibt der Cursor ungenutzt und aendert nichts.
    export_store_cursor = RowLazyExportCursor()

    spool = tempfile.SpooledTemporaryFile(  # noqa: SIM115 -- closed later via background_tasks, must outlive this function
        mode="w+",
        encoding="utf-8",
        newline="",
        max_size=_CSV_EXPORT_SPOOL_MAX_BYTES,
    )
    writer = csv.DictWriter(spool, fieldnames=list(_CSV_EXPORT_HEADERS))
    writer.writeheader()
    principal = _principal_from_dependency(_user)

    try:
        while True:
            if time.monotonic() - started > _CSV_EXPORT_TOTAL_TIMEOUT_SECONDS:
                raise HTTPException(
                    status.HTTP_504_GATEWAY_TIMEOUT,
                    "ringbuffer CSV export timed out",
                )

            remaining = _CSV_EXPORT_MAX_ROWS - exported_rows
            if remaining <= 0:
                break
            chunk_size = min(_CSV_EXPORT_CHUNK_SIZE, remaining)

            try:
                chunk = await asyncio.wait_for(
                    _query_v2_entries(
                        body,
                        limit_override=chunk_size,
                        offset_override=offset,
                        candidate_cap_override=offset + chunk_size,
                        is_export=True,
                        export_store_cursor=export_store_cursor,
                        db=db,
                        principal=principal,
                    ),
                    timeout=_CSV_EXPORT_QUERY_TIMEOUT_SECONDS,
                )
            except TimeoutError as exc:
                raise HTTPException(
                    status.HTTP_504_GATEWAY_TIMEOUT,
                    "ringbuffer CSV export timed out",
                ) from exc

            if not chunk:
                break

            for entry in chunk:
                writer.writerow(_entry_to_csv_row(entry))

            fetched = len(chunk)
            exported_rows += fetched
            offset += fetched

            if fetched < chunk_size:
                break

        if exported_rows == _CSV_EXPORT_MAX_ROWS:
            probe = await asyncio.wait_for(
                _query_v2_entries(
                    body,
                    limit_override=1,
                    offset_override=offset,
                    candidate_cap_override=offset + 1,
                    is_export=True,
                    export_store_cursor=export_store_cursor,
                    db=db,
                    principal=principal,
                ),
                timeout=_CSV_EXPORT_QUERY_TIMEOUT_SECONDS,
            )
            if probe:
                raise HTTPException(
                    status.HTTP_422_UNPROCESSABLE_CONTENT,
                    f"export row limit exceeded (max {_CSV_EXPORT_MAX_ROWS})",
                )
    except Exception:
        spool.close()
        raise

    spool.seek(0)
    filename = f"ringbuffer_export_{datetime.now(UTC).strftime('%Y%m%dT%H%M%SZ')}.csv"
    background_tasks.add_task(spool.close)
    return StreamingResponse(
        spool,
        media_type="text/csv; charset=utf-8",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "X-RingBuffer-Export-Rows": str(exported_rows),
        },
        background=background_tasks,
    )


# ---------------------------------------------------------------------------
# Filterset CRUD (flat schema, with legacy shim on POST/PUT)
# ---------------------------------------------------------------------------


def _parse_filterset_in(raw: dict[str, Any]) -> RingBufferFiltersetIn:
    try:
        return RingBufferFiltersetIn.model_validate(raw)
    except ValidationError as exc:
        # ``include_context=False`` strips the raw Python exception object from
        # the error list — FastAPI's default JSON encoder chokes on the bundled
        # ``ValueError`` instance otherwise (see #431).
        raise HTTPException(
            status.HTTP_422_UNPROCESSABLE_CONTENT,
            exc.errors(include_url=False, include_context=False),
        ) from exc


async def _read_json_body(request: Request) -> dict[str, Any]:
    try:
        raw = await request.json()
    except json.JSONDecodeError as exc:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_CONTENT, "invalid JSON body") from exc
    if not isinstance(raw, dict):
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_CONTENT, "request body must be a JSON object")
    return raw


@router.get("/filtersets", response_model=list[RingBufferFiltersetOut])
async def list_ringbuffer_filtersets(
    current_user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(get_db),
) -> list[RingBufferFiltersetOut]:
    return await _visible_filtersets(db, _principal_from_dependency(current_user))


@router.post("/filtersets", response_model=RingBufferFiltersetOut, status_code=status.HTTP_201_CREATED)
@audit_application_contract("POST", "/api/v1/ringbuffer/filtersets", principal_param="current_user")
async def create_ringbuffer_filterset(
    request: Request,
    current_user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(get_db),
) -> RingBufferFiltersetOut:
    raw = await _read_json_body(request)
    payload = _parse_filterset_in(raw)
    if _is_empty_criteria(payload.filter):
        raise HTTPException(
            status.HTTP_422_UNPROCESSABLE_CONTENT,
            "filterset.filter must declare at least one criterion (hierarchy_nodes, datapoints, devices, tags, adapters, q, or value_filter)",
        )
    return await _insert_filterset(
        db,
        payload=payload,
        principal=_principal_from_dependency(current_user),
        request=request,
        audit_path="/api/v1/ringbuffer/filtersets",
    )


@router.get("/filtersets/{filterset_id}", response_model=RingBufferFiltersetOut)
async def get_ringbuffer_filterset(
    filterset_id: str,
    current_user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(get_db),
) -> RingBufferFiltersetOut:
    return await _require_filterset_access(db, filterset_id, _principal_from_dependency(current_user), AuthzAction.READ)


@router.put("/filtersets/{filterset_id}", response_model=RingBufferFiltersetOut)
@audit_application_contract("PUT", "/api/v1/ringbuffer/filtersets/{filterset_id}", principal_param="current_user", resource_param="filterset_id")
async def update_ringbuffer_filterset(
    filterset_id: str,
    request: Request,
    current_user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(get_db),
) -> RingBufferFiltersetOut:
    principal = _principal_from_dependency(current_user)
    current = await _require_filterset_access(db, filterset_id, principal, AuthzAction.WRITE)

    raw = await _read_json_body(request)
    try:
        body = RingBufferFiltersetUpdate.model_validate(raw)
    except ValidationError as exc:
        raise HTTPException(
            status.HTTP_422_UNPROCESSABLE_CONTENT,
            exc.errors(include_url=False, include_context=False),
        ) from exc

    now = _now_iso()
    name = body.name if body.name is not None else current.name
    description = body.description if body.description is not None else current.description
    dsl_version = body.dsl_version if body.dsl_version is not None else current.dsl_version
    color = body.color if body.color is not None else current.color
    new_filter = body.filter if body.filter is not None else current.filter

    if _is_empty_criteria(new_filter):
        raise HTTPException(
            status.HTTP_422_UNPROCESSABLE_CONTENT,
            "filterset.filter must declare at least one criterion (hierarchy_nodes, datapoints, devices, tags, adapters, q, or value_filter)",
        )
    await _require_explicit_datapoint_scope(db, principal, new_filter)

    # is_active, topbar_active and topbar_order live in
    # ringbuffer_filterset_user_state per-user (#478); PUT only changes the
    # shared payload (name/description/filter/color/dsl_version) and never
    # touches the global is_active / topbar_* columns.
    async with db.transaction():
        await db.execute(
            """UPDATE ringbuffer_filtersets
               SET name=?, description=?, dsl_version=?,
                   color=?, filter_json=?, updated_at=?
               WHERE id=?""",
            (
                name,
                description,
                dsl_version,
                color,
                _encode_filter(new_filter),
                now,
                filterset_id,
            ),
        )
        if body.is_active is not None or body.topbar_active is not None or body.topbar_order is not None:
            prior = await _fetch_user_state(db, principal.subject, filterset_id)
            active = body.is_active if body.is_active is not None else (prior[0] if prior else True)
            topbar_active = body.topbar_active if body.topbar_active is not None else (prior[1] if prior else False)
            order = body.topbar_order if body.topbar_order is not None else (prior[2] if prior else 0)
            await _upsert_user_state(
                db,
                username=principal.subject,
                filterset_id=filterset_id,
                is_active=bool(active),
                topbar_active=bool(topbar_active),
                topbar_order=int(order),
            )
        await write_application_success(
            db,
            request,
            principal,
            "PUT",
            "/api/v1/ringbuffer/filtersets/{filterset_id}",
            resource_id=filterset_id,
            commit=False,
        )
    updated = await _fetch_filterset(db, filterset_id, username=principal.subject)
    if not updated:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "ringbuffer filterset not found")
    return updated.model_copy(update={"can_write": True})


@router.delete("/filtersets/{filterset_id}", status_code=status.HTTP_204_NO_CONTENT)
@audit_application_contract("DELETE", "/api/v1/ringbuffer/filtersets/{filterset_id}", principal_param="current_user", resource_param="filterset_id")
async def delete_ringbuffer_filterset(
    filterset_id: str,
    current_user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(get_db),
) -> None:
    principal = _principal_from_dependency(current_user)
    await _require_filterset_access(db, filterset_id, principal, AuthzAction.WRITE)
    async with db.transaction():
        await db.execute(
            "DELETE FROM authz_node_roles WHERE node_type='ringbuffer_filterset' AND node_id=?",
            (filterset_id,),
        )
        await db.execute("DELETE FROM ringbuffer_filtersets WHERE id=?", (filterset_id,))
        await write_application_success(
            db,
            None,
            principal,
            "DELETE",
            "/api/v1/ringbuffer/filtersets/{filterset_id}",
            resource_id=filterset_id,
            commit=False,
        )


@router.post("/filtersets/{filterset_id}/clone", response_model=RingBufferFiltersetOut, status_code=status.HTTP_201_CREATED)
@audit_application_contract(
    "POST", "/api/v1/ringbuffer/filtersets/{filterset_id}/clone", principal_param="current_user", resource_param="filterset_id"
)
async def clone_ringbuffer_filterset(
    request: Request,
    filterset_id: str,
    body: RingBufferFiltersetCloneRequest,
    current_user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(get_db),
) -> RingBufferFiltersetOut:
    principal = _principal_from_dependency(current_user)
    if principal.type != "user":
        raise HTTPException(status.HTTP_403_FORBIDDEN, "User principal required to create filtersets")
    source = await _require_filterset_access(db, filterset_id, principal, AuthzAction.READ)

    clone_name = body.name if body.name else f"{source.name} (Copy)"
    clone_payload = RingBufferFiltersetIn(
        name=clone_name,
        description=source.description,
        dsl_version=source.dsl_version,
        is_active=source.is_active,
        color=source.color,
        # Clones do not inherit topbar activation — the user explicitly opts in
        # via the PATCH /topbar endpoint after deciding the clone is ready.
        topbar_active=False,
        topbar_order=0,
        filter=source.filter,
    )
    return await _insert_filterset(
        db,
        payload=clone_payload,
        principal=principal,
        request=request,
        audit_path="/api/v1/ringbuffer/filtersets/{filterset_id}/clone",
    )


# ---------------------------------------------------------------------------
# Topbar PATCH endpoints (#431)
# ---------------------------------------------------------------------------


@router.patch("/filtersets/order", response_model=list[RingBufferFiltersetOut])
@audit_application_contract("PATCH", "/api/v1/ringbuffer/filtersets/order", principal_param="current_user")
async def patch_ringbuffer_filtersets_order(
    body: RingBufferFiltersetOrderPatch,
    current_user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(get_db),
) -> list[RingBufferFiltersetOut]:
    """Persist a new topbar order for several sets in one batch — per-user.

    Sets not mentioned in ``items`` keep their existing per-user ``topbar_order``.
    Unknown IDs are ignored silently — a racing delete must not break drag-and-
    drop reordering.
    """
    principal = _principal_from_dependency(current_user)
    visible = await _visible_filtersets(db, principal)
    known_ids = {filterset.id for filterset in visible}
    async with db.transaction():
        for item in body.items:
            if item.id not in known_ids:
                continue
            prior = await _fetch_user_state(db, principal.subject, item.id)
            is_active = prior[0] if prior else True
            topbar_active = prior[1] if prior else False
            await _upsert_user_state(
                db,
                username=principal.subject,
                filterset_id=item.id,
                is_active=bool(is_active),
                topbar_active=bool(topbar_active),
                topbar_order=int(item.topbar_order),
            )
        await write_application_success(
            db,
            None,
            principal,
            "PATCH",
            "/api/v1/ringbuffer/filtersets/order",
            details={
                "item_count": len(body.items),
                "payload_sha256": audit_payload_sha256([item.model_dump() for item in body.items]),
            },
            commit=False,
        )

    return await _visible_filtersets(db, principal)


@router.patch("/filtersets/{filterset_id}/topbar", response_model=RingBufferFiltersetOut)
@audit_application_contract(
    "PATCH",
    "/api/v1/ringbuffer/filtersets/{filterset_id}/topbar",
    principal_param="current_user",
    resource_param="filterset_id",
)
async def patch_ringbuffer_filterset_topbar(
    filterset_id: str,
    body: RingBufferFiltersetTopbarPatch,
    current_user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(get_db),
) -> RingBufferFiltersetOut:
    """Update the per-user view (``is_active``, ``topbar_active``, ``topbar_order``).

    All three fields live in ``ringbuffer_filterset_user_state`` (#478), so
    every principal with central READ access maintains its own active/pinned
    state. WRITE is not required because this never mutates the shared set.
    """
    principal = _principal_from_dependency(current_user)
    await _require_filterset_access(db, filterset_id, principal, AuthzAction.READ)

    prior = await _fetch_user_state(db, principal.subject, filterset_id)
    cur_is_active = prior[0] if prior else True
    cur_topbar_active = prior[1] if prior else False
    cur_topbar_order = prior[2] if prior else 0

    is_active = body.is_active if body.is_active is not None else cur_is_active
    topbar_active = body.topbar_active if body.topbar_active is not None else cur_topbar_active
    topbar_order = body.topbar_order if body.topbar_order is not None else cur_topbar_order

    # When the set transitions from "not in topbar" to "in topbar" *and* the
    # caller did not pin an explicit order, assign one that ranks the new
    # set after every currently topbar-active set IN THIS USER'S VIEW. This
    # avoids many sets piling up at topbar_order=0 and keeps the deterministic
    # first-color-wins tie-break sane.
    if topbar_active and not cur_topbar_active and body.topbar_order is None:
        max_row = await db.fetchone(
            "SELECT COALESCE(MAX(topbar_order), -1) AS max_order FROM ringbuffer_filterset_user_state "
            "WHERE username=? AND topbar_active=1 AND filterset_id != ?",
            (principal.subject, filterset_id),
        )
        max_order = int(max_row["max_order"]) if max_row else -1
        topbar_order = max_order + 1

    async with db.transaction():
        await _upsert_user_state(
            db,
            username=principal.subject,
            filterset_id=filterset_id,
            is_active=bool(is_active),
            topbar_active=bool(topbar_active),
            topbar_order=int(topbar_order),
        )
        await write_application_success(
            db,
            None,
            principal,
            "PATCH",
            "/api/v1/ringbuffer/filtersets/{filterset_id}/topbar",
            resource_id=filterset_id,
            commit=False,
        )

    updated = await _fetch_filterset(db, filterset_id, username=principal.subject)
    if not updated:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "ringbuffer filterset not found")
    grants = await _filterset_grants(db, principal)
    return updated.model_copy(update={"can_write": _filterset_decision(principal, filterset_id, AuthzAction.WRITE, grants).allowed})


# ---------------------------------------------------------------------------
# Multi-set query (#431) — OR-union across all named sets, annotated entries
# ---------------------------------------------------------------------------


@router.post("/filtersets/query", response_model=list[RingBufferMultiEntryOut])
async def query_ringbuffer_filtersets_multi(
    body: RingBufferMultiQueryRequest,
    current_user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(get_db),
) -> list[RingBufferMultiEntryOut]:
    principal = _principal_from_dependency(current_user)
    if len(body.set_ids) > _FILTERSET_MULTI_QUERY_SET_CAP:
        raise HTTPException(
            status.HTTP_422_UNPROCESSABLE_CONTENT,
            f"too many filtersets requested (max {_FILTERSET_MULTI_QUERY_SET_CAP})",
        )

    # No filtersets requested → return entries filtered only by the time window
    # (or no filter at all if ``time`` is also None). This mirrors how the topbar
    # looks before the user toggles any set on.
    if not body.set_ids:
        empty_filter = FilterCriteria()
        query = _filter_to_query_v2(empty_filter, body.time)
        query = query.model_copy(
            update={
                "sort": body.sort,
                "pagination": query.pagination.model_copy(
                    update={"limit": body.limit, "offset": body.offset},
                ),
            }
        )
        entries = await _query_v2_entries(query, db=db, principal=principal)
        return [RingBufferMultiEntryOut(**entry.model_dump(), matched_set_ids=[]) for entry in entries]

    # Resolve sets — skip missing/inactive (per-user) ones rather than fail.
    # ``is_active`` is now part of the caller's per-user state, so two users may
    # see different OR-unions across the same set_ids.
    visible_by_id = {filterset.id: filterset for filterset in await _visible_filtersets(db, principal)}
    resolved: list[RingBufferFiltersetOut] = []
    for set_id in body.set_ids:
        current = visible_by_id.get(set_id)
        if current is None:
            continue
        if not current.is_active:
            continue
        # Empty FilterCriteria → no real filter configured yet. Skip so the
        # user sees the empty result (#36 UX): topbar chip will show the
        # warn marker so the misconfiguration is obvious.
        if _is_empty_criteria(current.filter):
            continue
        resolved.append(current)

    # Per-set query, generously paginated; OR-union by entry id and remember
    # which sets contributed to the union for each entry.
    per_set_limit = min(body.limit + body.offset + _FILTERSET_QUERY_LIMIT_CAP, _FILTERSET_MULTI_QUERY_PER_SET_LIMIT)
    matched: dict[int, list[str]] = {}
    entries_by_id: dict[int, RingBufferEntryOut] = {}
    for fs in resolved:
        query = await _build_query_from_filter_criteria(
            fs.filter,
            time_filter=body.time,
            db=db,
            sort=body.sort,
            limit=per_set_limit,
            offset=0,
        )
        if query is None:
            continue
        try:
            rows = await _query_v2_entries(query, db=db, principal=principal)
        except HTTPException:
            # An empty-but-present filter criterion (e.g. tags=[]) reduces to a
            # no-op match — skip it instead of failing the whole multi-query.
            continue
        for entry in rows:
            matched.setdefault(entry.id, []).append(fs.id)
            entries_by_id.setdefault(entry.id, entry)

    # Apply final sort + pagination on the union.
    ordered_ids = sorted(
        matched.keys(),
        key=lambda eid: (entries_by_id[eid].ts, entries_by_id[eid].id) if body.sort.field == "ts" else entries_by_id[eid].id,
        reverse=(body.sort.order == "desc"),
    )
    paginated = ordered_ids[body.offset : body.offset + body.limit]
    return [
        RingBufferMultiEntryOut(
            **entries_by_id[eid].model_dump(),
            matched_set_ids=matched[eid],
        )
        for eid in paginated
    ]


@router.post("/filtersets/{filterset_id}/query", response_model=list[RingBufferEntryOut])
async def query_ringbuffer_filterset(
    filterset_id: str,
    current_user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(get_db),
) -> list[RingBufferEntryOut]:
    """Single-set query (back-compat for callers that target one set at a time).

    The body is intentionally ignored — the time filter and pagination are
    fixed defaults here. Callers that need custom time/pagination should use
    ``POST /filtersets/query`` with a single-element ``set_ids`` list. The
    set's ``is_active`` flag is taken from the caller's per-user state (#478).
    """
    principal = _principal_from_dependency(current_user)
    current = await _require_filterset_access(db, filterset_id, principal, AuthzAction.READ)
    if not current.is_active:
        return []

    query = await _build_query_from_filter_criteria(current.filter, time_filter=None, db=db)
    if query is None:
        return []
    return await _query_v2_entries(query, db=db, principal=principal)


# ---------------------------------------------------------------------------
# Multi-set CSV/TSV export (#427)
# ---------------------------------------------------------------------------


_EXPORT_SETTINGS_KEY = "ringbuffer.export_settings"


async def _guarded_export_query(
    query: RingBufferQueryV2,
    *,
    candidate_cap_override: int,
    db: Database,
    principal: Principal,
) -> list[RingBufferEntryOut]:
    """Fuehrt einen Filterset-Export-Scan mit dem Per-Query-Timeout des CSV-Exports aus (#951 [P2]).

    Ohne Guard koennte ein pathologischer q-/metadata-/contains-/regex-/value-Filter ueber eine
    grosse Legacy-Datei oder viele v2-Segmente bis zur Erschoepfung scannen und den API-Worker
    blockieren, BEVOR eine Response gesendet wird. Bei Timeout dasselbe 504 wie
    ``/ringbuffer/export/csv``.
    """
    try:
        return await asyncio.wait_for(
            _query_v2_entries(
                query,
                candidate_cap_override=candidate_cap_override,
                is_export=True,
                db=db,
                principal=principal,
            ),
            timeout=_CSV_EXPORT_QUERY_TIMEOUT_SECONDS,
        )
    except TimeoutError as exc:
        raise HTTPException(
            status.HTTP_504_GATEWAY_TIMEOUT,
            "ringbuffer CSV export timed out",
        ) from exc


async def _collect_multi_entries(
    body: RingBufferMultiExportRequest,
    db: Database,
    *,
    username: str | None = None,
    principal: Principal | None = None,
) -> tuple[list[RingBufferEntryOut], dict[int, list[str]]]:
    """Collect the OR-union of entries across the requested filtersets.

    Mirrors the logic of ``POST /filtersets/query`` but with the export-specific
    row cap and pagination semantics: we want **all** rows in the union, capped
    only by the global ``_CSV_EXPORT_MAX_ROWS`` guard the streaming writer
    enforces.
    """
    if len(body.set_ids) > _FILTERSET_MULTI_QUERY_SET_CAP:
        raise HTTPException(
            status.HTTP_422_UNPROCESSABLE_CONTENT,
            f"too many filtersets requested (max {_FILTERSET_MULTI_QUERY_SET_CAP})",
        )

    if not body.set_ids:
        empty_filter = FilterCriteria()
        query = _filter_to_query_v2(empty_filter, body.time)
        query = query.model_copy(
            update={
                "pagination": query.pagination.model_copy(
                    update={"limit": _CSV_EXPORT_MAX_ROWS, "offset": 0},
                ),
            }
        )
        if principal is None:
            return [], {}
        entries = await _guarded_export_query(
            query,
            candidate_cap_override=_CSV_EXPORT_MAX_ROWS,
            db=db,
            principal=principal,
        )
        return entries, {e.id: [] for e in entries}

    if principal is None:
        return [], {}
    started = time.monotonic()
    visible_by_id = {filterset.id: filterset for filterset in await _visible_filtersets(db, principal)}
    resolved: list[RingBufferFiltersetOut] = []
    for set_id in body.set_ids:
        current = visible_by_id.get(set_id)
        if current is None or not current.is_active:
            continue
        # Empty FilterCriteria → the set has no real filter configured yet.
        # Treat it as a no-op so the user sees an empty table (and the chip
        # warn-icon in the UI) rather than every row being painted (#36).
        if _is_empty_criteria(current.filter):
            continue
        resolved.append(current)

    matched: dict[int, list[str]] = {}
    entries_by_id: dict[int, RingBufferEntryOut] = {}
    for fs in resolved:
        if time.monotonic() - started > _CSV_EXPORT_TOTAL_TIMEOUT_SECONDS:
            raise HTTPException(
                status.HTTP_504_GATEWAY_TIMEOUT,
                "ringbuffer CSV export timed out",
            )
        query = await _build_query_from_filter_criteria(
            fs.filter,
            time_filter=body.time,
            db=db,
            limit=_CSV_EXPORT_MAX_ROWS,
            offset=0,
        )
        if query is None:
            continue
        try:
            rows = await _guarded_export_query(
                query,
                candidate_cap_override=_CSV_EXPORT_MAX_ROWS,
                db=db,
                principal=principal,
            )
        except HTTPException as exc:
            if exc.status_code == status.HTTP_504_GATEWAY_TIMEOUT:
                raise
            continue
        for entry in rows:
            matched.setdefault(entry.id, []).append(fs.id)
            entries_by_id.setdefault(entry.id, entry)

    ordered_ids = sorted(matched.keys(), key=lambda eid: entries_by_id[eid].ts, reverse=True)
    ordered_entries = [entries_by_id[eid] for eid in ordered_ids]
    return ordered_entries, matched


@router.post("/filtersets/export/count", response_model=RingBufferMultiExportCountResponse)
async def count_ringbuffer_filtersets_export(
    body: RingBufferMultiExportCountRequest,
    current_user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(get_db),
) -> RingBufferMultiExportCountResponse:
    """Preflight: how many rows would the corresponding CSV export produce?

    Used by the UI to warn the user before triggering a large download. The
    set/time semantics match ``POST /filtersets/export/csv`` exactly, so the
    returned count is the row count of the union the export would write.
    Per-user ``is_active`` applies — a set the caller has deactivated for
    themselves is excluded from the count too (#478).
    """
    principal = _principal_from_dependency(current_user)
    export_body = RingBufferMultiExportRequest(set_ids=body.set_ids, time=body.time)
    entries, _ = await _collect_multi_entries(export_body, db, username=principal.subject, principal=principal)
    return RingBufferMultiExportCountResponse(row_count=len(entries))


@router.post("/filtersets/export/csv")
async def export_ringbuffer_filtersets_csv(
    body: RingBufferMultiExportRequest,
    background_tasks: BackgroundTasks,
    current_user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(get_db),
) -> StreamingResponse:
    """Multi-set CSV/TSV export — OR-union of all requested active sets.

    Optional columns (``unit`` from #434, ``matched_set_ids`` from #431) and
    encoding (UTF-8 with optional BOM) are toggleable via the request body. The
    persisted user defaults live behind ``GET/PUT /ringbuffer/export/settings``.
    Per-user ``is_active`` filters the OR-union to what the caller has enabled.
    """
    principal = _principal_from_dependency(current_user)
    entries, matched = await _collect_multi_entries(body, db, username=principal.subject, principal=principal)
    if len(entries) > _CSV_EXPORT_MAX_ROWS:
        raise HTTPException(
            status.HTTP_422_UNPROCESSABLE_CONTENT,
            f"export row limit exceeded (max {_CSV_EXPORT_MAX_ROWS})",
        )

    # Tab delimiter conventionally produces .tsv with the matching media type;
    # everything else lands as .csv. Extension and media type are derived from
    # the delimiter, not from a separate format selector.
    extension = "tsv" if body.delimiter == "\t" else "csv"
    media_type = "text/tab-separated-values" if body.delimiter == "\t" else "text/csv"

    fieldnames = list(_CSV_EXPORT_HEADERS)
    if body.include_unit:
        fieldnames.append("unit")
    if body.include_matched_set_ids:
        fieldnames.append("matched_set_ids")

    spool = tempfile.SpooledTemporaryFile(  # noqa: SIM115 -- closed later via background_tasks, must outlive this function
        mode="w+",
        encoding="utf-8",
        newline="",
        max_size=_CSV_EXPORT_SPOOL_MAX_BYTES,
    )
    if body.encoding == "utf8-bom":
        spool.write("﻿")
    # Empty escape_char selects RFC 4180 behaviour (doublequote=True). Setting
    # an escape_char switches the writer to backslash-style escaping; csv
    # requires doublequote=False in that mode.
    writer_kwargs: dict[str, Any] = {
        "delimiter": body.delimiter,
        "quotechar": body.quote_char,
    }
    if body.escape_char:
        writer_kwargs["escapechar"] = body.escape_char
        writer_kwargs["doublequote"] = False
    writer = csv.DictWriter(spool, fieldnames=fieldnames, **writer_kwargs)
    writer.writeheader()
    for entry in entries:
        row = _entry_to_csv_row(entry)
        if body.include_unit:
            row["unit"] = entry.unit or ""
        if body.include_matched_set_ids:
            row["matched_set_ids"] = ",".join(matched.get(entry.id, []))
        writer.writerow(row)

    spool.seek(0)
    filename = f"ringbuffer_export_{datetime.now(UTC).strftime('%Y%m%dT%H%M%SZ')}.{extension}"
    background_tasks.add_task(spool.close)
    return StreamingResponse(
        spool,
        media_type=f"{media_type}; charset=utf-8",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "X-RingBuffer-Export-Rows": str(len(entries)),
        },
        background=background_tasks,
    )


@router.get("/export/settings", response_model=RingBufferExportSettings)
async def get_ringbuffer_export_settings(
    _user: str = Depends(get_current_user),
    db: Database = Depends(get_db),
) -> RingBufferExportSettings:
    row = await db.fetchone("SELECT value FROM app_settings WHERE key=?", (_EXPORT_SETTINGS_KEY,))
    if not row or not row["value"]:
        return RingBufferExportSettings()
    try:
        raw = json.loads(row["value"])
    except json.JSONDecodeError:
        return RingBufferExportSettings()
    # Legacy format: pre-#427 the dialog stored a CSV/TSV radio selection.
    # Translate to the new delimiter when the new key is absent so users
    # don't silently lose their old TSV preference on first load.
    if isinstance(raw, dict) and "delimiter" not in raw and raw.get("format") == "tsv":
        raw["delimiter"] = "\t"
    try:
        return RingBufferExportSettings(**raw)
    except ValidationError:
        return RingBufferExportSettings()


@router.put("/export/settings", response_model=RingBufferExportSettings)
@audit_application_contract("PUT", "/api/v1/ringbuffer/export/settings", principal_param="_user")
async def put_ringbuffer_export_settings(
    body: RingBufferExportSettings,
    _user: str = Depends(get_current_user),
    db: Database = Depends(get_db),
) -> RingBufferExportSettings:
    payload = json.dumps(body.model_dump())
    async with db.transaction():
        await db.execute(
            "INSERT INTO app_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (_EXPORT_SETTINGS_KEY, payload),
        )
        await write_application_success(db, None, _user, "PUT", "/api/v1/ringbuffer/export/settings", commit=False)
    return body


# ---------------------------------------------------------------------------
# Stats / config
# ---------------------------------------------------------------------------


class LegacyMigrationDecisionIn(BaseModel):
    """Entscheidung des Migrations-Assistenten (#964). ``migrate`` startet den Job (#965)."""

    decision: Literal["keep", "discard", "skip"]


class LegacyMigrationStatus(BaseModel):
    """Zustand + Ist-Analyse für den Migrations-Assistenten (#964)."""

    decision: str | None
    retention_protected: bool
    legacy: dict[str, Any] | None
    disk_free_bytes: int | None
    budget_bytes: int | None
    estimated_copy_bytes: int | None
    over_budget: bool
    estimated_seconds_until_budget: float | None
    job: dict[str, Any] | None


async def _legacy_migration_status(db: Database) -> LegacyMigrationStatus:
    """Baut den Assistenten-Status aus Decision-State, Legacy-Overview und Prognose (#964).

    Eskalations-Signal: ``estimated_seconds_until_budget`` prognostiziert aus der
    Wachstumsrate (``prognosis.bytes_per_hour``), wann das Size-Budget erschöpft ist
    und die FIFO-Retention das Legacy-Segment zurückgewinnen MÜSSTE (0 = bereits
    über Budget). ``None``, wenn keine Rate/kein Budget vorliegt.
    """
    rb = get_optional_ringbuffer()
    # Die Post-Commit-Finalisierung (state-basiertes Nachziehen von ``migrated``) läuft NICHT mehr
    # hier, sondern in den Aufrufern unter ``_LEGACY_DECISION_LOCK`` (#968, Q10j0): dieser Helper
    # wird auch aus dem Decision-/Start-Pfad aufgerufen, die den Lock bereits halten – ein zweiter
    # (nicht-reentranter) Lock-Erwerb hier würde deadlocken. Der GET-Status-Endpoint und der
    # Config-Runtime-Init serialisieren den Finalizer daher explizit vor ihrem Aufruf dieses Helpers.
    decision = await load_legacy_migration_decision(db)
    legacy: dict[str, Any] | None = None
    over_budget = False
    budget: int | None = None
    eta: float | None = None
    estimated_copy: int | None = None
    reclaimable_migrating_manifest_bytes = 0
    reclaimable_migrating_disk_bytes = 0
    protected = decision in LEGACY_DECISIONS_PROTECTED
    job: dict[str, Any] | None = None
    if rb is not None and is_ringbuffer_enabled():
        job = rb.legacy_migration_progress()
        legacy = await rb.legacy_migration_overview()
        stats = await rb.stats()
        budget = stats.get("max_file_size_bytes")
        if legacy is not None:
            reclaimable_migrating_manifest_bytes, reclaimable_migrating_disk_bytes = await rb.reclaimable_migrating_bytes()
        # ``retention_over_budget`` liegt unter ``store.backend_extra`` und die Gesamt-
        # Nutzung als Top-Level ``file_size_bytes`` (#968, Codex :1999) – nicht als
        # Top-Level ``retention_over_budget``/``size_bytes``. Ohne die korrekten Pfade
        # war ``over_budget`` immer False und ``size`` None, sodass genau der attachte-
        # Legacy-Upgrade-Fall (fuer den die Eskalation gebaut wurde) nie eskalierte.
        over_budget = bool(((stats.get("store") or {}).get("backend_extra") or {}).get("retention_over_budget"))
        if legacy is not None and not over_budget and budget:
            rate = (stats.get("prognosis") or {}).get("bytes_per_hour")
            size = stats.get("file_size_bytes")
            if rate and size is not None and rate > 0:
                eta = max(0.0, (budget - size) / rate * 3600.0)
        elif legacy is not None and over_budget:
            eta = 0.0
        # Copy-Obergrenze fuer den Disk-Precheck (#968, Codex :278/:2020): der Job kopiert
        # nur das v2-Aequivalent der Legacy-Daten, gekappt auf das TATSAECHLICHE
        # Ziel-Volumen des Migrators – ``budget - headroom - live_bytes`` – NICHT auf das
        # ganze Budget. Verbrauchen vorhandene Live-Segmente bereits den Grossteil des
        # Budgets, kopiert der Job entsprechend weniger; ein UI-Block anhand des vollen
        # Budgets wuerde eine valide Migration grundlos verhindern. Konservativ mit
        # ``2x Legacy-Groesse`` gedeckelt (v2-Zeilen sind groesser als ihre v1-Quelle).
        legacy_size = (legacy or {}).get("size_bytes")
        if isinstance(legacy_size, int) and legacy_size > 0:
            v2_estimate = 2 * legacy_size
            if budget:
                headroom = ((stats.get("prognosis") or {}).get("effective_segment_max_bytes")) or 0
                total_size = stats.get("file_size_bytes") or 0
                # ALLE Legacy-Quellen aus den Live-Bytes herausrechnen (#968, Codex :2032), nicht
                # nur die angezeigte: der Migrator schließt in ``_target_copy_volume`` jedes
                # Legacy-Segment aus. Bei mehreren attachten Quellen zählten die übrigen sonst als
                # Live-Bestand, senkten ``target_volume``/``estimated_copy`` und ließen eine
                # Migration zu, die der Backend-Precheck dann ablehnt.
                total_legacy_bytes = await rb.attached_legacy_total_bytes()
                # Der nächste ``/migration/start`` verwirft Copy-Phase-Reste VOR seiner
                # Planung. Dieselben sicher reclaimable ``migrating``-Bytes deshalb hier
                # ebenfalls nicht als Live-Bestand zählen (#1009). Recoverbare Kopien aus
                # einem unterbrochenen Commit-Fenster sind ausdrücklich ausgeschlossen.
                live_bytes = max(0, total_size - total_legacy_bytes - reclaimable_migrating_manifest_bytes)
                target_volume = max(0, budget - headroom - live_bytes)
                estimated_copy = min(v2_estimate, target_volume)
            else:
                estimated_copy = v2_estimate
    disk_free: int | None = None
    try:
        disk_free = shutil.disk_usage(str(Path(_ringbuffer_disk_path()).parent)).free
        # Effektiv verfügbarer Platz nach demselben Cleanup, das ``/migration/start``
        # vor dem Disk-Precheck ausführt (#1009).
        disk_free += reclaimable_migrating_disk_bytes
    except OSError:
        disk_free = None
    return LegacyMigrationStatus(
        decision=decision,
        retention_protected=protected,
        legacy=legacy,
        disk_free_bytes=disk_free,
        budget_bytes=budget,
        estimated_copy_bytes=estimated_copy,
        over_budget=over_budget,
        estimated_seconds_until_budget=eta,
        job=job,
    )


async def _finalize_decision_under_lock(db: Database, rb) -> None:
    """Gleicht Decision-State und Legacy-Quelle unter dem Decision-Lock ab.

    Zwei entgegengesetzte Crash-/Kopierzustände werden serialisiert mit Admin-
    Entscheidungen repariert:

    * terminal + Legacy attached → Quelle wieder ``pending`` und geschützt,
    * non-terminal + Migration committed + keine Legacy → ``migrated``.

    Der zweite, rein nachziehende Finalizer bleibt best-effort. Beim ersten Pfad
    darf der Status dagegen keinen scheinbar reparierten Zustand liefern, wenn
    Schutz oder Persistenz fehlschlagen; der Fehler wird für einen späteren Poll
    weitergereicht.
    """
    async with _LEGACY_DECISION_LOCK:
        decision = await load_legacy_migration_decision(db)
        if decision in LEGACY_DECISIONS_TERMINAL and await rb.has_attached_legacy():
            # Schutz zuerst aktivieren: zwischen Decision-Write und Live-Reconfigure
            # darf die FIFO-Retention die gerade wiederentdeckte Quelle nicht reclaimen.
            await rb.set_legacy_retention_protected(True)
            # Kein Rollback bei Fehlschlag: Protection bleibt in jedem Fehlerfall aktiv,
            # die Legacy-Quelle ist noch angehängt; ein Rollback auf False wäre
            # datenunsicher, weil die FIFO-Retention die Quelle vor dem nächsten
            # Poll-Retry zurückgewinnen könnte. Der Fehler propagiert unverändert;
            # der nächste Poll wiederholt.
            await persist_legacy_migration_decision(db, LEGACY_DECISION_PENDING)
            return
        try:
            await finalize_committed_migration_decision(db, rb)
        except Exception:
            logger.exception("RingBuffer: Finalisierung der Migrations-Entscheidung fehlgeschlagen (Retry beim nächsten Poll)")


@router.get("/migration", response_model=LegacyMigrationStatus)
async def legacy_migration_status(
    _user: str = Depends(get_admin_user),
    db: Database = Depends(get_db),
) -> LegacyMigrationStatus:
    """Zustand des Legacy-Migrations-Assistenten inkl. Ist-Analyse (#964)."""
    rb = get_optional_ringbuffer()
    if rb is not None and is_ringbuffer_enabled():
        await _finalize_decision_under_lock(db, rb)
    return await _legacy_migration_status(db)


@router.post("/migration/decision", response_model=LegacyMigrationStatus)
@audit_application_contract("POST", "/api/v1/ringbuffer/migration/decision", principal_param="_user")
async def legacy_migration_decision(
    body: LegacyMigrationDecisionIn,
    request: Request = None,  # type: ignore[assignment]
    _user: str = Depends(get_admin_user),
    db: Database = Depends(get_db),
) -> LegacyMigrationStatus:
    """Setzt die Assistenten-Entscheidung (#964).

    * ``skip``: später entscheiden – Legacy bleibt retention-geschützt (revidierbar).
    * ``keep``: bewusst read-only behalten – der Schutz fällt, die FIFO-Retention
      darf die Legacy-Quelle als global ältestes Segment zurückgewinnen (revidierbar,
      solange die Quelle existiert).
    * ``discard``: Alt-Historie sofort und endgültig verwerfen (terminal).

    Konkurrierende Entscheidungen werden serialisiert (#968, Q0qIM): der Terminal-Check,
    die Aktion und die Persistenz laufen atomar unter ``_LEGACY_DECISION_LOCK``, sodass ein
    ``keep`` nach einem parallel durchgelaufenen ``discard`` den frisch persistierten,
    terminalen ``discarded``-Zustand sieht und mit 409 abgelehnt wird, statt ihn zu überschreiben.
    """
    async with _LEGACY_DECISION_LOCK:
        result = await _legacy_migration_decision_locked(body, db)
    await write_application_success(
        db,
        request,
        _user,
        "POST",
        "/api/v1/ringbuffer/migration/decision",
        resource_id="global",
        details={"decision": body.decision},
        commit=True,
    )
    return result


async def _legacy_migration_decision_locked(body: LegacyMigrationDecisionIn, db: Database) -> LegacyMigrationStatus:
    rb = get_optional_ringbuffer()
    if rb is not None:
        await repair_pending_keep_migration_decision(db, rb)
    current = await load_legacy_migration_decision(db)
    if current in LEGACY_DECISIONS_TERMINAL:
        raise HTTPException(status.HTTP_409_CONFLICT, f"legacy migration already finalized ({current})")
    # Keine Entscheidung, solange ein Migrationsjob laeuft (#968, Codex :2047/:2078): ein
    # ``discard`` waehrend ``starting``/``copying``/``committing`` koennte die Legacy-
    # Quelle entfernen, waehrend die Copy-Task noch laeuft und danach ``migrated``
    # persistiert. ``legacy_migration_in_progress`` deckt auch das START-FENSTER ab
    # (synchrone Reservierung vor den awaited Prechecks, Phase noch nicht ``starting``).
    if rb is not None and rb.legacy_migration_in_progress():
        raise HTTPException(status.HTTP_409_CONFLICT, "a legacy migration job is currently running")
    # Auch einen im Commit-Fenster unterbrochenen Commit abwarten (#968, Codex :2110): eine
    # schema-legacy Row mit fehlender Datei bedeutet, dass die (noch unsichtbaren) migrating-
    # Kopien die einzige Quelle sind. Ein ``keep``/``discard`` würde ihren Retention-Schutz jetzt
    # aufheben, sodass die nächste Retention die Row löscht und der Reconciler die Kopien als
    # orphan verwirft. Erst der nächste ``/migration/start`` oder Startup vollendet den Commit.
    if rb is not None and await rb.has_missing_file_legacy():
        raise HTTPException(status.HTTP_409_CONFLICT, "an interrupted legacy migration commit awaits recovery; retry after it is reconciled")
    if body.decision == "skip":
        await persist_legacy_migration_decision(db, LEGACY_DECISION_SKIPPED)
        if rb is not None:
            await rb.set_legacy_retention_protected(True)
    elif body.decision == "keep":
        # War die gespeicherte Entscheidung NON-TERMINAL (skipped/pending) und eine Migration hat bereits
        # die letzte Quelle entfernt (committed), aber die ``migrated``-Terminalisierung schlug fehl
        # (#968, Q10j-), dann ist ``committed`` + keine Legacy ein eindeutiger Beleg: die Migration ist
        # durch, nur das Bookkeeping non-terminal → direkt ``migrated`` terminalisieren (NICHT über
        # ``finalize_committed_migration_decision``, der einen keep bewusst respektiert, Q0qIJ).
        # War die gespeicherte Entscheidung dagegen BEREITS ``keep`` (#1010, RCOh6), ist derselbe Zustand
        # (``keep`` + committed + keine Legacy) MEHRDEUTIG: er entsteht sowohl aus einem gescheiterten
        # ``on_success`` ALS AUCH aus einer bewusst ge-keepten Quelle, die die Retention danach
        # zurückgewonnen hat. Wie der Finalizer nicht raten – einen bereits expliziten ``keep`` behalten.
        if rb is not None and current != LEGACY_DECISION_KEEP and await rb.has_committed_migration() and not await rb.has_attached_legacy():
            await persist_legacy_migration_decision(db, LEGACY_DECISION_MIGRATED)
        else:
            await persist_legacy_migration_decision(db, LEGACY_DECISION_KEEP)
            if rb is not None:
                await rb.set_legacy_retention_protected(False)
    else:  # discard
        # ``discard`` ist terminal UND destruktiv (entfernt die Legacy-Dateien). Läuft
        # der Monitor nicht (Singleton None/deaktiviert), würde ``discard_legacy()``
        # übersprungen, aber ``discarded`` dennoch persistiert (#968, Codex :2084): die
        # Legacy-DB bliebe auf der Platte, würde beim nächsten Start wieder attached –
        # während der Assistent wegen der terminalen Entscheidung versteckt ist. Deshalb
        # 409, bis der Monitor läuft und die Quelle wirklich gelöscht werden kann.
        if rb is None or not is_ringbuffer_enabled():
            raise HTTPException(status.HTTP_409_CONFLICT, "ringbuffer is not running; cannot discard legacy data")
        # ZUERST verwerfen, DANN den Schutz aufheben (#968, Codex :2099): würde der Schutz
        # vorher fallen und ``discard_legacy()`` danach fehlschlagen (Legacy-DB nicht
        # unlinkbar), bliebe die Entscheidung ``pending``/``skipped``, aber die ungeschützte
        # Legacy-Quelle könnte von der nächsten Retention zurückgewonnen werden, obwohl der
        # Admin nie eine terminale ``discarded``-Entscheidung erreicht hat. discard_legacy()
        # läuft unter dem Schutz; erst nach erfolgreichem Unlink fällt er.
        await rb.discard_legacy()
        # ``discarded`` nur terminal setzen + Schutz aufheben, wenn KEINE Legacy-Quelle mehr bleibt
        # (#968, Codex :1095): ``discard_legacy`` verwirft nur die angezeigte (älteste) Quelle;
        # bleiben weitere, muss der Assistent für sie sichtbar/entscheidbar bleiben.
        if not await rb.has_attached_legacy():
            await rb.set_legacy_retention_protected(False)
            await persist_legacy_migration_decision(db, LEGACY_DECISION_DISCARDED)
        else:
            # Verbleibende Quelle(n) AKTIV schützen UND eine PROTECTED non-terminale Entscheidung
            # persistieren (#968, Codex :2141/:2145): nur das in-memory-Flag zu setzen genügt nicht –
            # der Status-Endpoint und der nächste Startup lesen die Persistenz
            # (``legacy_retention_protected = decision in LEGACY_DECISIONS_PROTECTED``); eine
            # ``keep``-Entscheidung ließe die verbleibende Quelle dann ungeschützt. ``skipped`` ist
            # protected + non-terminal, sodass der Assistent für die verbleibende Quelle sichtbar und
            # geschützt bleibt.
            await rb.set_legacy_retention_protected(True)
            await persist_legacy_migration_decision(db, LEGACY_DECISION_SKIPPED)
    return await _legacy_migration_status(db)


@router.post("/migration/start", response_model=LegacyMigrationStatus)
@audit_application_contract("POST", "/api/v1/ringbuffer/migration/start", principal_param="_user")
async def legacy_migration_start(
    request: Request = None,  # type: ignore[assignment]
    _user: str = Depends(get_admin_user),
    db: Database = Depends(get_db),
) -> LegacyMigrationStatus:
    """Startet den budget-gebundenen Offline-Migrationsjob (#965).

    Läuft als Hintergrund-Task; Fortschritt über ``GET /migration`` (``job``-Feld).
    Nach erfolgreichem Commit wird die Entscheidung ``migrated`` (terminal)
    persistiert und der Retention-Schutz aufgehoben.

    Terminal-Check und Job-Reservierung laufen unter ``_LEGACY_DECISION_LOCK`` (#968, Q10j4):
    sonst könnte ein parallel laufender ``/migration/decision``-``discard``, der seinen
    Terminal-Check bereits passiert hat, dieselbe Quelle entfernen, während dieser Endpoint
    die alte non-terminale Entscheidung liest und einen Job reserviert, dessen ``on_success``
    dann ``migrated`` über das ``discarded``-Ergebnis schriebe.
    """
    async with _LEGACY_DECISION_LOCK:
        result = await _legacy_migration_start_locked(db)
    await write_application_success(
        db,
        request,
        _user,
        "POST",
        "/api/v1/ringbuffer/migration/start",
        resource_id="global",
        commit=True,
    )
    return result


async def _legacy_migration_start_locked(db: Database) -> LegacyMigrationStatus:
    from obs.ringbuffer.store.offline_migration import OfflineMigrationError

    rb = get_optional_ringbuffer()
    if rb is None or not is_ringbuffer_enabled():
        raise HTTPException(status.HTTP_409_CONFLICT, "ringbuffer is not running")
    await repair_pending_keep_migration_decision(db, rb)
    current = await load_legacy_migration_decision(db)
    if current in LEGACY_DECISIONS_TERMINAL:
        raise HTTPException(status.HTTP_409_CONFLICT, f"legacy migration already finalized ({current})")

    async def _persist_migrated() -> None:
        async with _LEGACY_DECISION_LOCK:
            # Nur terminal ``migrated``, wenn KEINE Legacy-Quelle mehr attached ist
            # (#968, Codex :441/:2142). Bei einem partial keep-Commit zieht der
            # atomare Store-Beleg stattdessen ``skipped`` + Schutz nach und wird erst
            # nach erfolgreicher App-DB-Persistenz quittiert (#1013).
            if await rb.has_attached_legacy():
                await repair_pending_keep_migration_decision(db, rb)
                return
            await persist_legacy_migration_decision(db, LEGACY_DECISION_MIGRATED)

    try:
        await rb.start_legacy_migration(
            on_success=_persist_migrated,
            started_from_keep=current == LEGACY_DECISION_KEEP,
        )
    except OfflineMigrationError as exc:
        raise HTTPException(status.HTTP_409_CONFLICT, str(exc)) from exc
    return await _legacy_migration_status(db)


@router.get("/stats", response_model=RingBufferStats)
async def ringbuffer_stats(
    _user: str = Depends(get_current_user),
    db: Database = Depends(get_db),
) -> RingBufferStats:
    rb = get_optional_ringbuffer()
    if not is_ringbuffer_enabled() or rb is None:
        return await _disabled_stats(db)
    stats = await rb.stats()
    # Persistierte Segment-Config mitgeben, damit der Config-Dialog die
    # gespeicherten Werte anzeigt (``rb.stats()`` liefert nur den Store-Snapshot).
    persisted = await load_persisted_ringbuffer_config(db, storage_path=_ringbuffer_disk_path())
    return RingBufferStats(
        enabled=True,
        segment_max_bytes=persisted.get("segment_max_bytes"),
        segment_max_rows=persisted.get("segment_max_rows"),
        segment_max_age=persisted.get("segment_max_age"),
        **_segment_contract_stats(
            max_entries=stats["max_entries"],
            max_file_size_bytes=stats["max_file_size_bytes"],
            max_age=stats["max_age"],
            segment_max_bytes=persisted.get("segment_max_bytes"),
            segment_max_rows=persisted.get("segment_max_rows"),
            segment_max_age=persisted.get("segment_max_age"),
        ),
        **stats,
    )


@router.post("/config", response_model=RingBufferStats)
@audit_application_contract("POST", "/api/v1/ringbuffer/config", principal_param="_user")
async def configure_ringbuffer(
    body: RingBufferConfig,
    request: Request,
    _user: str = Depends(get_admin_user),
    db: Database = Depends(get_db),
) -> RingBufferStats:
    if body.storage != "file":
        raise HTTPException(
            status.HTTP_422_UNPROCESSABLE_CONTENT,
            "storage must be 'file' (memory and disk are no longer supported)",
        )

    async with _CONFIGURE_LOCK:
        result = await _configure_ringbuffer_locked(body, db)
        await write_application_success(db, request, _user, "POST", "/api/v1/ringbuffer/config", commit=True)
        return result


async def _configure_ringbuffer_locked(body: RingBufferConfig, db: Database) -> RingBufferStats:
    persisted = await load_persisted_ringbuffer_config(db, storage_path=_ringbuffer_disk_path())
    requested_enabled = body.enabled if "enabled" in body.model_fields_set else is_ringbuffer_enabled()
    rb = get_optional_ringbuffer()
    current_config = await rb.stats() if rb is not None else persisted

    resolved_max_entries = body.max_entries if "max_entries" in body.model_fields_set else current_config["max_entries"]
    resolved_max_file_size = body.max_file_size_bytes if "max_file_size_bytes" in body.model_fields_set else current_config["max_file_size_bytes"]
    resolved_max_age = body.max_age if "max_age" in body.model_fields_set else current_config["max_age"]
    # Null-Retention normalisieren (#951 [P2]): ``RingBufferConfig`` erlaubt ``max_age: 0``
    # (fuer persistierte Legacy-Configs bereits zu ``None`` normalisiert, siehe
    # persisted_config.py:110 / 9278f0d8). ``StoreRetentionConfig`` lehnt die rohe 0 aber
    # ab (verlangt ``>= 1`` oder ``null``) → 422 im segmentierten Pfad. Die 0 hier vor der
    # ``StoreRetentionConfig``/``validate_store_config`` zu ``None`` (unbegrenzt) klemmen,
    # damit der Round-trip konsistent zum Persisted-Load-Pfad gelingt.
    if resolved_max_age == 0:
        resolved_max_age = None

    # Segment-Parameter (#930) leben nur in der persistierten Config, nicht im
    # laufenden RingBuffer. Bei Teil-Updates die nicht gesetzten Felder aus der
    # persistierten Config übernehmen.
    # ``segmented`` ist ein Partial-Update-Feld (Codex #951 [P2]): ``None`` (fehlend
    # ODER explizit ``null``) bedeutet "unveraendert lassen" und behaelt den
    # persistierten/deployten Wert. Nur ein EXPLIZITES ``true``/``false`` schaltet um.
    # Deshalb auf ``is not None`` pruefen statt auf ``model_fields_set`` – ein explizit
    # gesendetes ``null`` darf NICHT als ``false`` interpretiert werden und den Store
    # in den Legacy-Pfad zurueckbauen.
    # Fallback fuer ein ausgelassenes Feld ist der LAUFENDE Wert (``rb.segmented``),
    # nicht ``persisted.get(..., False)``: ein neuer Install laeuft segmentiert per
    # Default, ohne dass ``segmented`` zwingend explizit in der persistierten Config
    # steht. Ohne den Live-Fallback kippte ein Omit-Update einen solchen laufenden
    # segmentierten Store faelschlich in den Legacy-Pfad (genau der Codex-Befund).
    # Nur wenn gar kein RingBuffer laeuft, greift die persistierte Config.
    if body.segmented is not None:
        resolved_segmented = body.segmented
    elif rb is not None:
        resolved_segmented = rb.segmented
    else:
        resolved_segmented = bool(persisted.get("segmented", False))
    # Segmentierung an das aufgelöste ``storage`` koppeln (Codex #951, Pkt 1):
    # Postet ein Client eine partielle Config wie ``{"storage": "memory"}`` ohne
    # ``segmented``, bliebe sonst das persistierte/Default-``segmented=true`` erhalten.
    # ``RingBuffer.start()`` nähme dann den segmentierten Pfad, dessen Store-Root aus
    # ``disk_path`` abgeleitet wird → ein als ``memory`` konfigurierter RingBuffer
    # schriebe persistente Segment-Dateien (Widerspruch zur memory-Semantik). Löst
    # ``storage`` zu ``memory`` auf, wird die Segmentierung daher normalisiert
    # abgeschaltet; der ``file``-Pfad bleibt unverändert (segmentiert per Default).
    resolved_storage = body.storage if "storage" in body.model_fields_set else current_config.get("storage", "file")
    # Eine in-memory-DB (``storage='file'`` mit ``disk_path`` wie ``:memory:``) kann NICHT
    # segmentiert werden – ``init_ringbuffer()`` leitete sonst ein reales
    # ``:memory:_segments``-Verzeichnis auf die Platte ab (Widerspruch zur memory-Semantik).
    # Wie der Startup-Pfad (``main.py``: ``not _is_sqlite_memory_path(rb_path)``) wird die
    # Segmentierung daher IMMER abgeschaltet, auch bei explizit gepostetem ``segmented=true``
    # (#968, Codex :2221/:2470): der implizite Default überlebte sonst beim Runtime-Enable,
    # und Clients wie das Config-Modal senden ``segmented`` stets explizit, was einen reinen
    # ``body.segmented is None``-Guard umginge. Die Bounds-Validierung expliziter Segment-
    # Werte bleibt unberührt (sie hängt nicht an ``resolved_segmented``).
    if resolved_storage == "memory" or _is_sqlite_memory_path(_ringbuffer_disk_path()):
        resolved_segmented = False
    resolved_segment_max_bytes = body.segment_max_bytes if "segment_max_bytes" in body.model_fields_set else persisted.get("segment_max_bytes")
    resolved_segment_max_rows = body.segment_max_rows if "segment_max_rows" in body.model_fields_set else persisted.get("segment_max_rows")
    resolved_segment_max_age = body.segment_max_age if "segment_max_age" in body.model_fields_set else persisted.get("segment_max_age")
    effective_segment_max_bytes = (
        resolved_segment_max_bytes if resolved_segment_max_bytes is not None else derive_segment_max_bytes(resolved_max_file_size)
    )
    effective_segment_max_rows = resolved_segment_max_rows if resolved_segment_max_rows is not None else derive_segment_max_rows(resolved_max_entries)
    effective_segment_max_age = resolved_segment_max_age if resolved_segment_max_age is not None else derive_segment_max_age(resolved_max_age)

    # Technische Grenzen NUR für EXPLIZIT gesetzte Segment-Werte durchsetzen (#919):
    # 4 MiB…1 GiB / 300 s…30 d / >= 1000. Nicht gesetzte Felder (Auto-Ableitung)
    # bleiben unangetastet → kein 422 im Auto-Startpfad.
    #
    # Migrierter Sub-300s-Round-trip (Codex #951, Pkt 1): Leitete der Loader für
    # eine migrierte Config ein gültiges ``segment_max_age`` UNTER dem 300-s-Minimum
    # ab (z. B. ``max_age=600`` → ``200``), bewahrt das Config-Modal (9855a69) diesen
    # Wert und sendet ihn beim Speichern UNRELATED-Einstellungen unverändert mit. Ein
    # solcher UNVERÄNDERTER Round-trip des bereits persistierten Werts wird NICHT als
    # expliziter Nutzer-Input gegen das 300-s-Minimum geprüft (analog zur Modal-Logik,
    # die das 300-s-Minimum nur bei aktiver Nutzeränderung erzwingt). Nur ein GEÄNDERTER
    # Sub-300s-Wert läuft weiter in die 422-Ablehnung.
    checked_segment_max_age = body.segment_max_age if "segment_max_age" in body.model_fields_set else None
    if (
        checked_segment_max_age is not None
        and checked_segment_max_age < SEGMENT_MAX_AGE_MIN
        and checked_segment_max_age == persisted.get("segment_max_age")
    ):
        checked_segment_max_age = None
    try:
        validate_explicit_segment_bounds(
            segment_max_bytes=body.segment_max_bytes if "segment_max_bytes" in body.model_fields_set else None,
            segment_max_age=checked_segment_max_age,
            segment_max_rows=body.segment_max_rows if "segment_max_rows" in body.model_fields_set else None,
        )
    except ValueError as exc:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_CONTENT, str(exc)) from exc

    # Segment-/Retention-Vertrag durchsetzen: zu grobe Segmentierung → HTTP 422
    # (nicht auto-korrigieren, #930). NUR wenn der Request wirklich segmentiert
    # auflöst (#951): der dokumentierte Legacy-Pfad (``segmented=false``) besitzt
    # keine Segmente, für die die 3-Segment-Regel gälte — ein Client, der den
    # Legacy-Store mit kurzer ``max_age`` behalten will, darf hier kein 422 gegen
    # den (ungenutzten) Default-``segment_max_age`` bekommen.
    if resolved_segmented:
        if effective_segment_max_bytes is None and effective_segment_max_rows is None and effective_segment_max_age is None:
            raise HTTPException(
                status.HTTP_422_UNPROCESSABLE_CONTENT,
                "At least one effective segment rotation limit is required; configure a segment limit or a matching total retention limit",
            )
        try:
            validate_store_config(
                SegmentConfig(
                    segment_max_bytes=effective_segment_max_bytes,
                    segment_max_rows=effective_segment_max_rows,
                    segment_max_age=effective_segment_max_age,
                ),
                StoreRetentionConfig(
                    max_file_size_bytes=resolved_max_file_size,
                    max_entries=resolved_max_entries,
                    max_age=resolved_max_age,
                ),
            )
        except ValueError as exc:
            raise HTTPException(status.HTTP_422_UNPROCESSABLE_CONTENT, str(exc)) from exc

    if not requested_enabled:
        previous_enabled = is_ringbuffer_enabled()
        stopped_rb = rb
        persisted_disabled = False
        unsubscribed = False
        stopped = False
        try:
            await persist_ringbuffer_config(
                db,
                enabled=False,
                max_entries=resolved_max_entries,
                max_file_size_bytes=resolved_max_file_size,
                max_age=resolved_max_age,
                segmented=resolved_segmented,
                segment_max_bytes=resolved_segment_max_bytes,
                segment_max_rows=resolved_segment_max_rows,
                segment_max_age=resolved_segment_max_age,
            )
            persisted_disabled = True
            if stopped_rb is not None:
                _unsubscribe_ringbuffer(stopped_rb)
                unsubscribed = True
                await stopped_rb.stop()
                stopped = True
            delete_ringbuffer_storage_files(_ringbuffer_disk_path())
        except RingBufferStorageDeleteIncompleteError:
            if stopped_rb is not None:
                reset_ringbuffer()
            set_ringbuffer_enabled(False)
            raise
        except Exception:
            set_ringbuffer_enabled(previous_enabled)
            if stopped_rb is not None:
                if stopped:
                    await stopped_rb.start()
                if unsubscribed:
                    _subscribe_ringbuffer(stopped_rb)
            if persisted_disabled and previous_enabled:
                with suppress(Exception):
                    await persist_ringbuffer_config(
                        db,
                        enabled=True,
                        max_entries=resolved_max_entries,
                        max_file_size_bytes=resolved_max_file_size,
                        max_age=resolved_max_age,
                        segmented=resolved_segmented,
                        segment_max_bytes=resolved_segment_max_bytes,
                        segment_max_rows=resolved_segment_max_rows,
                        segment_max_age=resolved_segment_max_age,
                    )
            raise
        if stopped_rb is not None:
            reset_ringbuffer()
        set_ringbuffer_enabled(False)
        return await _disabled_stats(db)

    # Segmentierungs-Wechsel gegenüber der LAUFENDEN Instanz (#951): ``rb.reconfigure``
    # kennt kein ``segmented`` und ändert ``_segmented`` nicht. Liefe der Monitor
    # bereits im (unterstützten) Legacy-Modus und käme später ``segmented:true``
    # (oder umgekehrt), persistierte die API den neuen Wert, während die laufende
    # Instanz im alten Modus bliebe (Store fehlt bzw. bleibt fälschlich aktiv). Daher
    # bei erkanntem Wechsel den RingBuffer stoppen und mit der neuen Segmentierung
    # neu aufbauen — analog zum Model-Switch in ``RingBuffer.reconfigure``.
    # Rollback-sicher (#951, Pkt 2): Der alte Buffer muss abgebaut werden, bevor der
    # neue denselben Disk-Pfad öffnet. Scheitert der Neuaufbau (Segment-Root gelockt,
    # DB nicht öffenbar), darf NICHT „kein Buffer" zurückbleiben, obwohl die Config
    # schon umgestellt ist – sonst zeichnet der Monitor nichts mehr auf. Daher die
    # Config des alten Buffers festhalten, damit sie im Fehlerfall im ALTEN Modus
    # (inkl. Subscription) wiederhergestellt werden kann.
    switch_prev_config: dict[str, Any] | None = None
    if rb is not None and rb.segmented != resolved_segmented:
        switch_prev_config = {
            "storage": rb._storage,
            "max_entries": rb._max_entries,
            "max_file_size_bytes": rb._max_file_size_bytes,
            "max_age": rb._max_age,
            "segmented": rb.segmented,
            "segment_max_bytes": rb._segment_max_bytes_config,
            "segment_max_rows": rb._segment_max_rows_config,
            "segment_max_age": rb._segment_max_age_config,
            # Retention-Schutz des Legacy-Segments mitsichern (#968, Codex :2443),
            # damit ein Rollback nach fehlgeschlagenem Rebuild den Schutz nicht verliert.
            "legacy_retention_protected": rb._legacy_retention_protected,
        }
        _unsubscribe_ringbuffer(rb)
        await rb.stop()
        reset_ringbuffer()
        rb = None
        # Rebuild-Fenster deterministisch DISABLED halten (#951 [P2] "Keep ringbuffer
        # disabled during mode rebuild"): der Singleton ist ab hier ``None``, bis das
        # awaited ``init_ringbuffer()`` unten den Ersatz aufbaut. Ohne diese Zeile bliebe
        # ``_enabled`` true (``reset_ringbuffer`` setzt es sogar wieder auf true), sodass
        # nebenlaeufige query/export-Requests ``is_ringbuffer_enabled()`` → true sehen und
        # ``get_ringbuffer()`` dann mangels Buffer wirft → transiente 500s waehrend des
        # Speicherns der Config. Disabled liefern die Read-Pfade stattdessen deterministisch
        # eine leere Seite. Nach erfolgreichem Neuaufbau wird unten wieder enabled.
        set_ringbuffer_enabled(False)

    created_rb = False
    subscribed_new = False
    # Vor dem Attach merken, ob die Ringbuffer-DB bereits existierte (#968, Codex :2518/:2429):
    # ist sie pre-existing (Upgrade-Install, Monitor-Enable-aus-deaktiviert), hat ``init_ringbuffer``
    # nur eine vorhandene DB geöffnet – NICHT erstellt. Ein Rollback nach einem transienten Save-
    # Fehler darf sie dann nicht löschen (sonst irreversibler Verlust der Alt-Historie). UNABHÄNGIG
    # vom Modus (#968, Codex :2429): auch der explizite Legacy-Pfad (``segmented=false``) nutzt die
    # ``obs_ringbuffer.db`` direkt als Storage und ist gleichermaßen schützenswert. Gleiches gilt für
    # einen bereits vorhandenen Segment-Root (#968, Codex :2527): dessen retenierte v2-Historie darf
    # ein Rollback ebenso wenig entfernen.
    _rb_disk_path = _ringbuffer_disk_path()
    legacy_preexisting = Path(_rb_disk_path).exists()
    segment_root_preexisting = Path(_rb_disk_path).with_name(f"{Path(_rb_disk_path).stem}_segments").exists()
    try:
        if rb is None:
            # Migrations-Assistent (#968, Codex :2369): der Runtime-Init (Monitor-Enable
            # oder Mode-Rebuild via POST /config) muss das Decision/Protection-Setup des
            # Startups spiegeln. Sonst bliebe bei einem Upgrade, bei dem der Monitor erst
            # zur Laufzeit aktiviert wird, die Entscheidung ``None`` (Banner versteckt) und
            # die ersten non-legacy-Daten könnten die FIFO-Retention das Legacy-Segment
            # zurückgewinnen lassen, bevor der Assistent den pending/skipped-Schutz greift.
            try:
                decision = await ensure_legacy_migration_decision(
                    db,
                    legacy_db_path=_ringbuffer_disk_path() if resolved_segmented else None,
                )
            except Exception:
                # Ein transient gesperrtes app-DB-Setting darf den gesunden
                # Runtime-Buffer nicht verhindern. Konservativ geschützt starten;
                # der Finalizer unten und spätere Status-Polls wiederholen den Write.
                logger.exception("RingBuffer: Runtime-Abgleich der Legacy-Entscheidung fehlgeschlagen (Buffer startet retention-geschützt)")
                decision = LEGACY_DECISION_PENDING
            rb = await init_ringbuffer(
                storage="file",
                max_entries=resolved_max_entries,
                disk_path=_ringbuffer_disk_path(),
                max_file_size_bytes=resolved_max_file_size,
                max_age=resolved_max_age,
                segmented=resolved_segmented,
                segment_max_bytes=resolved_segment_max_bytes,
                segment_max_rows=resolved_segment_max_rows,
                segment_max_age=resolved_segment_max_age,
                legacy_retention_protected=decision in LEGACY_DECISIONS_PROTECTED,
            )
            _subscribe_ringbuffer(rb)
            subscribed_new = True
            created_rb = True
            # Ersatz-Buffer steht: Rebuild-Fenster schliessen, wieder enabled (#951 [P2]).
            # Nur im Switch-Pfad noetig (nur dort wurde oben disabled); der regulaere
            # Enable-aus-deaktiviert-Pfad setzt seinen Enable-State an anderer Stelle.
            if switch_prev_config is not None:
                set_ringbuffer_enabled(True)
            # Der Runtime-Init kann den Offline-Migrations-Reconciler laufen (Crash im
            # Commit-Fenster, Monitor erst zur Laufzeit aktiviert): dann ist der Store promotet
            # und die Legacy-Datei weg, während die Entscheidung ``pending``/``skipped`` bliebe.
            # Wie der Startup-Finalizer state-basiert nachziehen (#968, Codex :2423) – aber NACH
            # dem vollständigen Buffer-Setup (subscribed + enabled), serialisiert mit dem Decision-
            # Endpoint (#968, Q10j0) und best-effort (#968, Codex :2436): schlägt die Decision-
            # Persistenz transient fehl (app-DB locked/voll – genau der Fall, den dieser Retry-Pfad
            # behandelt), darf das den bereits laufenden Buffer NICHT abbauen (created_rb/
            # subscribed_new sind gesetzt, der except-Cleanup risse ihn sonst nieder). Der nächste
            # Status-Poll zieht die Entscheidung nach.
            try:
                await _finalize_decision_under_lock(db, rb)
            except Exception:
                logger.exception(
                    "RingBuffer: Runtime-Finalisierung der Migrations-Entscheidung fehlgeschlagen "
                    "(Buffer bleibt aktiv, Retry beim nächsten Status-Poll)"
                )

        reconfigure_kwargs: dict[str, Any] = {}
        if "max_entries" in body.model_fields_set:
            reconfigure_kwargs["max_entries"] = body.max_entries
        if "max_file_size_bytes" in body.model_fields_set:
            reconfigure_kwargs["max_file_size_bytes"] = body.max_file_size_bytes
        if "max_age" in body.model_fields_set:
            # Null-Retention (#951 [P2]): die normalisierte ``resolved_max_age`` (0 → None)
            # verwenden, damit auch der Live-Reconfigure-Pfad kein rohes 0 an
            # ``StoreRetentionConfig`` durchreicht.
            reconfigure_kwargs["max_age"] = resolved_max_age
        # Segment-Config live an den laufenden Store propagieren (#919/#938):
        # gesetzte segment_max_* werden übernommen, im segmentierten Modus wirken
        # sie sofort (Rotation/Retention/Prognose) ohne Neustart.
        if "segment_max_bytes" in body.model_fields_set:
            reconfigure_kwargs["segment_max_bytes"] = body.segment_max_bytes
        if "segment_max_rows" in body.model_fields_set:
            reconfigure_kwargs["segment_max_rows"] = body.segment_max_rows
        if "segment_max_age" in body.model_fields_set:
            reconfigure_kwargs["segment_max_age"] = body.segment_max_age
        await rb.reconfigure(body.storage, **reconfigure_kwargs)
        stats = await rb.stats()
        await persist_ringbuffer_config(
            db,
            enabled=True,
            max_entries=stats["max_entries"],
            max_file_size_bytes=stats["max_file_size_bytes"],
            max_age=stats["max_age"],
            segmented=resolved_segmented,
            segment_max_bytes=resolved_segment_max_bytes,
            segment_max_rows=resolved_segment_max_rows,
            segment_max_age=resolved_segment_max_age,
        )
    except Exception as exc:
        if created_rb and rb is not None:
            if subscribed_new:
                _unsubscribe_ringbuffer(rb)
            await rb.stop()
            reset_ringbuffer()
            set_ringbuffer_enabled(False)
            # Storage NUR löschen, wenn es KEIN Modus-Switch-Rollback ist (#951, Pkt 2):
            # Bei einem Switch teilt sich der frisch erstellte Buffer denselben
            # Disk-Pfad + Segment-Root mit dem alten Modus. ``switch_prev_config``
            # signalisiert genau diesen Fall – die Storage-Dateien tragen die
            # Historie, die der nachfolgende Rollback bewahren soll. Ein transienter
            # Save-Fehler beim Switch darf sie daher NICHT löschen. Ohne aktiven
            # Switch ist der Buffer wirklich frisch angelegt (z. B. aus dem
            # deaktivierten Zustand) und wird sauber wieder abgebaut.
            if switch_prev_config is None:
                with suppress(Exception):
                    # Pre-existing Storage NICHT löschen (#968, Codex :2518/:2527): weder die
                    # attachte Legacy-DB noch einen bereits vorhandenen Segment-Root – nur was
                    # dieser Request neu erzeugt hat. Ein transienter Save-Fehler darf keine
                    # bestehende v1-/v2-Historie irreversibel entfernen.
                    delete_ringbuffer_storage_files(
                        _ringbuffer_disk_path(),
                        keep_legacy_db=legacy_preexisting,
                        keep_segment_root=segment_root_preexisting,
                    )
        # Modus-Switch-Rebuild gescheitert (#951, Pkt 2): der alte Buffer wurde
        # bereits abgebaut. Damit immer ein funktionierender Buffer läuft, den
        # vorherigen Zustand im ALTEN Modus re-initialisieren und neu subscriben.
        if switch_prev_config is not None:
            try:
                restored = await init_ringbuffer(
                    storage=switch_prev_config["storage"],
                    max_entries=switch_prev_config["max_entries"],
                    disk_path=_ringbuffer_disk_path(),
                    max_file_size_bytes=switch_prev_config["max_file_size_bytes"],
                    max_age=switch_prev_config["max_age"],
                    segmented=switch_prev_config["segmented"],
                    segment_max_bytes=switch_prev_config["segment_max_bytes"],
                    segment_max_rows=switch_prev_config["segment_max_rows"],
                    segment_max_age=switch_prev_config["segment_max_age"],
                    # Legacy-Schutz aus dem vorherigen Zustand wiederherstellen (#968,
                    # Codex :2443): sonst defaultet ``protect_legacy`` auf false und die
                    # FIFO-Retention könnte die über-budget Legacy-Quelle löschen, bevor
                    # der Admin eine informierte Entscheidung getroffen hat.
                    legacy_retention_protected=switch_prev_config["legacy_retention_protected"],
                )
                _subscribe_ringbuffer(restored)
                set_ringbuffer_enabled(True)
            except Exception as restore_exc:
                # Auch das Restore des alten Buffers ist gescheitert (#951 [P2]:
                # "Report failed mode-switch rollbacks"). Der alte Buffer ist bereits
                # gestoppt+ge-``reset``, ein neuer konnte nicht aufgebaut werden → der
                # Store läuft jetzt DEGRADIERT (kein Buffer, deaktiviert): Recording
                # steht, Query-Endpunkte liefern disabled/500, bis ein Neustart oder ein
                # weiterer Config-Call kommt. Diesen Zustand NICHT verschlucken, sondern
                # deterministisch setzen und dem Aufrufer SICHTBAR melden – sonst sähe der
                # Betreiber nur den ursprünglichen Config-Fehler und wüsste nicht, dass der
                # Store degradiert ist.
                reset_ringbuffer()
                set_ringbuffer_enabled(False)
                logger.error(
                    "RingBuffer mode-switch rollback failed: neither the reconfigured buffer "
                    "nor the previous buffer could be restored; store is now disabled with no "
                    "active buffer (original error: %r)",
                    exc,
                    exc_info=restore_exc,
                )
                raise HTTPException(
                    status.HTTP_500_INTERNAL_SERVER_ERROR,
                    "ringbuffer mode-switch failed and rollback to the previous buffer also "
                    f"failed: the store is now disabled with no active buffer. "
                    f"config error: {exc!s}; rollback error: {restore_exc!s}",
                ) from restore_exc
        raise
    # Persistierte Segment-Config in die Response spiegeln (wie GET /stats),
    # damit das Config-Modal nach dem Speichern die GESPEICHERTEN Werte
    # hydratisiert statt auf die Defaults zurueckzufallen (#919/#938).
    return RingBufferStats(
        enabled=True,
        segment_max_bytes=resolved_segment_max_bytes,
        segment_max_rows=resolved_segment_max_rows,
        segment_max_age=resolved_segment_max_age,
        **_segment_contract_stats(
            max_entries=stats["max_entries"],
            max_file_size_bytes=stats["max_file_size_bytes"],
            max_age=stats["max_age"],
            segment_max_bytes=resolved_segment_max_bytes,
            segment_max_rows=resolved_segment_max_rows,
            segment_max_age=resolved_segment_max_age,
        ),
        **stats,
    )
