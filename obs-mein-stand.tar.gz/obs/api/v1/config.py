"""Config Backup / Restore — Phase 5 (Multi-Instance)

GET  /api/v1/config/export        → JSON-Sicherung: DataPoints + Bindings + AdapterInstances + KNX-GAs + Visu + NavLinks + AppSettings + Hierarchy
POST /api/v1/config/import        ← JSON, upsert-Semantik (existierende IDs werden aktualisiert)
POST /api/v1/config/import/db     ← SQLite-Datei hochladen und als neue Datenbank einspielen

Rückwärtskompatibel: Alter Export mit adapter_configs wird beim Import erkannt und migriert.
"""

from __future__ import annotations

import asyncio
import base64
import json
import logging
import os
import sqlite3
import tempfile
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import Literal

from fastapi import APIRouter, BackgroundTasks, Depends, File, HTTPException, Request, UploadFile, status
from fastapi.responses import FileResponse
from pydantic import BaseModel, ConfigDict, Field, field_validator

from obs.api.audit import AuditLogWriter, AuditOutcome, audit_payload_sha256, build_audit_context
from obs.api.auth import get_admin_user
from obs.api.v1.authz import _canonical_principal_id, _require_grant_targets
from obs.api.v1.bindings import (
    _ensure_webhook_slug_free,
    _ensure_webhook_target_allowed,
    _json_config,
    _validate_adapter_binding,
    _webhook_config_with_token,
)
from obs.api.v1.services.hierarchy_lifecycle import collect_hierarchy_tree_node_ids, delete_hierarchy_grants
from obs.core.formula import validate_formula
from obs.core.registry import get_registry
from obs.datetime_format import DATETIME_SETTING_KEYS, validate_datetime_setting
from obs.db.database import Database, get_db
from obs.logic.capabilities import LOGIC_CAPABILITIES, LOGIC_CREATE_CAPABILITY
from obs.logic.models import FlowData
from obs.logic.validation import validate_timer_durations
from obs.models.authz import AuthzPrincipalGrant
from obs.models.datapoint import DataPoint
from obs.regional_format import REGIONAL_SETTING_KEYS, validate_regional_setting
from obs.visu_alarms import VISU_ALARMS_KEY, parse_visu_alarms, reload_visu_alarms
from obs.visu_devices import VISU_DEVICES_KEY, parse_visu_devices

logger = logging.getLogger(__name__)


async def _reload_visu_alarms(db: Database) -> None:
    """Apply the stored Visu alarm definitions; a failure must not fail an import or reset."""
    try:
        await reload_visu_alarms(db)
    except Exception:
        logger.exception("Reloading the Visu alarms failed")


router = APIRouter(tags=["config"])

_EXPORT_VERSION = "5"


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------


class ExportedDataPoint(BaseModel):
    id: str
    name: str
    data_type: str
    unit: str | None
    tags: list[str]
    mqtt_alias: str | None
    control_class: Literal["room_local", "central_plant"] = "room_local"
    external_write_enabled: bool = False


class ExportedBinding(BaseModel):
    id: str
    datapoint_id: str
    adapter_type: str
    adapter_instance_id: str | None = None
    direction: str
    config: dict
    enabled: bool
    value_formula: str | None = None
    send_throttle_ms: int | None = None
    send_on_change: bool = False
    send_min_delta: float | None = None
    send_min_delta_pct: float | None = None


class ExportedAdapterInstance(BaseModel):
    id: str
    adapter_type: str
    name: str
    config: dict
    enabled: bool


class ExportedKnxGroupAddress(BaseModel):
    address: str
    name: str
    description: str
    dpt: str | None


# Legacy (v1 export format)
class ExportedAdapterConfig(BaseModel):
    adapter_type: str
    config: dict
    enabled: bool


def _message_binding_row(
    *,
    binding_id: str,
    direction: str,
    config: dict,
    enabled: bool,
    instance_id: str | None,
) -> dict:
    return {
        "id": binding_id,
        "direction": direction,
        "config": config,
        "enabled": enabled,
        "adapter_instance_id": instance_id,
    }


async def _validate_import_message_instance_configs(
    instances: list[ExportedAdapterInstance],
    bindings: list[ExportedBinding],
    db: Database,
) -> dict[str, str]:
    message_instances = {instance.id: instance for instance in instances if instance.adapter_type == "MESSAGE"}
    if not message_instances:
        return {}

    message_import_bindings = [binding for binding in bindings if binding.adapter_type == "MESSAGE"]
    existing_import_bindings: dict[str, dict] = {}
    for binding in message_import_bindings:
        row = await db.fetchone(
            "SELECT id, adapter_instance_id, adapter_type FROM adapter_bindings WHERE id=?",
            (binding.id,),
        )
        if row is not None and row["adapter_type"] == "MESSAGE":
            existing_import_bindings[binding.id] = row

    invalid: dict[str, str] = {}
    for instance_id, instance in message_instances.items():
        rows = await db.fetchall(
            """SELECT id, adapter_instance_id, direction, config, enabled
               FROM adapter_bindings
               WHERE adapter_instance_id=? AND adapter_type='MESSAGE'""",
            (instance_id,),
        )
        proposed = {
            row["id"]: _message_binding_row(
                binding_id=row["id"],
                direction=row["direction"],
                config=_json_config(row["config"]),
                enabled=bool(row["enabled"]),
                instance_id=row["adapter_instance_id"],
            )
            for row in rows
        }
        for binding in message_import_bindings:
            existing = existing_import_bindings.get(binding.id)
            effective_instance_id = existing["adapter_instance_id"] if existing is not None else binding.adapter_instance_id
            if effective_instance_id == instance_id:
                proposed[binding.id] = _message_binding_row(
                    binding_id=binding.id,
                    direction=binding.direction,
                    config=binding.config,
                    enabled=binding.enabled,
                    instance_id=effective_instance_id,
                )
        try:
            for binding in proposed.values():
                _validate_adapter_binding(
                    "MESSAGE",
                    binding["direction"],
                    binding["config"],
                    enabled=binding["enabled"],
                    instance_config=instance.config,
                )
        except Exception as exc:
            logger.exception(f"Binding validation for instance {instance_id} failed")
            invalid[instance_id] = str(exc)
    return invalid


class ExportedLogicGraph(BaseModel):
    id: str
    name: str
    description: str
    enabled: bool
    flow_data: dict
    control_class: Literal["room_local", "central_plant"] = "room_local"


class ExportedIcon(BaseModel):
    name: str  # Stem ohne .svg, z.B. "abacus-solid"
    content_b64: str  # base64-kodierter SVG-Inhalt


class ExportedVisuNode(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: str
    parent_id: str | None
    name: str
    type: str
    node_order: int
    icon: str | None
    access: str | None
    # Accepted only for backwards-compatible import of pre-V42 backups. The
    # legacy value may be a PIN hash, so it is discarded and never exported or
    # installed as a credential; protected pages therefore remain fail-closed.
    access_pin: str | None = Field(default=None, exclude=True)
    page_config: str | None
    users: list[str] = []

    @field_validator("access_pin", mode="before")
    @classmethod
    def _discard_legacy_access_pin(cls, _value: object) -> None:
        return None


class ExportedNavLink(BaseModel):
    id: str
    label: str
    url: str
    icon: str
    sort_order: int
    open_new_tab: bool


class ExportedAppSetting(BaseModel):
    key: str
    value: str


class ExportedHierarchyTree(BaseModel):
    id: str
    name: str
    description: str
    source: str = ""


class ExportedHierarchyNode(BaseModel):
    id: str
    tree_id: str
    parent_id: str | None
    name: str
    description: str
    node_order: int
    icon: str | None
    is_tree_root: bool = False
    """The tree's hidden root node (#1217 follow-up) — round-tripped through
    export/import so a restore doesn't turn it back into a visible folder.
    Defaults to False for older exports that predate this field."""


class ExportedHierarchyDpLink(BaseModel):
    id: str
    node_id: str
    datapoint_id: str


class ExportedAuthzGrant(BaseModel):
    principal_type: Literal["user", "api_key"]
    principal_id: str
    node_type: str
    node_id: str
    role: Literal["owner", "resident", "operator", "guest"]
    effect: Literal["allow", "deny"] = "allow"
    central_control: bool = False


class ExportedApiKeyCapabilitySet(BaseModel):
    key_id: str
    revision: int = Field(default=0, ge=0)
    capabilities: list[Literal["visu.page_config.write", "datapoint.metadata.write"]] = []


class ConfigExport(BaseModel):
    obs_version: str
    exported_at: str
    datapoints: list[ExportedDataPoint]
    bindings: list[ExportedBinding]
    adapter_instances: list[ExportedAdapterInstance] = []
    knx_group_addresses: list[ExportedKnxGroupAddress] = []
    logic_graphs: list[ExportedLogicGraph] = []
    # Legacy field (v1) — ignoriert beim Import wenn adapter_instances vorhanden
    adapter_configs: list[ExportedAdapterConfig] = []
    # Icons & FA-Key (ab Version 4)
    icons: list[ExportedIcon] = []
    fa_api_key: str | None = None
    # Visu, NavLinks, AppSettings, Hierarchy (ab Version 5)
    visu_nodes: list[ExportedVisuNode] = []
    nav_links: list[ExportedNavLink] = []
    app_settings: list[ExportedAppSetting] = []
    hierarchy_trees: list[ExportedHierarchyTree] = []
    hierarchy_nodes: list[ExportedHierarchyNode] = []
    hierarchy_dp_links: list[ExportedHierarchyDpLink] = []
    authz_grants: list[ExportedAuthzGrant] = []
    api_key_capability_sets: list[ExportedApiKeyCapabilitySet] = []


class ImportResult(BaseModel):
    datapoints_created: int
    datapoints_updated: int
    bindings_created: int
    bindings_updated: int
    adapter_instances_upserted: int
    knx_group_addresses_upserted: int
    logic_graphs_created: int
    logic_graphs_updated: int
    adapters_restarted: int
    icons_imported: int = 0
    visu_nodes_upserted: int = 0
    nav_links_upserted: int = 0
    app_settings_upserted: int = 0
    hierarchy_upserted: int = 0
    authz_grants_upserted: int = 0
    api_key_capability_sets_upserted: int = 0
    errors: list[str]


class ResetResult(BaseModel):
    datapoints_deleted: int
    bindings_deleted: int
    adapter_instances_deleted: int
    knx_group_addresses_deleted: int
    logic_graphs_deleted: int
    icons_deleted: int = 0
    visu_nodes_deleted: int = 0
    nav_links_deleted: int = 0
    hierarchy_deleted: int = 0
    errors: list[str]


class ClearResult(BaseModel):
    deleted: int
    bindings_deleted: int = 0
    errors: list[str] = []


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@router.get("/export", response_model=ConfigExport)
async def export_config(
    _user: str = Depends(get_admin_user),
    db: Database = Depends(lambda: get_db()),
) -> ConfigExport:
    reg = get_registry()
    all_dps = reg.all()

    datapoints = [
        ExportedDataPoint(
            id=str(dp.id),
            name=dp.name,
            data_type=dp.data_type,
            unit=dp.unit,
            tags=dp.tags,
            mqtt_alias=dp.mqtt_alias,
            control_class=getattr(dp, "control_class", "room_local"),
            external_write_enabled=getattr(dp, "external_write_enabled", False),
        )
        for dp in all_dps
    ]

    binding_rows = await db.fetchall("SELECT * FROM adapter_bindings ORDER BY created_at")
    bindings = [
        ExportedBinding(
            id=r["id"],
            datapoint_id=r["datapoint_id"],
            adapter_type=r["adapter_type"],
            adapter_instance_id=r["adapter_instance_id"],
            direction=r["direction"],
            config=json.loads(r["config"]),
            enabled=bool(r["enabled"]),
            value_formula=r["value_formula"],
            send_throttle_ms=r["send_throttle_ms"],
            send_on_change=bool(r["send_on_change"]),
            send_min_delta=r["send_min_delta"],
            send_min_delta_pct=r["send_min_delta_pct"],
        )
        for r in binding_rows
    ]

    instance_rows = await db.fetchall("SELECT * FROM adapter_instances ORDER BY adapter_type, name")
    adapter_instances = [
        ExportedAdapterInstance(
            id=r["id"],
            adapter_type=r["adapter_type"],
            name=r["name"],
            config=json.loads(r["config"]) if r["config"] else {},
            enabled=bool(r["enabled"]),
        )
        for r in instance_rows
    ]

    ga_rows = await db.fetchall("SELECT address, name, description, dpt FROM knx_group_addresses ORDER BY address")
    knx_group_addresses = [
        ExportedKnxGroupAddress(
            address=r["address"],
            name=r["name"],
            description=r["description"],
            dpt=r["dpt"],
        )
        for r in ga_rows
    ]

    graph_rows = await db.fetchall("SELECT * FROM logic_graphs ORDER BY name")
    logic_graphs = [
        ExportedLogicGraph(
            id=r["id"],
            name=r["name"],
            description=r["description"] or "",
            enabled=bool(r["enabled"]),
            flow_data=json.loads(r["flow_data"]) if r["flow_data"] else {"nodes": [], "edges": []},
            control_class=r["control_class"] if "control_class" in r.keys() else "room_local",  # noqa: SIM118 -- sqlite Row membership checks values
        )
        for r in graph_rows
    ]

    # Icons — alle SVG-Dateien als base64
    from obs.api.v1.icons import _icons_dir

    icons: list[ExportedIcon] = []
    try:
        for svg_file in sorted(_icons_dir().glob("*.svg")):
            try:
                icons.append(
                    ExportedIcon(
                        name=svg_file.stem,
                        content_b64=base64.b64encode(svg_file.read_bytes()).decode(),
                    ),
                )
            except OSError:
                logger.exception(f"Skipping unreadable icon {svg_file}")
    except Exception:
        logger.exception("Icon export failed — continuing export without icons")

    # FontAwesome API Key
    fa_key_row = await db.fetchone("SELECT value FROM app_settings WHERE key = 'icons.fontawesome_api_key'")
    fa_api_key = fa_key_row["value"] if fa_key_row else None

    # Visu nodes with central policy/grant assignments. PIN credentials are
    # intentionally never part of JSON configuration exports.
    visu_node_rows = await db.fetchall("SELECT * FROM visu_nodes ORDER BY node_order, created_at")
    policy_rows = await db.fetchall("SELECT node_id, access_mode FROM authz_visu_page_policies")
    node_policies = {row["node_id"]: row["access_mode"] for row in policy_rows}
    visu_node_user_rows = await db.fetchall(
        """SELECT node_id, principal_id
           FROM authz_node_roles
           WHERE principal_type='user' AND node_type='visu_page'
             AND role='guest' AND effect='allow'""",
    )
    node_users: dict[str, list[str]] = {}
    for r in visu_node_user_rows:
        node_users.setdefault(r["node_id"], []).append(r["principal_id"])

    visu_nodes = [
        ExportedVisuNode(
            id=r["id"],
            parent_id=r["parent_id"],
            name=r["name"],
            type=r["type"],
            node_order=r["node_order"],
            icon=r["icon"],
            access=node_policies.get(r["id"]),
            page_config=r["page_config"],
            users=node_users.get(r["id"], []),
        )
        for r in visu_node_rows
    ]

    # NavLinks
    nav_link_rows = await db.fetchall("SELECT * FROM nav_links ORDER BY sort_order, label")
    nav_links = [
        ExportedNavLink(
            id=r["id"],
            label=r["label"],
            url=r["url"],
            icon=r["icon"],
            sort_order=r["sort_order"],
            open_new_tab=bool(r["open_new_tab"]),
        )
        for r in nav_link_rows
    ]

    # App-Settings (alle außer FA-Key — der wird separat übergeben für Rückwärtskompatibilität)
    setting_rows = await db.fetchall("SELECT key, value FROM app_settings WHERE key != 'icons.fontawesome_api_key' ORDER BY key")
    app_settings = [ExportedAppSetting(key=r["key"], value=r["value"]) for r in setting_rows]

    # Hierarchy
    tree_rows = await db.fetchall("SELECT * FROM hierarchy_trees ORDER BY name")
    hierarchy_trees = [ExportedHierarchyTree(id=r["id"], name=r["name"], description=r["description"], source=r["source"] or "") for r in tree_rows]

    h_node_rows = await db.fetchall("SELECT * FROM hierarchy_nodes ORDER BY node_order, created_at")
    hierarchy_nodes = [
        ExportedHierarchyNode(
            id=r["id"],
            tree_id=r["tree_id"],
            parent_id=r["parent_id"],
            name=r["name"],
            description=r["description"],
            node_order=r["node_order"],
            icon=r["icon"],
            is_tree_root=bool(r["is_tree_root"]),
        )
        for r in h_node_rows
    ]

    dp_link_rows = await db.fetchall("SELECT * FROM hierarchy_datapoint_links")
    hierarchy_dp_links = [ExportedHierarchyDpLink(id=r["id"], node_id=r["node_id"], datapoint_id=r["datapoint_id"]) for r in dp_link_rows]

    logic_capabilities = sorted(LOGIC_CAPABILITIES)
    capability_placeholders = ",".join("?" for _ in logic_capabilities)
    grant_rows = await db.fetchall(
        f"""SELECT principal_type, principal_id, node_type, node_id, role, effect, central_control
            FROM authz_node_roles AS grant_row
            WHERE (node_type='hierarchy' AND EXISTS (
                       SELECT 1 FROM hierarchy_nodes WHERE id=grant_row.node_id
                   ))
               OR (node_type='datapoint' AND EXISTS (
                       SELECT 1 FROM datapoints WHERE id=grant_row.node_id
                   ))
               OR (node_type='logic_graph' AND EXISTS (
                       SELECT 1 FROM logic_graphs WHERE id=grant_row.node_id
                   ))
               OR (node_type='visu_page' AND EXISTS (
                       SELECT 1 FROM visu_nodes WHERE id=grant_row.node_id
                   ))
               OR (node_type='ringbuffer_filterset' AND EXISTS (
                       SELECT 1 FROM ringbuffer_filtersets WHERE id=grant_row.node_id
                   ))
               OR (node_type='adapter_instance' AND EXISTS (
                       SELECT 1 FROM adapter_instances WHERE id=grant_row.node_id
                   ))
               OR (node_type='logic_capability' AND node_id IN ({capability_placeholders}))
            ORDER BY principal_type, principal_id, node_type, node_id""",
        logic_capabilities,
    )
    user_rows = await db.fetchall("SELECT username FROM users")
    valid_usernames = {row["username"] for row in user_rows}
    api_key_rows = await db.fetchall("SELECT id FROM api_keys")
    valid_api_key_ids: set[str] = set()
    for row in api_key_rows:
        try:
            valid_api_key_ids.add(_canonical_principal_id("api_key", row["id"]))
        except HTTPException:
            continue

    valid_grant_rows = []
    for row in grant_rows:
        if row["principal_type"] == "user":
            if row["principal_id"] in valid_usernames:
                valid_grant_rows.append(row)
            continue
        try:
            principal_id = _canonical_principal_id("api_key", row["principal_id"])
        except HTTPException:
            continue
        if row["node_type"] == "logic_capability" and row["node_id"] == LOGIC_CREATE_CAPABILITY:
            continue
        if principal_id in valid_api_key_ids:
            valid_grant_rows.append(row)

    authz_grants = [
        ExportedAuthzGrant(
            principal_type=row["principal_type"],
            principal_id=row["principal_id"],
            node_type=row["node_type"],
            node_id=row["node_id"],
            role=row["role"],
            effect=row["effect"],
            central_control=bool(row["central_control"]) if "central_control" in row.keys() else False,  # noqa: SIM118 -- sqlite Row membership checks values
        )
        for row in valid_grant_rows
    ]

    capability_set_rows = await db.fetchall("SELECT key_id, revision FROM api_key_capability_sets ORDER BY key_id")
    capability_rows = await db.fetchall("SELECT key_id, capability FROM api_key_capabilities ORDER BY key_id, capability")
    capabilities_by_key: dict[str, list[str]] = {}
    for row in capability_rows:
        capabilities_by_key.setdefault(row["key_id"], []).append(row["capability"])
    api_key_capability_sets = [
        ExportedApiKeyCapabilitySet(
            key_id=row["key_id"],
            revision=row["revision"],
            capabilities=capabilities_by_key.get(row["key_id"], []),
        )
        for row in capability_set_rows
    ]

    return ConfigExport(
        obs_version=_EXPORT_VERSION,
        exported_at=datetime.now(UTC).isoformat(),
        datapoints=datapoints,
        bindings=bindings,
        adapter_instances=adapter_instances,
        knx_group_addresses=knx_group_addresses,
        logic_graphs=logic_graphs,
        icons=icons,
        fa_api_key=fa_api_key,
        visu_nodes=visu_nodes,
        nav_links=nav_links,
        app_settings=app_settings,
        hierarchy_trees=hierarchy_trees,
        hierarchy_nodes=hierarchy_nodes,
        hierarchy_dp_links=hierarchy_dp_links,
        authz_grants=authz_grants,
        api_key_capability_sets=api_key_capability_sets,
    )


@router.get("/export/db")
async def export_db(
    background_tasks: BackgroundTasks,
    _user: str = Depends(get_admin_user),
) -> FileResponse:
    """Erstellt eine konsistente SQLite-Sicherung via sqlite3.backup() und gibt sie als Datei zurück."""
    from obs.config import get_settings

    src_path = get_settings().database.path

    if not os.path.exists(src_path):
        raise HTTPException(status_code=404, detail="Datenbankdatei nicht gefunden.")

    with tempfile.NamedTemporaryFile(suffix=".sqlite", delete=False) as tmp:
        pass
    try:
        src = sqlite3.connect(src_path)
        dst = sqlite3.connect(tmp.name)
        src.backup(dst)
        dst.close()
        src.close()
    except Exception as exc:
        os.unlink(tmp.name)
        raise HTTPException(status_code=500, detail=f"Backup fehlgeschlagen: {exc}") from exc

    background_tasks.add_task(os.unlink, tmp.name)
    return FileResponse(
        path=tmp.name,
        media_type="application/octet-stream",
        filename="obs.sqlite",
    )


@router.post("/import/db", status_code=status.HTTP_200_OK)
async def import_db(
    request: Request = None,  # type: ignore[assignment]
    file: UploadFile = File(...),
    _admin: str = Depends(get_admin_user),
    db: Database = Depends(lambda: get_db()),
) -> dict:
    """SQLite-Datenbank aus hochgeladener Datei wiederherstellen.

    ACHTUNG: Alle aktuellen Daten werden durch den Inhalt der hochgeladenen Datei ersetzt.
    Adapter, Logik-Engine und Registry werden nach dem Restore neu gestartet.
    """
    from obs.config import get_settings

    dst_path = get_settings().database.path
    audit_context = build_audit_context(request, _admin)
    db_disconnected = False
    operation_succeeded = False

    # Hochgeladene Datei in temporäre Datei speichern
    with tempfile.NamedTemporaryFile(suffix=".sqlite", delete=False) as tmp:
        pass
    try:
        content = await file.read()
        await asyncio.to_thread(Path(tmp.name).write_bytes, content)

        # SQLite-Magic-Header prüfen (erste 16 Bytes: "SQLite format 3\000")
        if len(content) < 16 or not content.startswith(b"SQLite format 3\x00"):
            os.unlink(tmp.name)
            raise HTTPException(status_code=400, detail="Die hochgeladene Datei ist keine gültige SQLite-Datenbank.")

        # Adapter und Logic Engine stoppen
        try:
            from obs.adapters import registry as adapter_registry

            await adapter_registry.stop_all()
        except Exception:
            logger.exception("Adapter stop before DB restore failed — continuing restore anyway")

        try:
            from obs.logic.manager import get_logic_manager

            await get_logic_manager().stop()
        except Exception:
            logger.exception("Logic engine stop before DB restore failed — continuing restore anyway")

        # Keep private transactions blocked until the replacement connection
        # and its in-memory registry snapshot are consistent again.
        async with db.exclusive_lifecycle() as lifecycle:
            await lifecycle.disconnect()
            db_disconnected = True

            # Restore via sqlite3.backup()
            try:
                src_conn = sqlite3.connect(tmp.name)
                dst_conn = sqlite3.connect(dst_path)
                src_conn.backup(dst_conn)
                dst_conn.close()
                src_conn.close()
            except Exception as exc:
                raise HTTPException(status_code=500, detail=f"Datenbankwiederherstellung fehlgeschlagen: {exc}") from exc

            # Verbindung wieder aufbauen (inkl. Migrationen)
            await lifecycle.connect()
            db_disconnected = False

            # Registry neu laden
            reg = get_registry()
            reg._points.clear()
            reg._values.clear()
            await reg.load_from_db()

        # Logic Engine neu starten
        try:
            from obs.logic.manager import get_logic_manager

            logic_mgr = get_logic_manager()
            await logic_mgr.start()
        except Exception:
            logger.exception("Logic engine restart after DB restore failed")

        # Adapter neu starten
        adapters_restarted = 0
        try:
            from obs.adapters import registry as adapter_registry
            from obs.core.event_bus import get_event_bus

            event_bus = get_event_bus()
            await adapter_registry.start_all(event_bus, db)
            adapters_restarted = len(adapter_registry.get_all_instances())
        except Exception:
            logger.exception("Adapter restart after DB restore failed")

        operation_succeeded = True
        writer = AuditLogWriter(db, audit_context)
        await writer.write_contract("POST", "/api/v1/config/import/db", resource_id="global")
        return {"ok": True, "message": "Datenbankwiederherstellung erfolgreich.", "adapters_restarted": adapters_restarted}

    except Exception:
        if operation_succeeded:
            raise
        if db_disconnected:
            await db.connect()
            db_disconnected = False
        writer = AuditLogWriter(db, audit_context)
        await writer.write_contract("POST", "/api/v1/config/import/db", resource_id="global", outcome=AuditOutcome.FAILED)
        raise
    finally:
        try:
            os.unlink(tmp.name)
        except OSError:
            pass


@router.post("/import", response_model=ImportResult, status_code=status.HTTP_200_OK)
async def import_config(
    body: ConfigExport,
    _user: str = Depends(get_admin_user),
    db: Database = Depends(lambda: get_db()),
    request: Request = None,  # type: ignore[assignment]
) -> ImportResult:
    result = ImportResult(
        datapoints_created=0,
        datapoints_updated=0,
        bindings_created=0,
        bindings_updated=0,
        adapter_instances_upserted=0,
        knx_group_addresses_upserted=0,
        logic_graphs_created=0,
        logic_graphs_updated=0,
        adapters_restarted=0,
        errors=[],
    )
    reg = get_registry()
    now = datetime.now(UTC).isoformat()

    # --- DataPoints ---
    # external_write_enabled is deliberately imported as False here, regardless
    # of what the document requests: this loop runs before bindings are
    # imported below, so checking binding topology at this point would miss
    # bindings the same document is about to create — a datapoint could then
    # end up with both an enabled binding and the opt-in flag, silently
    # violating the invariant the PATCH route enforces (Codex review). Actually
    # enabling a requested opt-in is deferred to the post-bindings pass further
    # down, once the full, final topology is known.
    requested_external_write: dict[uuid.UUID, bool] = {}
    for dp_data in body.datapoints:
        try:
            dp_id = uuid.UUID(dp_data.id)
            requested_external_write[dp_id] = bool(dp_data.external_write_enabled)
            existing = reg.get(dp_id)
            if existing:
                from obs.models.datapoint import DataPointUpdate

                await reg.update(
                    dp_id,
                    DataPointUpdate(
                        name=dp_data.name,
                        data_type=dp_data.data_type,
                        unit=dp_data.unit,
                        tags=dp_data.tags,
                        mqtt_alias=dp_data.mqtt_alias,
                        control_class=dp_data.control_class,
                        external_write_enabled=False,
                    ),
                )
                result.datapoints_updated += 1
            else:
                dp = DataPoint(
                    id=dp_id,
                    name=dp_data.name,
                    data_type=dp_data.data_type,
                    unit=dp_data.unit,
                    tags=dp_data.tags,
                    mqtt_alias=dp_data.mqtt_alias,
                    control_class=dp_data.control_class,
                    external_write_enabled=False,
                )
                await db.execute_and_commit(
                    """INSERT OR IGNORE INTO datapoints
                       (id, name, data_type, unit, tags, mqtt_topic, mqtt_alias, control_class, external_write_enabled, created_at, updated_at)
                       VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
                    (
                        str(dp.id),
                        dp.name,
                        dp.data_type,
                        dp.unit,
                        json.dumps(dp.tags),
                        dp.mqtt_topic,
                        dp.mqtt_alias,
                        dp.control_class,
                        int(dp.external_write_enabled),
                        now,
                        now,
                    ),
                )
                from obs.core.registry import ValueState

                reg._points[dp_id] = dp
                reg._values[dp_id] = ValueState()
                result.datapoints_created += 1
        except Exception as exc:
            logger.exception(f"DataPoint {dp_data.id} failed")
            result.errors.append(f"DataPoint {dp_data.id}: {exc}")

    # --- Adapter Instances ---
    # Quelle: adapter_instances (v2) oder adapter_configs (v1 legacy)
    instances_to_upsert = body.adapter_instances
    if not instances_to_upsert and body.adapter_configs:
        # Legacy v1: adapter_configs → neue Instanzen mit neuer UUID
        for ac in body.adapter_configs:
            instances_to_upsert.append(
                ExportedAdapterInstance(
                    id=str(uuid.uuid4()),
                    adapter_type=ac.adapter_type,
                    name=ac.adapter_type,
                    config=ac.config,
                    enabled=ac.enabled,
                ),
            )

    invalid_message_instances = await _validate_import_message_instance_configs(instances_to_upsert, body.bindings, db)

    for ai in instances_to_upsert:
        try:
            if ai.id in invalid_message_instances:
                raise ValueError(invalid_message_instances[ai.id])
            await db.execute_and_commit(
                """INSERT INTO adapter_instances
                   (id, adapter_type, name, config, enabled, created_at, updated_at)
                   VALUES (?,?,?,?,?,?,?)
                   ON CONFLICT(id) DO UPDATE
                   SET name=excluded.name, config=excluded.config,
                       enabled=excluded.enabled, updated_at=excluded.updated_at""",
                (
                    ai.id,
                    ai.adapter_type,
                    ai.name,
                    json.dumps(ai.config),
                    int(ai.enabled),
                    now,
                    now,
                ),
            )
            result.adapter_instances_upserted += 1
        except Exception as exc:
            logger.exception(f"AdapterInstance {ai.id} failed")
            result.errors.append(f"AdapterInstance {ai.id}: {exc}")

    # --- Bindings ---
    for b_data in body.bindings:
        try:
            b_id = b_data.id
            existing_binding = await db.fetchone(
                "SELECT id, adapter_type, adapter_instance_id, config FROM adapter_bindings WHERE id=?",
                (b_id,),
            )
            effective_adapter_type = existing_binding["adapter_type"] if existing_binding is not None else b_data.adapter_type
            effective_instance_id = existing_binding["adapter_instance_id"] if existing_binding is not None else b_data.adapter_instance_id
            formula = (b_data.value_formula or "").strip() or None
            if formula:
                err = validate_formula(formula)
                if err:
                    raise ValueError(f"Ungültige Formel: {err}")
            instance_config = None
            if effective_adapter_type == "MESSAGE" and effective_instance_id:
                if effective_instance_id in invalid_message_instances:
                    raise ValueError(invalid_message_instances[effective_instance_id])
                instance_row = await db.fetchone("SELECT config FROM adapter_instances WHERE id=?", (effective_instance_id,))
                if instance_row is None:
                    raise ValueError(f"MESSAGE adapter instance not found: {effective_instance_id}")
                instance_config = _json_config(instance_row["config"])
            _validate_adapter_binding(
                effective_adapter_type,
                b_data.direction,
                b_data.config,
                enabled=b_data.enabled,
                instance_config=instance_config,
            )
            stored_config = b_data.config
            if effective_adapter_type == "WEBHOOK":
                # Store the config the way the create route would: slug trimmed and
                # lower-case (so a later create of `bell` cannot collide with an
                # imported `Bell`) and a token that is never empty. A document
                # that carries one — a backup — keeps it; one that omits it gets
                # the stored token of that binding or a fresh one, instead of an
                # endpoint that can never authenticate.
                stored_token = b_data.config.get("token") or (_json_config(existing_binding["config"]).get("token") if existing_binding else None)
                stored_config = _webhook_config_with_token(b_data.config, stored_token=stored_token or None)
                # Rows are written one by one, so a later duplicate sees the
                # earlier one. Without this both would be stored and the adapter
                # would silently drop one of the two URLs on the restart below.
                await _ensure_webhook_slug_free(db, effective_instance_id, stored_config["slug"], exclude_binding_id=b_id)
                # The create/update routes refuse a live webhook on a central_plant
                # DataPoint; an import must not be a way around that.
                if b_data.enabled:
                    _ensure_webhook_target_allowed(uuid.UUID(b_data.datapoint_id))
            if existing_binding:
                await db.execute_and_commit(
                    """UPDATE adapter_bindings
                       SET direction=?, config=?, enabled=?,
                           value_formula=?, send_throttle_ms=?, send_on_change=?,
                           send_min_delta=?, send_min_delta_pct=?,
                           updated_at=?
                       WHERE id=?""",
                    (
                        b_data.direction,
                        json.dumps(stored_config),
                        int(b_data.enabled),
                        formula,
                        b_data.send_throttle_ms,
                        int(b_data.send_on_change),
                        b_data.send_min_delta,
                        b_data.send_min_delta_pct,
                        now,
                        b_id,
                    ),
                )
                result.bindings_updated += 1
            else:
                await db.execute_and_commit(
                    """INSERT INTO adapter_bindings
                       (id, datapoint_id, adapter_type, adapter_instance_id,
                        direction, config, enabled,
                        value_formula, send_throttle_ms, send_on_change,
                        send_min_delta, send_min_delta_pct,
                        created_at, updated_at)
                       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (
                        b_id,
                        b_data.datapoint_id,
                        b_data.adapter_type,
                        b_data.adapter_instance_id,
                        b_data.direction,
                        json.dumps(stored_config),
                        int(b_data.enabled),
                        formula,
                        b_data.send_throttle_ms,
                        int(b_data.send_on_change),
                        b_data.send_min_delta,
                        b_data.send_min_delta_pct,
                        now,
                        now,
                    ),
                )
                result.bindings_created += 1
        except Exception as exc:
            logger.exception(f"Binding {b_data.id} failed")
            result.errors.append(f"Binding {b_data.id}: {exc}")

    # --- External write opt-in (post-bindings) ---
    # Deferred from the DataPoints pass above so the binding topology this
    # checks against already includes any bindings the same import document
    # just created — matches the invariant the PATCH route enforces (a
    # datapoint may only opt in while genuinely bindingless).
    if any(requested_external_write.values()):
        from obs.api.v1.datapoints import _has_write_semantic_binding
        from obs.models.datapoint import DataPointUpdate

        for dp_id, requested in requested_external_write.items():
            if not requested:
                continue
            try:
                if await _has_write_semantic_binding(db, dp_id):
                    result.errors.append(f"DataPoint {dp_id}: external_write_enabled ignored — datapoint has an adapter binding")
                    continue
                await reg.update(dp_id, DataPointUpdate(external_write_enabled=True))
            except Exception as exc:
                logger.exception(f"DataPoint {dp_id} external_write_enabled opt-in failed")
                result.errors.append(f"DataPoint {dp_id}: external_write_enabled opt-in failed: {exc}")

    # --- KNX Group Addresses ---
    for ga in body.knx_group_addresses:
        try:
            await db.execute_and_commit(
                """INSERT INTO knx_group_addresses (address, name, description, dpt)
                   VALUES (?,?,?,?)
                   ON CONFLICT(address) DO UPDATE
                   SET name=excluded.name, description=excluded.description, dpt=excluded.dpt""",
                (ga.address, ga.name, ga.description, ga.dpt),
            )
            result.knx_group_addresses_upserted += 1
        except Exception as exc:
            logger.exception(f"KNX GA {ga.address} failed")
            result.errors.append(f"KNX GA {ga.address}: {exc}")

    # --- Logic Graphs ---
    imported_graph_ids: list[str] = []
    for lg in body.logic_graphs:
        try:
            row = await db.fetchone("SELECT id FROM logic_graphs WHERE id=?", (lg.id,))
            validate_timer_durations(FlowData.model_validate(lg.flow_data))
            flow_json = json.dumps(lg.flow_data)
            if row:
                await db.execute_and_commit(
                    """UPDATE logic_graphs
                       SET name=?, description=?, enabled=?, flow_data=?, control_class=?, updated_at=?
                       WHERE id=?""",
                    (lg.name, lg.description, int(lg.enabled), flow_json, lg.control_class, now, lg.id),
                )
                result.logic_graphs_updated += 1
            else:
                await db.execute_and_commit(
                    """INSERT INTO logic_graphs
                       (id, name, description, enabled, flow_data, control_class, created_at, updated_at, created_by)
                       VALUES (?,?,?,?,?,?,?,?,?)""",
                    (
                        lg.id,
                        lg.name,
                        lg.description,
                        int(lg.enabled),
                        flow_json,
                        lg.control_class,
                        now,
                        now,
                        _user,
                    ),
                )
                result.logic_graphs_created += 1
            # Duplicate ids collapse to one row — initialize each id once
            if lg.id not in imported_graph_ids:
                imported_graph_ids.append(lg.id)
        except Exception as exc:
            logger.exception(f"LogicGraph {lg.id} failed")
            result.errors.append(f"LogicGraph {lg.id}: {exc}")

    if body.logic_graphs:
        try:
            from obs.logic.manager import get_logic_manager

            manager = get_logic_manager()
            # The imported sheet carries no node state: drop the cached graph
            # plus all in-memory and persisted node state of the upserted
            # graphs, so neither stale read/write-filter state nor old
            # hysteresis/accumulator state of a reused graph id leaks into
            # the restored sheet.
            for graph_id in imported_graph_ids:
                manager.invalidate_cache(graph_id)
                await manager.reset_node_state(graph_id)
            await manager.reload()
        except Exception as exc:
            logger.exception("Logic manager reload failed")
            result.errors.append(f"Logic manager reload: {exc}")

    # Restart all adapter instances so they pick up new configs and bindings
    try:
        from obs.adapters import registry as adapter_registry
        from obs.core.event_bus import get_event_bus

        event_bus = get_event_bus()
        await adapter_registry.stop_all()
        await adapter_registry.start_all(event_bus, db)
        result.adapters_restarted = len(adapter_registry.get_all_instances())
    except Exception as exc:
        logger.exception("Adapter restart failed")
        result.errors.append(f"Adapter restart failed: {exc}")

    # --- FontAwesome API Key ---
    if body.fa_api_key:
        try:
            await db.execute_and_commit(
                "INSERT OR REPLACE INTO app_settings (key, value) VALUES (?, ?)",
                ("icons.fontawesome_api_key", body.fa_api_key),
            )
        except Exception as exc:
            logger.exception("FA API Key import failed")
            result.errors.append(f"FA API Key import failed: {exc}")

    # --- Icons ---
    if body.icons:
        from obs.api.v1.icons import _icons_dir, _safe_name, _sanitize_svg

        icons_dir = _icons_dir()
        for icon in body.icons:
            try:
                raw = base64.b64decode(icon.content_b64)
                sanitized = _sanitize_svg(raw)
                if sanitized is None:
                    result.errors.append(f"Icon '{icon.name}': kein gültiges/sicheres SVG, übersprungen")
                    continue
                safe = _safe_name(f"{icon.name}.svg")
                if not safe:
                    result.errors.append(f"Icon '{icon.name}': ungültiger Name, übersprungen")
                    continue
                (icons_dir / f"{safe}.svg").write_bytes(sanitized)
                result.icons_imported += 1
            except Exception as exc:
                logger.exception(f"Icon '{icon.name}' failed")
                result.errors.append(f"Icon '{icon.name}': {exc}")

    # --- Visu Nodes (topologisch sortiert: Eltern vor Kindern) ---
    if body.visu_nodes:
        inserted_ids: set[str] = set()
        remaining = list(body.visu_nodes)

        # Vorhandene IDs als bereits eingefügt markieren (damit parent_id-Referenzen korrekt aufgelöst werden)
        existing_rows = await db.fetchall("SELECT id FROM visu_nodes")
        for r in existing_rows:
            inserted_ids.add(r["id"])

        for _pass in range(len(remaining) + 1):
            if not remaining:
                break
            next_remaining = []
            for node in remaining:
                if node.parent_id is None or node.parent_id in inserted_ids:
                    try:
                        await db.execute_and_commit(
                            """INSERT INTO visu_nodes
                               (id, parent_id, name, type, node_order, icon, page_config, created_at, updated_at, created_by)
                               VALUES (?,?,?,?,?,?,?,?,?,?)
                               ON CONFLICT(id) DO UPDATE
                               SET parent_id=excluded.parent_id, name=excluded.name, type=excluded.type,
                                   node_order=excluded.node_order, icon=excluded.icon,
                                   page_config=excluded.page_config, updated_at=excluded.updated_at""",
                            (
                                node.id,
                                node.parent_id,
                                node.name,
                                node.type,
                                node.node_order,
                                node.icon,
                                node.page_config,
                                now,
                                now,
                                _user if node.type == "PAGE" else None,
                            ),
                        )
                        inserted_ids.add(node.id)
                        result.visu_nodes_upserted += 1

                        await db.execute_and_commit("DELETE FROM authz_visu_page_policies WHERE node_id=?", (node.id,))
                        if node.access is not None:
                            await db.execute_and_commit(
                                "INSERT INTO authz_visu_page_policies (node_id, access_mode) VALUES (?, ?)",
                                (node.id, node.access),
                            )

                        # Central user grants replace the old per-page assignment table.
                        await db.execute_and_commit(
                            """DELETE FROM authz_node_roles
                               WHERE principal_type='user' AND node_type='visu_page' AND node_id=?
                                 AND role='guest' AND effect='allow'""",
                            (node.id,),
                        )
                        if node.users and node.access == "user":
                            for username in node.users:
                                user = await db.fetchone("SELECT is_admin FROM users WHERE username=?", (username,))
                                if user and not bool(user["is_admin"]):
                                    await db.execute_and_commit(
                                        """INSERT OR IGNORE INTO authz_node_roles
                                               (principal_type, principal_id, node_type, node_id, role, effect)
                                           VALUES ('user', ?, 'visu_page', ?, 'guest', 'allow')""",
                                        (username, node.id),
                                    )
                    except Exception as exc:
                        logger.exception(f"VisuNode {node.id} failed")
                        result.errors.append(f"VisuNode {node.id}: {exc}")
                        inserted_ids.add(node.id)
                else:
                    next_remaining.append(node)
            remaining = next_remaining

        for node in remaining:
            result.errors.append(f"VisuNode {node.id}: parent_id '{node.parent_id}' nicht gefunden, übersprungen")

    # --- NavLinks ---
    for nl in body.nav_links:
        try:
            await db.execute_and_commit(
                """INSERT INTO nav_links (id, label, url, icon, sort_order, open_new_tab, created_at)
                   VALUES (?,?,?,?,?,?,?)
                   ON CONFLICT(id) DO UPDATE
                   SET label=excluded.label, url=excluded.url, icon=excluded.icon,
                       sort_order=excluded.sort_order, open_new_tab=excluded.open_new_tab""",
                (nl.id, nl.label, nl.url, nl.icon, nl.sort_order, int(nl.open_new_tab), now),
            )
            result.nav_links_upserted += 1
        except Exception as exc:
            logger.exception(f"NavLink {nl.id} failed")
            result.errors.append(f"NavLink {nl.id}: {exc}")

    # --- App Settings ---
    # Display settings are validated on the way in exactly as PUT /system/settings
    # does: an unchecked region_format or currency from a hand-edited backup would
    # otherwise reach the frontends, where Intl rejects it (issue #1073).
    imported_datetime_settings: dict[str, str] = {}
    for s in body.app_settings:
        try:
            if s.key in DATETIME_SETTING_KEYS:
                validate_datetime_setting(s.key, s.value)
            elif s.key in REGIONAL_SETTING_KEYS:
                validate_regional_setting(s.key, s.value)
            elif s.key == VISU_DEVICES_KEY:
                parse_visu_devices(s.value)
            elif s.key == VISU_ALARMS_KEY:
                parse_visu_alarms(s.value)
            await db.execute_and_commit(
                "INSERT OR REPLACE INTO app_settings (key, value) VALUES (?,?)",
                (s.key, s.value),
            )
            result.app_settings_upserted += 1
            if s.key in DATETIME_SETTING_KEYS or s.key in REGIONAL_SETTING_KEYS:
                imported_datetime_settings[s.key] = s.value
        except Exception as exc:
            logger.exception(f"AppSetting {s.key} failed")
            result.errors.append(f"AppSetting {s.key}: {exc}")

    # Imported alarm definitions take effect right away (nothing is raised by the import).
    await _reload_visu_alarms(db)

    # Apply imported date/time settings immediately. Logic graphs may already
    # have been reloaded above, but their executor receives this hot
    # configuration on the next evaluation.
    if imported_datetime_settings:
        try:
            from obs.logic.manager import get_logic_manager

            get_logic_manager().update_app_config(imported_datetime_settings)
        except RuntimeError:
            pass  # Manager may not be running — non-critical

    # Seed Read Object nodes of the restored graphs with the current registry
    # values (issue #1031) — after the adapter restart, so the WriteRouter can
    # resolve newly imported adapter instances for the published writes, and
    # after the app-settings import, so timezone-dependent nodes evaluate
    # with the restored configuration. Only successfully upserted graphs
    # qualify — a failed entry reusing an existing graph id must not
    # re-initialize the old graph. The bulk pass suppresses cascades between
    # the restored graphs so each one initializes exactly once.
    if imported_graph_ids:
        try:
            from obs.logic.manager import get_logic_manager

            await get_logic_manager().initialize_graphs(imported_graph_ids)
        except Exception as exc:
            logger.exception("Logic graph initialization failed")
            result.errors.append(f"Logic graph initialization: {exc}")

    # --- Hierarchy Trees ---
    for ht in body.hierarchy_trees:
        try:
            await db.execute_and_commit(
                """INSERT INTO hierarchy_trees (id, name, description, source, created_at, updated_at)
                   VALUES (?,?,?,?,?,?)
                   ON CONFLICT(id) DO UPDATE
                   SET name=excluded.name, description=excluded.description, source=excluded.source, updated_at=excluded.updated_at""",
                (ht.id, ht.name, ht.description, ht.source, now, now),
            )
            result.hierarchy_upserted += 1
        except Exception as exc:
            logger.exception(f"HierarchyTree {ht.id} failed")
            result.errors.append(f"HierarchyTree {ht.id}: {exc}")

    # --- Hierarchy Nodes (topologisch sortiert) ---
    if body.hierarchy_nodes:
        inserted_h_ids: set[str] = set()
        existing_h = await db.fetchall("SELECT id FROM hierarchy_nodes")
        for r in existing_h:
            inserted_h_ids.add(r["id"])

        remaining_h = list(body.hierarchy_nodes)
        for _pass in range(len(remaining_h) + 1):
            if not remaining_h:
                break
            next_remaining_h = []
            for hn in remaining_h:
                if hn.parent_id is None or hn.parent_id in inserted_h_ids:
                    try:
                        await db.execute_and_commit(
                            """INSERT INTO hierarchy_nodes
                               (id, tree_id, parent_id, name, description, node_order, icon, is_tree_root, created_at, updated_at)
                               VALUES (?,?,?,?,?,?,?,?,?,?)
                               ON CONFLICT(id) DO UPDATE
                               SET tree_id=excluded.tree_id, parent_id=excluded.parent_id, name=excluded.name,
                                   description=excluded.description, node_order=excluded.node_order,
                                   icon=excluded.icon, is_tree_root=excluded.is_tree_root, updated_at=excluded.updated_at""",
                            (hn.id, hn.tree_id, hn.parent_id, hn.name, hn.description, hn.node_order, hn.icon, int(hn.is_tree_root), now, now),
                        )
                        inserted_h_ids.add(hn.id)
                        result.hierarchy_upserted += 1
                    except Exception as exc:
                        logger.exception(f"HierarchyNode {hn.id} failed")
                        result.errors.append(f"HierarchyNode {hn.id}: {exc}")
                        inserted_h_ids.add(hn.id)
                else:
                    next_remaining_h.append(hn)
            remaining_h = next_remaining_h

    # A backup taken before #1217's tree-root-node feature (or a synthetic
    # partial import missing hierarchy_nodes) may restore hierarchy_trees rows
    # with no is_tree_root=1 node — backfill any still missing one, same as
    # _migration_v54_hierarchy_tree_root_nodes. Runs after the node import
    # loop above so a root node actually included in the import is correctly
    # recognized here and never duplicated.
    for ht in body.hierarchy_trees:
        existing_root = await db.fetchone("SELECT id FROM hierarchy_nodes WHERE tree_id=? AND is_tree_root=1", (ht.id,))
        if existing_root:
            continue
        try:
            await db.execute_and_commit(
                """INSERT INTO hierarchy_nodes
                       (id, tree_id, parent_id, name, description, node_order, icon, is_tree_root, created_at, updated_at)
                   VALUES (?,?,NULL,?,'',-1,NULL,1,?,?)""",
                (str(uuid.uuid4()), ht.id, ht.name, now, now),
            )
        except Exception as exc:
            logger.exception(f"HierarchyTree {ht.id} root node backfill failed")
            result.errors.append(f"HierarchyTree {ht.id} root node: {exc}")

    # --- Hierarchy DataPoint Links ---
    for link in body.hierarchy_dp_links:
        try:
            await db.execute_and_commit(
                """INSERT OR IGNORE INTO hierarchy_datapoint_links (id, node_id, datapoint_id, created_at)
                   VALUES (?,?,?,?)""",
                (link.id, link.node_id, link.datapoint_id, now),
            )
            result.hierarchy_upserted += 1
        except Exception as exc:
            logger.exception(f"HierarchyDpLink {link.id} failed")
            result.errors.append(f"HierarchyDpLink {link.id}: {exc}")

    # --- Central authorization grants ---
    for grant in body.authz_grants:
        try:
            async with db.transaction():
                principal_id = _canonical_principal_id(grant.principal_type, grant.principal_id)
                principal_table = "users" if grant.principal_type == "user" else "api_keys"
                principal_column = "username" if grant.principal_type == "user" else "id"
                principal = await db.fetchone(
                    f"SELECT 1 FROM {principal_table} WHERE {principal_column}=?",
                    (principal_id,),
                )
                if principal is None:
                    raise ValueError(f"principal {grant.principal_type}:{principal_id} does not exist")
                target = AuthzPrincipalGrant(
                    node_type=grant.node_type,
                    node_id=grant.node_id,
                    role=grant.role,
                    effect=grant.effect,
                    central_control=grant.central_control,
                )
                if grant.principal_type == "api_key" and grant.node_type == "logic_capability" and grant.node_id == LOGIC_CREATE_CAPABILITY:
                    raise ValueError("Logic graph creation can only be granted to users")
                await _require_grant_targets(db, [target])
                await db.execute(
                    """INSERT INTO authz_node_roles
                           (principal_type, principal_id, node_type, node_id, role, effect, central_control)
                       VALUES (?, ?, ?, ?, ?, ?, ?)
                       ON CONFLICT(principal_type, principal_id, node_type, node_id) DO UPDATE
                       SET role=excluded.role, effect=excluded.effect, central_control=excluded.central_control,
                           updated_at=strftime('%Y-%m-%dT%H:%M:%fZ', 'now')""",
                    (
                        grant.principal_type,
                        principal_id,
                        grant.node_type,
                        grant.node_id,
                        grant.role,
                        grant.effect,
                        int(grant.central_control),
                    ),
                )
            result.authz_grants_upserted += 1
        except Exception as exc:  # noqa: BLE001 -- config import records per-item failures and continues
            result.errors.append(f"AuthzGrant {grant.principal_type}:{grant.principal_id}/{grant.node_type}:{grant.node_id}: {exc}")

    # --- API-key configuration capability sets ---
    for capability_set in body.api_key_capability_sets:
        try:
            key = await db.fetchone("SELECT 1 FROM api_keys WHERE id=?", (capability_set.key_id,))
            if key is None:
                raise ValueError(f"API key {capability_set.key_id} does not exist")
            async with db.transaction():
                await db.execute("DELETE FROM api_key_capabilities WHERE key_id=?", (capability_set.key_id,))
                await db.executemany(
                    "INSERT INTO api_key_capabilities (key_id, capability) VALUES (?, ?)",
                    [(capability_set.key_id, capability) for capability in capability_set.capabilities],
                )
                await db.execute(
                    """INSERT INTO api_key_capability_sets (key_id, revision, updated_at)
                       VALUES (?, ?, strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
                       ON CONFLICT(key_id) DO UPDATE
                       SET revision=excluded.revision, updated_at=excluded.updated_at""",
                    (capability_set.key_id, capability_set.revision),
                )
            result.api_key_capability_sets_upserted += 1
        except Exception as exc:  # noqa: BLE001 -- config import records per-item failures and continues
            result.errors.append(f"ApiKeyCapabilitySet {capability_set.key_id}: {exc}")

    if request is not None:
        writer = AuditLogWriter(db, build_audit_context(request, _user))
        outcome = AuditOutcome.FAILED if result.errors else AuditOutcome.SUCCESS
        result_data = result.model_dump()
        counts = {key: value for key, value in result_data.items() if key != "errors"}
        await writer.write_contract(
            "POST",
            "/api/v1/config/import",
            resource_id="global",
            outcome=outcome,
            details={
                "counts": counts,
                "error_count": len(result.errors),
                "payload_sha256": audit_payload_sha256(counts),
            },
        )
    return result


@router.delete("/reset", response_model=ResetResult, status_code=status.HTTP_200_OK)
async def factory_reset(
    request: Request = None,  # type: ignore[assignment]
    _admin: str = Depends(get_admin_user),
    db: Database = Depends(lambda: get_db()),
) -> ResetResult:
    """Factory reset — deletes ALL data. Admin only."""
    result = ResetResult(
        datapoints_deleted=0,
        bindings_deleted=0,
        adapter_instances_deleted=0,
        knx_group_addresses_deleted=0,
        logic_graphs_deleted=0,
        errors=[],
    )

    try:
        from obs.adapters import registry as adapter_registry

        await adapter_registry.stop_all()
    except Exception as exc:
        logger.exception("Adapter stop failed")
        result.errors.append(f"Adapter stop failed: {exc}")

    try:
        row = await db.fetchone("SELECT COUNT(*) as n FROM logic_graphs")
        result.logic_graphs_deleted = row["n"] if row else 0
        async with db.transaction():
            await db.execute("DELETE FROM authz_node_roles WHERE node_type='logic_graph'")
            await db.execute("DELETE FROM logic_graphs")
        from obs.logic.manager import get_logic_manager

        await get_logic_manager().reload()
    except Exception as exc:
        logger.exception("Logic graphs reset failed")
        result.errors.append(f"Logic graphs reset failed: {exc}")

    try:
        row = await db.fetchone("SELECT COUNT(*) as n FROM adapter_bindings")
        result.bindings_deleted = row["n"] if row else 0
        row = await db.fetchone("SELECT COUNT(*) as n FROM datapoints")
        result.datapoints_deleted = row["n"] if row else 0
        row = await db.fetchone("SELECT COUNT(*) as n FROM adapter_instances")
        result.adapter_instances_deleted = row["n"] if row else 0
        async with db.transaction():
            await db.execute("DELETE FROM adapter_bindings")
            await db.execute("DELETE FROM authz_node_roles WHERE node_type='datapoint'")
            await db.execute("DELETE FROM authz_node_roles WHERE node_type='adapter_instance'")
            await db.execute("DELETE FROM adapter_instances")
            await db.execute("DELETE FROM datapoints")
        reg = get_registry()
        reg._points.clear()
        reg._values.clear()
    except Exception as exc:
        logger.exception("DataPoints and adapters reset failed")
        result.errors.append(f"DataPoints and adapters reset failed: {exc}")

    try:
        for table in ("knx_space_device_links", "knx_co_ga_links", "knx_comm_objects", "knx_devices"):
            await db.execute_and_commit(f"DELETE FROM {table}")
        row = await db.fetchone("SELECT COUNT(*) as n FROM knx_group_addresses")
        result.knx_group_addresses_deleted = row["n"] if row else 0
        await db.execute_and_commit("DELETE FROM knx_group_addresses")
    except Exception as exc:
        logger.exception("KNX group addresses reset failed")
        result.errors.append(f"KNX group addresses reset failed: {exc}")

    # Visu-Nodes löschen (Kinder werden durch CASCADE automatisch gelöscht)
    try:
        row = await db.fetchone("SELECT COUNT(*) as n FROM visu_nodes")
        result.visu_nodes_deleted = row["n"] if row else 0
        async with db.transaction():
            await db.execute("DELETE FROM authz_node_roles WHERE node_type='visu_page'")
            await db.execute("DELETE FROM visu_nodes WHERE parent_id IS NULL")
    except Exception as exc:
        logger.exception("Visu nodes reset failed")
        result.errors.append(f"Visu nodes reset failed: {exc}")

    # NavLinks löschen
    try:
        row = await db.fetchone("SELECT COUNT(*) as n FROM nav_links")
        result.nav_links_deleted = row["n"] if row else 0
        await db.execute_and_commit("DELETE FROM nav_links")
    except Exception as exc:
        logger.exception("NavLinks reset failed")
        result.errors.append(f"NavLinks reset failed: {exc}")

    # Hierarchy löschen
    try:
        row = await db.fetchone("SELECT COUNT(*) as n FROM hierarchy_trees")
        result.hierarchy_deleted = row["n"] if row else 0
        async with db.transaction():
            tree_rows = await db.fetchall("SELECT id FROM hierarchy_trees")
            tree_ids = [tree_row["id"] for tree_row in tree_rows]
            node_ids = await collect_hierarchy_tree_node_ids(db, tree_ids)
            await delete_hierarchy_grants(db, node_ids)
            await db.execute("DELETE FROM authz_node_roles WHERE node_type='hierarchy'")
            await db.execute("DELETE FROM hierarchy_trees")
    except Exception as exc:
        logger.exception("Hierarchy reset failed")
        result.errors.append(f"Hierarchy reset failed: {exc}")

    # App-Settings zurücksetzen (Autobackup-Einstellungen behalten, Standard-Timezone wiederherstellen)
    try:
        await db.execute_and_commit("DELETE FROM app_settings WHERE key NOT LIKE 'autobackup.%'")
        await db.execute_and_commit("INSERT OR IGNORE INTO app_settings (key, value) VALUES ('timezone', 'Europe/Zurich')")
        await db.execute_and_commit("INSERT OR IGNORE INTO app_settings (key, value) VALUES ('date_format', 'dd.MM.yyyy')")
        await db.execute_and_commit("INSERT OR IGNORE INTO app_settings (key, value) VALUES ('time_format', 'HH:mm:ss')")
        await db.execute_and_commit("INSERT OR IGNORE INTO app_settings (key, value) VALUES ('language', 'de')")
        await db.execute_and_commit("INSERT OR IGNORE INTO app_settings (key, value) VALUES ('region_format', 'auto')")
        await db.execute_and_commit("INSERT OR IGNORE INTO app_settings (key, value) VALUES ('currency', 'auto')")
        await _reload_visu_alarms(db)
        from obs.logic.manager import get_logic_manager

        get_logic_manager().update_app_config(
            {
                "timezone": "Europe/Zurich",
                "date_format": "dd.MM.yyyy",
                "time_format": "HH:mm:ss",
                "language": "de",
                "region_format": "auto",
                "currency": "auto",
            }
        )
    except Exception as exc:
        logger.exception("App settings reset failed")
        result.errors.append(f"App settings reset failed: {exc}")

    # Icons (SVG-Dateien) löschen
    try:
        from obs.api.v1.icons import _icons_dir

        icons_dir = _icons_dir()
        for svg_file in list(icons_dir.glob("*.svg")):
            svg_file.unlink()
            result.icons_deleted += 1
    except Exception as exc:
        logger.exception("Icons reset failed")
        result.errors.append(f"Icons reset failed: {exc}")

    writer = AuditLogWriter(db, build_audit_context(request, _admin))
    outcome = AuditOutcome.FAILED if result.errors else AuditOutcome.SUCCESS
    result_data = result.model_dump()
    await writer.write_contract(
        "DELETE",
        "/api/v1/config/reset",
        resource_id="global",
        outcome=outcome,
        details={"counts": {key: value for key, value in result_data.items() if key != "errors"}, "error_count": len(result.errors)},
    )
    return result


@router.delete("/reset/bindings", response_model=ClearResult, status_code=status.HTTP_200_OK)
async def clear_bindings(
    request: Request = None,  # type: ignore[assignment]
    _admin: str = Depends(get_admin_user),
    db: Database = Depends(lambda: get_db()),
) -> ClearResult:
    """Delete all Bindings and restart adapters so they pick up empty binding list. Admin only."""
    result = ClearResult(deleted=0)
    try:
        from obs.adapters import registry as adapter_registry
        from obs.core.event_bus import get_event_bus

        await adapter_registry.stop_all()
        row = await db.fetchone("SELECT COUNT(*) as n FROM adapter_bindings")
        result.deleted = row["n"] if row else 0
        await db.execute_and_commit("DELETE FROM adapter_bindings")
        await adapter_registry.start_all(get_event_bus(), db)
    except Exception as exc:
        logger.exception("Bindings clear failed")
        result.errors.append(f"Bindings clear failed: {exc}")
    writer = AuditLogWriter(db, build_audit_context(request, _admin))
    outcome = AuditOutcome.FAILED if result.errors else AuditOutcome.SUCCESS
    await writer.write_contract(
        "DELETE",
        "/api/v1/config/reset/bindings",
        resource_id="global",
        outcome=outcome,
        details={"counts": {"deleted": result.deleted}, "error_count": len(result.errors)},
    )
    return result


@router.delete("/reset/datapoints", response_model=ClearResult, status_code=status.HTTP_200_OK)
async def clear_datapoints(
    request: Request = None,  # type: ignore[assignment]
    _admin: str = Depends(get_admin_user),
    db: Database = Depends(lambda: get_db()),
) -> ClearResult:
    """Delete all DataPoints and their Bindings. Admin only."""
    result = ClearResult(deleted=0, bindings_deleted=0)
    try:
        from obs.adapters import registry as adapter_registry
        from obs.core.event_bus import get_event_bus

        await adapter_registry.stop_all()
        row = await db.fetchone("SELECT COUNT(*) as n FROM adapter_bindings")
        result.bindings_deleted = row["n"] if row else 0
        row = await db.fetchone("SELECT COUNT(*) as n FROM datapoints")
        result.deleted = row["n"] if row else 0
        async with db.transaction():
            await db.execute("DELETE FROM adapter_bindings")
            await db.execute("DELETE FROM authz_node_roles WHERE node_type='datapoint'")
            await db.execute("DELETE FROM datapoints")
        reg = get_registry()
        reg._points.clear()
        reg._values.clear()
        await adapter_registry.start_all(get_event_bus(), db)
    except Exception as exc:
        logger.exception("DataPoints clear failed")
        result.errors.append(f"DataPoints clear failed: {exc}")
    writer = AuditLogWriter(db, build_audit_context(request, _admin))
    outcome = AuditOutcome.FAILED if result.errors else AuditOutcome.SUCCESS
    await writer.write_contract(
        "DELETE",
        "/api/v1/config/reset/datapoints",
        resource_id="global",
        outcome=outcome,
        details={"counts": {"deleted": result.deleted, "bindings_deleted": result.bindings_deleted}, "error_count": len(result.errors)},
    )
    return result


@router.delete("/reset/logic", response_model=ClearResult, status_code=status.HTTP_200_OK)
async def clear_logic(
    request: Request = None,  # type: ignore[assignment]
    _admin: str = Depends(get_admin_user),
    db: Database = Depends(lambda: get_db()),
) -> ClearResult:
    """Delete all Logic Graphs. Admin only."""
    result = ClearResult(deleted=0)
    try:
        row = await db.fetchone("SELECT COUNT(*) as n FROM logic_graphs")
        result.deleted = row["n"] if row else 0
        async with db.transaction():
            await db.execute("DELETE FROM authz_node_roles WHERE node_type='logic_graph'")
            await db.execute("DELETE FROM logic_graphs")
        from obs.logic.manager import get_logic_manager

        await get_logic_manager().reload()
    except Exception as exc:
        logger.exception("Logic graphs clear failed")
        result.errors.append(f"Logic graphs clear failed: {exc}")
    writer = AuditLogWriter(db, build_audit_context(request, _admin))
    outcome = AuditOutcome.FAILED if result.errors else AuditOutcome.SUCCESS
    await writer.write_contract(
        "DELETE",
        "/api/v1/config/reset/logic",
        resource_id="global",
        outcome=outcome,
        details={"counts": {"deleted": result.deleted}, "error_count": len(result.errors)},
    )
    return result


@router.delete("/reset/adapters", response_model=ClearResult, status_code=status.HTTP_200_OK)
async def clear_adapters(
    request: Request = None,  # type: ignore[assignment]
    _admin: str = Depends(get_admin_user),
    db: Database = Depends(lambda: get_db()),
) -> ClearResult:
    """Stop and delete all Adapter Instances and their Bindings. Admin only."""
    result = ClearResult(deleted=0, bindings_deleted=0)
    try:
        from obs.adapters import registry as adapter_registry

        await adapter_registry.stop_all()
        row = await db.fetchone("SELECT COUNT(*) as n FROM adapter_bindings")
        result.bindings_deleted = row["n"] if row else 0
        row = await db.fetchone("SELECT COUNT(*) as n FROM adapter_instances")
        result.deleted = row["n"] if row else 0
        async with db.transaction():
            await db.execute("DELETE FROM adapter_bindings")
            await db.execute("DELETE FROM authz_node_roles WHERE node_type='adapter_instance'")
            await db.execute("DELETE FROM adapter_instances")
    except Exception as exc:
        logger.exception("Adapters clear failed")
        result.errors.append(f"Adapters clear failed: {exc}")
    writer = AuditLogWriter(db, build_audit_context(request, _admin))
    outcome = AuditOutcome.FAILED if result.errors else AuditOutcome.SUCCESS
    await writer.write_contract(
        "DELETE",
        "/api/v1/config/reset/adapters",
        resource_id="global",
        outcome=outcome,
        details={"counts": {"deleted": result.deleted, "bindings_deleted": result.bindings_deleted}, "error_count": len(result.errors)},
    )
    return result
