"""MESSAGE adapter.

Observes DataValueEvent updates and sends notifications through provider
plugins when a per-binding value condition is fulfilled.
"""

from __future__ import annotations

import asyncio
import html
import logging
import re
import time
import uuid
from collections import deque
from collections.abc import Callable
from datetime import UTC, datetime
from types import SimpleNamespace
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, ValidationError, model_validator

from obs.adapters.base import AdapterBase
from obs.adapters.message import providers as message_providers
from obs.adapters.message.providers.base import MessageSendResult
from obs.adapters.message.providers.pushover import (
    check_static_url_title,
    parse_pushover_options,
    validation_error_message,
)
from obs.adapters.registry import register
from obs.core.event_bus import DataValueEvent
from obs.core.json import json_dumps
from obs.core.url_values import encode_url_value
from obs.datetime_format import DEFAULT_DATE_FORMAT, DEFAULT_TIME_FORMAT, format_datetime
from obs.db.database import get_db
from obs.regional_format import (
    DEFAULT_CURRENCY,
    DEFAULT_REGION_FORMAT,
    format_number,
    is_finite_number,
    resolve_region_format,
)

logger = logging.getLogger(__name__)

MessageOperator = Literal["any", "=", "==", "<", "<=", ">", ">=", "!=", "contains", "contains not", "starts with", "ends with"]
ArchiveStrategy = Literal["none", "send_only", "archive_only", "send_and_archive"]
MAX_PENDING_EVENTS_PER_BINDING = 100
_NO_PENDING_COALESCE = object()
_PLACEHOLDER_PATTERN = re.compile("###(?:DP|DPU|DPN|DPI|TS|DATE|TIME)###")


class ProviderTargetRef(BaseModel):
    provider: str
    target: str


class MessageAdapterConfig(BaseModel):
    providers: dict[str, dict[str, Any]] = Field(
        default_factory=dict,
        title="Provider",
        description="Provider-Konfigurationen, z. B. pushover, telegram oder seven.io mit targets.",
    )

    @model_validator(mode="after")
    def _validate_providers(self) -> MessageAdapterConfig:
        for provider_type, provider_config in self.providers.items():
            provider = message_providers.get_provider(provider_type)
            if provider is None:
                raise ValueError(f"Unknown MESSAGE provider: {provider_type}")
            parsed_without_targets = provider.config_schema(**{**provider_config, "targets": {}})
            if getattr(parsed_without_targets, "enabled", False):
                provider.config_schema(**provider_config)
        return self


class MessageBindingConfig(BaseModel):
    # The binding API returns validation errors verbatim; Pushover options may
    # hold an image URL with credentials, so errors must not echo the input.
    model_config = ConfigDict(hide_input_in_errors=True)

    operator: MessageOperator = Field(default="==")
    compare_value: Any = None
    message: str = Field(default="###DPN###: ###DP### ###DPU###")
    title: str | None = None
    providers: list[ProviderTargetRef] = Field(default_factory=list)
    priority: int | None = None
    # Kept raw and validated only where it applies (a sending binding with a
    # Pushover target): leftover hidden values must never block other bindings.
    pushover: dict[str, Any] | None = None
    send_on_change: bool = True
    cooldown_seconds: int = Field(default=0, ge=0)
    enabled: bool = True
    archive_id: str | None = None
    archive_strategy: ArchiveStrategy = "send_only"

    @model_validator(mode="after")
    def _validate_targets(self) -> MessageBindingConfig:
        if not self.message.strip():
            raise ValueError("MESSAGE binding message must not be empty")
        sends_notification = self.archive_strategy in {"send_only", "send_and_archive"}
        archives_notification = self.archive_strategy in {"archive_only", "send_and_archive"}
        if self.enabled and sends_notification and not self.providers:
            raise ValueError("MESSAGE binding requires at least one target")
        if self.enabled and archives_notification and not self.archive_id:
            raise ValueError("MESSAGE binding archive_id is required for archive strategies")
        seen_targets: set[tuple[str, str]] = set()
        for ref in self.providers:
            key = (ref.provider, ref.target)
            if key in seen_targets:
                raise ValueError(f"Duplicate MESSAGE target: {ref.provider}/{ref.target}")
            seen_targets.add(key)
        if self.enabled and sends_notification and any(ref.provider == "pushover" for ref in self.providers):
            # A legacy top-level priority still applies when the options leave it unset.
            parse_pushover_options(self.pushover, priority=self.priority)
            check_static_url_title(self.pushover)
        return self


class _BindingState:
    def __init__(self) -> None:
        self.last_condition: bool = False
        self.last_sent_monotonic: float | None = None
        self.last_value: Any = object()
        self.in_flight: bool = False
        self.in_flight_key: Any = _NO_PENDING_COALESCE
        self.reset_version: int = 0
        self.pending_events: deque[tuple[Any, DataValueEvent, Any]] = deque()

    def queue_pending_event(self, binding: Any, event: DataValueEvent, coalesce_key: Any = _NO_PENDING_COALESCE) -> None:
        if coalesce_key is not _NO_PENDING_COALESCE:
            if not self.pending_events and _values_equal(coalesce_key, self.in_flight_key):
                return
            for index, (_binding, _event, pending_key) in enumerate(self.pending_events):
                if _values_equal(coalesce_key, pending_key):
                    self.pending_events[index] = (binding, event, coalesce_key)
                    return
        if len(self.pending_events) >= MAX_PENDING_EVENTS_PER_BINDING:
            self.pending_events.popleft()
        self.pending_events.append((binding, event, coalesce_key))


def _binding_config(binding: Any) -> MessageBindingConfig:
    return MessageBindingConfig(**{**binding.config, "enabled": bool(getattr(binding, "enabled", True))})


def _as_number(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _values_equal(left: Any, right: Any) -> bool:
    try:
        return left == right
    except Exception:
        logger.exception("MESSAGE: comparing binding values failed — treating as unequal")
        return False


def _pending_coalesce_key(cfg: MessageBindingConfig, event: DataValueEvent) -> Any:
    if not cfg.send_on_change:
        return _NO_PENDING_COALESCE
    return event.value if cfg.operator == "any" else True


def _as_bool(value: Any) -> bool | None:
    if isinstance(value, bool):
        return value
    if isinstance(value, int | float) and not isinstance(value, bool):
        if value == 1:
            return True
        if value == 0:
            return False
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"true", "1", "yes", "on"}:
            return True
        if normalized in {"false", "0", "no", "off"}:
            return False
    return None


def evaluate_condition(value: Any, operator: str, compare_value: Any) -> bool:
    """Evaluate a MESSAGE binding condition without raising for bad input."""
    op = "==" if operator == "=" else operator
    if op == "any":
        return True
    if op in {"==", "!="}:
        left_bool = _as_bool(value)
        right_bool = _as_bool(compare_value)
        if left_bool is not None and right_bool is not None:
            equal = left_bool is right_bool
        else:
            left_number = _as_number(value)
            right_number = _as_number(compare_value)
            if left_number is not None and right_number is not None:
                equal = left_number == right_number
            else:
                equal = str(value) == str(compare_value)
        return equal if op == "==" else not equal

    if op in {"<", "<=", ">", ">="}:
        left_number = _as_number(value)
        right_number = _as_number(compare_value)
        if left_number is None or right_number is None:
            return False
        if op == "<":
            return left_number < right_number
        if op == "<=":
            return left_number <= right_number
        if op == ">":
            return left_number > right_number
        return left_number >= right_number

    left = "" if value is None else str(value)
    right = "" if compare_value is None else str(compare_value)
    if op == "contains":
        return right in left
    if op == "contains not":
        return right not in left
    if op == "starts with":
        return left.startswith(right)
    if op == "ends with":
        return left.endswith(right)
    return False


def _format_value(value: Any, region_format: str = "de-DE") -> str:
    """Render a datapoint value for a human-readable message.

    Numbers use the configured regional format so a German reader sees
    ``1,05`` rather than the ambiguous ``1.05``; every other type — including
    infinities and NaN, which have no regional form — keeps its locale-neutral
    JSON representation.
    """
    if isinstance(value, str):
        return value
    if isinstance(value, bool):
        return json_dumps(value)
    if isinstance(value, (int, float)) and is_finite_number(value):
        return format_number(value, region_format)
    return json_dumps(value)


def render_message(
    template: str,
    *,
    value: Any,
    unit: str | None,
    name: str,
    datapoint_id: uuid.UUID,
    ts: datetime,
    date_format: str = DEFAULT_DATE_FORMAT,
    time_format: str = DEFAULT_TIME_FORMAT,
    language: str = "de",
    region_format: str = DEFAULT_REGION_FORMAT,
    display_ts: datetime | None = None,
    encode: Callable[[str], str] | None = None,
) -> str:
    """Fill the binding placeholders; *encode* is applied to each inserted value."""
    display_ts = display_ts or ts
    replacements = {
        "###DP###": _format_value(value, resolve_region_format(region_format, language)),
        "###DPU###": unit or "",
        "###DPN###": name,
        "###DPI###": str(datapoint_id),
        "###TS###": ts.isoformat(),
        "###DATE###": format_datetime(display_ts, date_format, language),
        "###TIME###": format_datetime(display_ts, time_format, language),
    }
    if encode is not None:
        replacements = {placeholder: encode(text) for placeholder, text in replacements.items()}
    return _PLACEHOLDER_PATTERN.sub(lambda match: replacements[match.group(0)], template)


async def _datetime_settings() -> dict[str, str]:
    values = {
        "timezone": "Europe/Zurich",
        "date_format": DEFAULT_DATE_FORMAT,
        "time_format": DEFAULT_TIME_FORMAT,
        "language": "de",
        "region_format": DEFAULT_REGION_FORMAT,
        "currency": DEFAULT_CURRENCY,
    }
    try:
        rows = await get_db().fetchall(
            "SELECT key, value FROM app_settings WHERE key IN ('timezone', 'date_format', 'time_format', 'language', 'region_format', 'currency')"
        )
        values.update({row["key"]: row["value"] for row in rows})
    except RuntimeError:
        pass
    return values


@register
class MessageAdapter(AdapterBase):
    adapter_type = "MESSAGE"
    config_schema = MessageAdapterConfig
    binding_config_schema = MessageBindingConfig

    def __init__(self, event_bus: Any, config: dict | None = None, **kwargs) -> None:
        super().__init__(event_bus, config, **kwargs)
        self._cfg = MessageAdapterConfig(**self._config)
        self._binding_map: dict[uuid.UUID, list[Any]] = {}
        self._states: dict[uuid.UUID, _BindingState] = {}
        self._send_tasks: set[asyncio.Task] = set()
        self._subscribed = False

    async def connect(self) -> None:
        if not self._subscribed:
            self._bus.subscribe(DataValueEvent, self._on_value_event)
            self._subscribed = True
        await self._publish_status(True, "MESSAGE adapter ready", code="connected")

    async def disconnect(self) -> None:
        if self._subscribed:
            self._bus.unsubscribe(DataValueEvent, self._on_value_event)
            self._subscribed = False
        for task in self._send_tasks:
            task.cancel()
        if self._send_tasks:
            await asyncio.gather(*self._send_tasks, return_exceptions=True)
            self._send_tasks.clear()
        self._binding_map.clear()
        await self._publish_status(False, "Disconnected", code="disconnected")

    async def _on_bindings_reloaded(self) -> None:
        self._binding_map.clear()
        active_ids: set[uuid.UUID] = set()
        for binding in self._bindings:
            if binding.direction != "SOURCE":
                continue
            try:
                cfg = _binding_config(binding)
            except (ValidationError, TypeError):
                logger.warning("Invalid MESSAGE binding config for %s skipped", binding.id)
                continue
            if not cfg.enabled:
                continue
            active_ids.add(binding.id)
            self._binding_map.setdefault(binding.datapoint_id, []).append(binding)
            self._states[binding.id] = _BindingState()
        for binding_id in list(self._states):
            if binding_id not in active_ids:
                self._states.pop(binding_id, None)

    async def read(self, binding: Any) -> Any:
        return None

    async def write(self, binding: Any, value: Any) -> None:
        event = DataValueEvent(
            datapoint_id=binding.datapoint_id,
            value=value,
            quality="good",
            source_adapter=self.adapter_type,
            binding_id=binding.id,
        )
        await self._handle_binding_event(binding, event, ignore_repetition=True)

    async def send_notification(
        self,
        *,
        message: str,
        providers: list[dict[str, str] | ProviderTargetRef],
        title: str | None = None,
        priority: int | None = None,
        pushover: dict[str, Any] | None = None,
        pushover_message: str | None = None,
    ) -> list[MessageSendResult]:
        """Send an already rendered notification through the shared provider path.

        ``pushover`` carries per-message Pushover options; only Pushover targets
        receive them. Invalid options fail the Pushover targets only — other
        providers still deliver. Malformed target refs raise ``ValueError``.
        ``pushover_message`` replaces the text for Pushover targets only (e.g.
        with HTML-escaped values for HTML formatting).
        """
        try:
            refs = [ref if isinstance(ref, ProviderTargetRef) else ProviderTargetRef(**ref) for ref in providers]
        except ValidationError as exc:
            raise ValueError(validation_error_message(exc)) from None
        options_error = None
        if any(ref.provider == "pushover" for ref in refs):
            try:
                # Send-time normalisation (e.g. a title without URL is dropped)
                # must reach the config below, or its static checks would
                # reject what the provider accepts — for every target.
                own_priority = (
                    isinstance(pushover, dict) and str(pushover.get("priority") if pushover.get("priority") is not None else "").strip() != ""
                )
                parsed = parse_pushover_options(pushover, priority=priority)
                pushover = parsed.model_dump(exclude_none=True, exclude=None if own_priority else {"priority"})
            except ValueError as exc:
                options_error = f"invalid Pushover options: {exc}"
        sendable = [ref for ref in refs if options_error is None or ref.provider != "pushover"]
        try:
            cfg = MessageBindingConfig(
                message=message,
                providers=sendable,
                title=title,
                priority=priority,
                pushover=pushover if options_error is None else None,
                archive_strategy="send_only" if sendable else "none",
            )
        except ValidationError as exc:
            raise ValueError(validation_error_message(exc)) from None
        event = DataValueEvent(
            datapoint_id=uuid.UUID(int=0),
            value=message,
            quality="good",
            source_adapter=self.adapter_type,
        )
        sent = iter(await self._send_to_targets(cfg, SimpleNamespace(id=uuid.uuid4()), event, message, pushover_message))
        results = []
        for ref in refs:
            if options_error is not None and ref.provider == "pushover":
                results.append(MessageSendResult(ref.provider, ref.target, False, options_error))
            else:
                results.append(next(sent))
        return results

    async def _on_value_event(self, event: DataValueEvent) -> None:
        if event.quality != "good":
            return
        if getattr(event, "suppress_action_triggers", False) is True:
            return
        if getattr(event, "initialization", False) is True:
            # Save-time seeding by the logic initialization pass (issue
            # #1031) is not a value change — never notify on it.
            return
        for binding in self._binding_map.get(event.datapoint_id, []):
            await self._handle_binding_event(binding, event)

    async def _handle_binding_event(self, binding: Any, event: DataValueEvent, *, ignore_repetition: bool = False) -> None:
        cfg = _binding_config(binding)
        condition = evaluate_condition(event.value, cfg.operator, cfg.compare_value)
        state = self._states.setdefault(binding.id, _BindingState())
        if not condition:
            state.last_condition = False
            state.in_flight_key = _NO_PENDING_COALESCE
            state.reset_version += 1
            state.pending_events.clear()
            return

        now = time.monotonic()
        if not ignore_repetition:
            if cfg.send_on_change and cfg.operator == "any" and event.value == state.last_value:
                return
            if cfg.send_on_change and cfg.operator != "any" and state.last_condition:
                return
            if cfg.cooldown_seconds and state.last_sent_monotonic is not None:
                elapsed = now - state.last_sent_monotonic
                if elapsed < cfg.cooldown_seconds:
                    state.last_condition = True
                    return

        dp = _lookup_datapoint(event.datapoint_id)
        app_settings = await _datetime_settings()
        event_ts = event.ts if event.ts.tzinfo else event.ts.replace(tzinfo=UTC)
        try:
            from zoneinfo import ZoneInfo

            display_ts = event_ts.astimezone(ZoneInfo(app_settings["timezone"]))
        except (KeyError, ValueError):
            display_ts = event_ts
        render_kwargs: dict[str, Any] = {
            "value": event.value,
            "unit": getattr(dp, "unit", None),
            "name": getattr(dp, "name", str(event.datapoint_id)),
            "datapoint_id": event.datapoint_id,
            "ts": event_ts,
            "date_format": app_settings["date_format"],
            "time_format": app_settings["time_format"],
            "language": app_settings["language"],
            "region_format": app_settings.get("region_format", DEFAULT_REGION_FORMAT),
            "display_ts": display_ts,
        }
        rendered = render_message(cfg.message, **render_kwargs)
        reset_version = state.reset_version
        if state.in_flight and not ignore_repetition:
            state.queue_pending_event(binding, event, _pending_coalesce_key(cfg, event))
            return
        pushover_message = None
        if (
            cfg.pushover is not None
            and cfg.archive_strategy in {"send_only", "send_and_archive"}
            and any(ref.provider == "pushover" for ref in cfg.providers)
        ):
            rendered_options = {
                field: render_message(text, **render_kwargs, encode=None if field == "url_title" else encode_url_value)
                for field in ("image_url", "url", "url_title")
                if isinstance(text := cfg.pushover.get(field), str) and text
            }
            # The provider validates the rendered texts again before sending.
            cfg = cfg.model_copy(update={"pushover": {**cfg.pushover, **rendered_options}})
            if str(cfg.pushover.get("format") or "").strip().lower() == "html":
                # The template is the author's HTML; inserted values are data.
                pushover_message = render_message(cfg.message, **render_kwargs, encode=html.escape)
        # Flags are set only once nothing before the task can raise any more.
        state.in_flight = True
        state.in_flight_key = _pending_coalesce_key(cfg, event) if not ignore_repetition else _NO_PENDING_COALESCE
        task = asyncio.create_task(self._send_and_record(binding, event, cfg, rendered, state, reset_version, pushover_message))
        self._send_tasks.add(task)
        task.add_done_callback(self._send_tasks.discard)

    async def _send_and_record(
        self,
        binding: Any,
        event: DataValueEvent,
        cfg: MessageBindingConfig,
        rendered: str,
        state: _BindingState,
        reset_version: int,
        pushover_message: str | None = None,
    ) -> None:
        try:
            results = []
            if cfg.archive_strategy in {"send_only", "send_and_archive"}:
                results = await self._send_to_targets(cfg, binding, event, rendered, pushover_message)
        except Exception as exc:  # pragma: no cover - defensive guard for unexpected task errors
            logger.exception("MESSAGE send task failed unexpectedly")
            results = [MessageSendResult("message", "internal", False, str(exc))]

        archive_ok = True
        if cfg.archive_strategy in {"archive_only", "send_and_archive"} and cfg.archive_id:
            archive_ok = await self._archive_notification(cfg, binding, event, rendered, results)
        no_op = cfg.archive_strategy == "none"
        archive_only = cfg.archive_strategy == "archive_only"
        provider_success = bool(results) and any(result.ok for result in results)
        provider_all_ok = bool(results) and all(result.ok for result in results)
        success = no_op or (archive_only and archive_ok) or (provider_all_ok and archive_ok)
        partial_success = no_op or (archive_only and archive_ok) or provider_success
        if success or partial_success:
            state.last_sent_monotonic = time.monotonic()
            if state.reset_version == reset_version:
                state.last_condition = True
                state.last_value = event.value

        failures = [result for result in results if not result.ok]
        if archive_ok:
            if failures:
                detail = f"MESSAGE provider failures: {len(failures)} target(s)"
                await self._publish_status(True, detail, severity="warning", code="messageProviderFailures", params={"count": len(failures)})
            elif results:
                await self._publish_status(True, "MESSAGE sent", code="messageSent")

        state.in_flight = False
        state.in_flight_key = _NO_PENDING_COALESCE
        while state.pending_events:
            pending = state.pending_events.popleft()
            pending_binding, pending_event, _pending_key = pending
            if not self._is_current_binding(pending_binding):
                continue
            await self._handle_binding_event(pending_binding, pending_event)
            if state.in_flight:
                break

    def _is_current_binding(self, binding: Any) -> bool:
        return any(current is binding for current in self._binding_map.get(binding.datapoint_id, []))

    async def _send_to_targets(
        self,
        cfg: MessageBindingConfig,
        binding: Any,
        event: DataValueEvent,
        rendered: str,
        pushover_message: str | None = None,
    ) -> list[MessageSendResult]:
        results: list[MessageSendResult] = []
        attachment_cache: dict[str, Any] = {}
        context = {
            "datapoint_id": str(event.datapoint_id),
            "binding_id": str(binding.id),
            "value": event.value,
            "ts": event.ts.isoformat(),
            "priority": cfg.priority,
        }
        for ref in cfg.providers:
            provider = message_providers.get_provider(ref.provider)
            if provider is None:
                logger.warning("MESSAGE provider '%s' is not registered", ref.provider)
                results.append(MessageSendResult(ref.provider, ref.target, False, "provider not registered"))
                continue
            provider_config = self._cfg.providers.get(ref.provider)
            if not provider_config:
                results.append(MessageSendResult(ref.provider, ref.target, False, "provider not configured"))
                continue
            try:
                parsed_provider_config = provider.config_schema(**provider_config)
            except Exception:
                logger.exception("MESSAGE provider '%s' config is invalid", ref.provider)
                results.append(MessageSendResult(ref.provider, ref.target, False, "provider config invalid"))
                continue
            if not getattr(parsed_provider_config, "enabled", False):
                results.append(MessageSendResult(ref.provider, ref.target, False, "provider disabled"))
                continue
            targets = getattr(parsed_provider_config, "targets", {}) or {}
            target_config = targets.get(ref.target)
            if target_config is None:
                results.append(MessageSendResult(ref.provider, ref.target, False, "target not configured"))
                continue
            provider_context = context
            message = rendered
            if ref.provider == "pushover" and pushover_message is not None:
                message = pushover_message
            if ref.provider == "pushover" and cfg.pushover is not None:
                provider_context = {
                    **context,
                    "pushover": {field: value for field, value in cfg.pushover.items() if value is not None},
                    "attachment_cache": attachment_cache,
                }
            try:
                result = await provider.send(
                    provider_config=provider_config,
                    target_name=ref.target,
                    target_config=_model_dump(target_config),
                    title=cfg.title,
                    message=message,
                    context=provider_context,
                )
                results.append(result)
            except Exception:
                logger.exception("MESSAGE provider '%s' target '%s' failed", ref.provider, ref.target)
                results.append(MessageSendResult(ref.provider, ref.target, False, "send failed"))
                continue
            if not result.ok:
                logger.warning("MESSAGE provider '%s' target '%s' failed: %s", ref.provider, ref.target, result.detail)
        return results

    async def _archive_notification(
        self,
        cfg: MessageBindingConfig,
        binding: Any,
        event: DataValueEvent,
        rendered: str,
        results: list[MessageSendResult],
    ) -> bool:
        try:
            from obs.message_archive import get_message_archive_service

            delivery_status = "archived"
            if cfg.archive_strategy == "send_and_archive":
                delivery_status = "sent" if results and all(result.ok for result in results) else "failed"
            await get_message_archive_service().record(
                cfg.archive_id or "notifications",
                type="notification",
                severity="info" if delivery_status in {"sent", "archived"} else "warning",
                source=f"notification.binding.{binding.id}",
                title=cfg.title or "",
                message=rendered,
                payload={
                    "datapoint_id": str(event.datapoint_id),
                    "binding_id": str(binding.id),
                    "notification_providers": sorted({result.provider for result in results}) if results else [],
                    "delivery_status": delivery_status,
                },
            )
            return True
        except Exception:
            logger.exception("MESSAGE archive write failed")
            await self._publish_status(True, "MESSAGE archive write failed", severity="warning", code="messageArchiveWriteFailed")
            return False


def _model_dump(value: Any) -> dict[str, Any]:
    if isinstance(value, BaseModel):
        return value.model_dump()
    return dict(value)


def _lookup_datapoint(datapoint_id: uuid.UUID) -> Any | None:
    try:
        from obs.core.registry import get_registry

        return get_registry().get(datapoint_id)
    except RuntimeError:
        return None
