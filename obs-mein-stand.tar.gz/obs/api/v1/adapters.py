"""Adapters API — Phase 5 (Multi-Instance)

Instanz-Routen (NEU):
  GET    /api/v1/adapters/instances                list all instances + status
  POST   /api/v1/adapters/instances                create new instance
  GET    /api/v1/adapters/instances/{id}           get one instance
  PATCH  /api/v1/adapters/instances/{id}           update config/name + hot-reload
  DELETE /api/v1/adapters/instances/{id}           stop + delete instance
  POST   /api/v1/adapters/instances/{id}/test      test connection (ephemeral)
  POST   /api/v1/adapters/instances/{id}/restart   stop + reconnect
  GET    /api/v1/adapters/instances/{id}/mqtt/browse  MQTT topic browser (scan broker)
  GET    /api/v1/adapters/instances/{id}/onewire/browse    1-Wire sensor/property browser (scan owserver)
  PATCH  /api/v1/adapters/instances/{id}/onewire/aliases   persist a ROM-ID → label alias

Typ-Routen (unverändert):
  GET    /api/v1/adapters                          list registered types
  GET    /api/v1/adapters/{type}/schema            Pydantic JSON schema
  GET    /api/v1/adapters/{type}/binding-schema    Pydantic JSON schema
  POST   /api/v1/adapters/{type}/test              test with given config (legacy)
  PATCH  /api/v1/adapters/{type}/config            update legacy adapter_configs
"""

from __future__ import annotations

import asyncio
import json
import logging
import uuid
from datetime import UTC, datetime
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from pydantic import BaseModel, ValidationError

from obs.adapters import registry as adapter_registry
from obs.adapters.base import AdapterDelegationCapability
from obs.adapters.knx.dpt_registry import DPTRegistry
from obs.api.audit import (
    AuditOutcome,
    contract_audit,
    set_contract_audit_details,
    set_contract_audit_outcome,
    set_contract_audit_resource_id,
    set_contract_audit_summary,
)
from obs.api.auth import Principal, get_admin_user, get_current_principal, get_current_user
from obs.api.authz import AuthzAction
from obs.api.authz_service import adapter_delegates, authorize_adapter_instance, filter_authorized_datapoints
from obs.api.v1.application_audit import audit_application_contract, write_application_success
from obs.api.v1.bindings import _ensure_binding_mutation_scope, _json_config, _validate_adapter_binding
from obs.api.v1.redaction import REDACTED
from obs.db.database import Database, get_db

logger = logging.getLogger(__name__)

router = APIRouter(tags=["adapters"])


# ---------------------------------------------------------------------------
# Response / Request models
# ---------------------------------------------------------------------------


class AdapterInstanceOut(BaseModel):
    id: uuid.UUID
    adapter_type: str
    name: str
    config: dict
    enabled: bool
    registered: bool  # Typ-Klasse geladen?
    running: bool
    connected: bool
    severity: str = "ok"  # "ok" | "warning" | "error" — last AdapterStatusEvent
    status_detail: str = ""  # non-localized fallback (issue #779)
    status_detail_code: str | None = None  # key suffix under adapters.statusDetail.*
    status_detail_params: dict = {}
    bindings: int
    created_at: str
    updated_at: str


class InstanceBindingEntry(BaseModel):
    binding_id: uuid.UUID
    datapoint_id: uuid.UUID
    datapoint_name: str
    enabled: bool
    config: dict


class BindingMigrationRequest(BaseModel):
    target_instance_id: uuid.UUID


class BindingMigrationResult(BaseModel):
    source_instance_id: uuid.UUID
    target_instance_id: uuid.UUID
    total_source_bindings: int
    migrated: int
    skipped: int


class AdapterInstanceCreate(BaseModel):
    adapter_type: str
    name: str
    config: dict = {}
    enabled: bool = True


class AdapterInstanceUpdate(BaseModel):
    name: str | None = None
    config: dict | None = None
    enabled: bool | None = None


class AdapterStatusOut(BaseModel):
    adapter_type: str
    registered: bool
    running: bool
    connected: bool
    hidden: bool = False


class AdapterConfigOut(BaseModel):
    adapter_type: str
    config: dict
    enabled: bool
    updated_at: str | None


class TestRequest(BaseModel):
    config: dict


class TestResult(BaseModel):
    success: bool
    detail: str  # non-localized fallback (issue #779)
    detail_code: str | None = None  # key suffix under adapters.testResult.*
    detail_params: dict = {}


def _failed_test_result(request: Request | None, result: TestResult) -> TestResult:
    if request is not None:
        set_contract_audit_outcome(request, AuditOutcome.FAILED)
    return result


def _bulk_summary(request: Request | None, *, count: int, payload: Any, error_count: int | None = None) -> None:
    if request is not None:
        set_contract_audit_summary(request, resource_count=count, payload=payload)
        if error_count is not None:
            set_contract_audit_details(
                request,
                {
                    **request.state.contract_audit_details,
                    "error_count": error_count,
                },
            )


def _bulk_mutation_result(request: Request | None, *, count: int, payload: Any, errors: list[str]) -> None:
    _bulk_summary(request, count=count, payload=payload, error_count=len(errors))
    if errors and request is not None:
        set_contract_audit_outcome(request, AuditOutcome.FAILED)


class IoBrokerStateOut(BaseModel):
    id: str
    name: str | None = None
    type: str | None = None
    role: str | None = None
    read: bool = True
    write: bool = False
    value: Any = None
    unit: str | None = None


class OneWireSensorOut(BaseModel):
    rom_id: str
    family: str
    properties: list[str]
    alias: str | None = None


class OneWireAliasRequest(BaseModel):
    rom_id: str
    label: str


class IoBrokerImportRequest(BaseModel):
    prefix: str = ""
    states: list[str] = []
    direction: str = "auto"
    tags: list[str] = []
    persist_value: bool = True
    record_history: bool = True
    limit: int = 300


class IoBrokerImportItem(BaseModel):
    state_id: str
    name: str
    data_type: str
    unit: str | None = None
    direction: str
    tags: list[str]
    exists: bool = False
    reason: str | None = None


class IoBrokerImportResult(BaseModel):
    preview: list[IoBrokerImportItem] = []
    created_datapoints: int = 0
    created_bindings: int = 0
    skipped_existing: int = 0
    errors: list[str] = []


class ConfigPatch(BaseModel):
    config: dict
    enabled: bool = True


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------


_MESSAGE_PROVIDER_SECRET_FIELDS = {
    "pushover": ("api_token",),
    "telegram": ("bot_token",),
    "seven.io": ("api_key",),
}
_MESSAGE_PROVIDER_TARGET_SECRET_FIELDS = {
    "pushover": ("user_key",),
    "telegram": ("chat_id",),
    "seven.io": ("to",),
}


def _redact_message_config(config: dict[str, Any]) -> dict[str, Any]:
    """Redact MESSAGE provider credentials and recipient identifiers for API output."""
    redacted = dict(config)
    providers = redacted.get("providers")
    if not isinstance(providers, dict):
        return redacted

    redacted_providers = dict(providers)
    redacted["providers"] = redacted_providers

    for provider_name, provider_fields in _MESSAGE_PROVIDER_SECRET_FIELDS.items():
        provider_config = redacted_providers.get(provider_name)
        if not isinstance(provider_config, dict):
            continue
        provider_redacted = dict(provider_config)
        redacted_providers[provider_name] = provider_redacted
        for field in provider_fields:
            if provider_redacted.get(field):
                provider_redacted[field] = REDACTED

        targets = provider_redacted.get("targets")
        if not isinstance(targets, dict):
            continue
        targets_redacted = dict(targets)
        provider_redacted["targets"] = targets_redacted
        for target_name, target_config in targets.items():
            if not isinstance(target_config, dict):
                continue
            target_redacted = dict(target_config)
            targets_redacted[target_name] = target_redacted
            for field in _MESSAGE_PROVIDER_TARGET_SECRET_FIELDS[provider_name]:
                if target_redacted.get(field):
                    target_redacted[field] = REDACTED

    return redacted


def _message_target_has_redacted_secret(provider_name: str, target_config: dict[str, Any]) -> bool:
    return any(target_config.get(field) == REDACTED for field in _MESSAGE_PROVIDER_TARGET_SECRET_FIELDS[provider_name])


def _message_redacted_secret_paths(config: dict[str, Any]) -> list[str]:
    providers = config.get("providers")
    if not isinstance(providers, dict):
        return []

    paths: list[str] = []
    for provider_name, provider_fields in _MESSAGE_PROVIDER_SECRET_FIELDS.items():
        provider_config = providers.get(provider_name)
        if not isinstance(provider_config, dict):
            continue
        for field in provider_fields:
            if provider_config.get(field) == REDACTED:
                paths.append(f"providers.{provider_name}.{field}")

        targets = provider_config.get("targets")
        if not isinstance(targets, dict):
            continue
        for target_name, target_config in targets.items():
            if not isinstance(target_config, dict):
                continue
            for field in _MESSAGE_PROVIDER_TARGET_SECRET_FIELDS[provider_name]:
                if target_config.get(field) == REDACTED:
                    paths.append(f"providers.{provider_name}.targets.{target_name}.{field}")
    return paths


def _reject_unresolved_redacted_message_config(config: dict[str, Any]) -> None:
    paths = _message_redacted_secret_paths(config)
    if paths:
        raise ValueError("Unresolved redacted MESSAGE secrets: " + ", ".join(paths) + "; please re-enter credentials")


def _message_redacted_target_rename_candidates(
    provider_name: str,
    stored_targets: dict[str, Any],
    incoming_targets: dict[str, Any],
) -> list[dict[str, Any]]:
    removed_targets = [target for target_name, target in stored_targets.items() if target_name not in incoming_targets and isinstance(target, dict)]
    added_redacted_targets = [
        target
        for target_name, target in incoming_targets.items()
        if target_name not in stored_targets and isinstance(target, dict) and _message_target_has_redacted_secret(provider_name, target)
    ]
    # Only handle single renames: FIFO matching for multiple renames would assign secrets in
    # stored-dict order, but the GUI appends renamed keys at the end, so the incoming order
    # reflects the user's edit sequence rather than the stored order — silently swapping secrets.
    if len(removed_targets) != 1 or len(added_redacted_targets) != 1:
        return []
    return removed_targets


def _preserve_redacted_message_config_secrets(stored_config: dict[str, Any], incoming_config: dict[str, Any]) -> dict[str, Any]:
    merged = dict(incoming_config)
    stored_providers = stored_config.get("providers")
    incoming_providers = incoming_config.get("providers")
    if not isinstance(stored_providers, dict) or not isinstance(incoming_providers, dict):
        return merged

    merged_providers = dict(incoming_providers)
    merged["providers"] = merged_providers

    for provider_name, provider_fields in _MESSAGE_PROVIDER_SECRET_FIELDS.items():
        stored_provider = stored_providers.get(provider_name)
        incoming_provider = incoming_providers.get(provider_name)
        if not isinstance(stored_provider, dict) or not isinstance(incoming_provider, dict):
            continue

        merged_provider = dict(incoming_provider)
        merged_providers[provider_name] = merged_provider
        for field in provider_fields:
            if merged_provider.get(field) == REDACTED and field in stored_provider:
                merged_provider[field] = stored_provider[field]

        stored_targets = stored_provider.get("targets")
        incoming_targets = incoming_provider.get("targets")
        if not isinstance(stored_targets, dict) or not isinstance(incoming_targets, dict):
            continue

        merged_targets = dict(incoming_targets)
        merged_provider["targets"] = merged_targets
        removed_targets_queue = _message_redacted_target_rename_candidates(provider_name, stored_targets, incoming_targets)
        for target_name, incoming_target in incoming_targets.items():
            stored_target = stored_targets.get(target_name)
            if not isinstance(stored_target, dict) or not isinstance(incoming_target, dict):
                if not isinstance(incoming_target, dict) or not _message_target_has_redacted_secret(provider_name, incoming_target):
                    continue
                if not removed_targets_queue:
                    raise ValueError(
                        f"Unresolvable redacted secret in target '{target_name}' of provider "
                        f"'{provider_name}': cannot determine mapping — please re-enter credentials"
                    )
                stored_target = removed_targets_queue.pop(0)
            merged_target = dict(incoming_target)
            merged_targets[target_name] = merged_target
            for field in _MESSAGE_PROVIDER_TARGET_SECRET_FIELDS[provider_name]:
                if merged_target.get(field) == REDACTED and field in stored_target:
                    merged_target[field] = stored_target[field]

    return merged


def _redact_instance_config(adapter_type: str, config: dict[str, Any]) -> dict[str, Any]:
    if adapter_type == "MESSAGE":
        return _redact_message_config(config)
    return config


def _instance_out(row: Any, instance: Any | None) -> AdapterInstanceOut:
    cls = adapter_registry.get_class(row["adapter_type"])
    return AdapterInstanceOut(
        id=uuid.UUID(row["id"]),
        adapter_type=row["adapter_type"],
        name=row["name"],
        config=_redact_instance_config(row["adapter_type"], json.loads(row["config"]) if row["config"] else {}),
        enabled=bool(row["enabled"]),
        registered=cls is not None,
        running=instance is not None,
        connected=instance.connected if instance else False,
        severity=getattr(instance, "last_severity", "ok") if instance else "ok",
        status_detail=getattr(instance, "last_detail", "") if instance else "",
        status_detail_code=getattr(instance, "last_detail_code", None) if instance else None,
        status_detail_params=getattr(instance, "last_detail_params", {}) if instance else {},
        bindings=len(instance.get_bindings()) if instance else 0,
        created_at=row["created_at"],
        updated_at=row["updated_at"],
    )


def _principal_from_dependency(user: Principal | str) -> Principal:
    if isinstance(user, Principal):
        return user
    # Compatibility for direct unit calls that still pass the legacy username.
    return Principal(subject=str(user), type="user", is_admin=str(user) == "admin")


async def _filter_readable_datapoint_ids(
    db: Database,
    principal: Principal,
    dp_ids: list[str],
) -> set[str]:
    if principal.type == "user" and principal.is_admin:
        return set(dp_ids)
    return set(await filter_authorized_datapoints(db, principal, dp_ids, action=AuthzAction.READ))


async def _ensure_instance_read(db: Database, principal: Principal, instance_id: str) -> None:
    if principal.type == "user" and principal.is_admin:
        return
    decision = await authorize_adapter_instance(
        db,
        principal,
        instance_id,
        action=AuthzAction.READ,
        min_role="guest",
    )
    if not decision.allowed:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Instanz nicht gefunden")


async def _ensure_instance_mutation(
    db: Database,
    principal: Principal,
    instance_id: str,
    adapter_type: str,
) -> None:
    if principal.type == "user" and principal.is_admin:
        return

    await _ensure_instance_write_grant(db, principal, instance_id)
    _ensure_adapter_delegates_operation(
        principal,
        adapter_type,
        AdapterDelegationCapability.CONFIGURE_INSTANCE,
    )


def _ensure_adapter_delegates_operation(
    principal: Principal,
    adapter_type: str,
    *capabilities: AdapterDelegationCapability,
) -> None:
    """Require every closed, code-declared capability for an adapter operation."""
    if not adapter_delegates(principal, adapter_type, *capabilities):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Adapter-Operation nicht erlaubt")


async def _ensure_instance_write_grant(db: Database, principal: Principal, instance_id: str) -> None:
    if principal.type == "user" and principal.is_admin:
        return
    decision = await authorize_adapter_instance(
        db,
        principal,
        instance_id,
        action=AuthzAction.WRITE,
        min_role="operator",
    )
    if not decision.allowed:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Adapter-Instanzänderung nicht erlaubt")


async def _validate_message_config_preserves_binding_targets(
    instance_id: str,
    config: dict[str, Any],
    db: Database,
) -> None:
    rows = await db.fetchall(
        """SELECT direction, config, enabled FROM adapter_bindings
           WHERE adapter_instance_id=? AND adapter_type='MESSAGE'""",
        (instance_id,),
    )
    for binding_row in rows:
        _validate_adapter_binding(
            "MESSAGE",
            binding_row["direction"],
            _json_config(binding_row["config"]),
            enabled=bool(binding_row["enabled"]),
            instance_config=config,
        )


# ---------------------------------------------------------------------------
# Instanz-Routen  (WICHTIG: vor /{adapter_type}/... registrieren!)
# ---------------------------------------------------------------------------


@router.get("/instances", response_model=list[AdapterInstanceOut])
async def list_instances(
    _user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(lambda: get_db()),
) -> list[AdapterInstanceOut]:
    rows = await db.fetchall("SELECT * FROM adapter_instances ORDER BY adapter_type, name")
    principal = _principal_from_dependency(_user)
    result = []
    for row in rows:
        try:
            await _ensure_instance_read(db, principal, row["id"])
        except HTTPException:
            continue
        instance = adapter_registry.get_instance_by_id(row["id"])
        result.append(_instance_out(row, instance))
    return result


@router.post(
    "/instances",
    response_model=AdapterInstanceOut,
    status_code=status.HTTP_201_CREATED,
    dependencies=[Depends(contract_audit("POST", "/api/v1/adapters/instances"))],
)
async def create_instance(
    body: AdapterInstanceCreate,
    _user: str = Depends(get_admin_user),
    db: Database = Depends(lambda: get_db()),
    request: Request = None,
) -> AdapterInstanceOut:
    cls = adapter_registry.get_class(body.adapter_type)
    if cls is None:
        raise HTTPException(
            status.HTTP_422_UNPROCESSABLE_CONTENT,
            f"Adapter-Typ '{body.adapter_type}' nicht registriert",
        )
    if body.adapter_type == "MESSAGE":
        try:
            _reject_unresolved_redacted_message_config(body.config)
        except ValueError as exc:
            raise HTTPException(status.HTTP_422_UNPROCESSABLE_CONTENT, str(exc)) from exc
    # Config validieren
    try:
        cls.config_schema(**body.config)
    except Exception as exc:
        raise HTTPException(
            status.HTTP_422_UNPROCESSABLE_CONTENT,
            f"Config-Validierungsfehler: {exc}",
        ) from exc

    instance_id = str(uuid.uuid4())
    if request is not None:
        set_contract_audit_resource_id(request, instance_id)
    now = datetime.now(UTC).isoformat()

    await db.execute_and_commit(
        """INSERT INTO adapter_instances
           (id, adapter_type, name, config, enabled, created_at, updated_at)
           VALUES (?,?,?,?,?,?,?)""",
        (
            instance_id,
            body.adapter_type,
            body.name,
            json.dumps(body.config),
            int(body.enabled),
            now,
            now,
        ),
    )

    # Hot-start wenn enabled
    if body.enabled:
        from obs.core.event_bus import get_event_bus

        try:
            await adapter_registry.start_instance(instance_id, get_event_bus(), db)
        except Exception:
            # Verbindungsfehler → Instanz existiert, aber running=False
            logger.exception("Start der neu angelegten Adapter-Instanz %s fehlgeschlagen", instance_id)

    row = await db.fetchone("SELECT * FROM adapter_instances WHERE id=?", (instance_id,))
    instance = adapter_registry.get_instance_by_id(instance_id)
    return _instance_out(row, instance)


@router.get("/instances/{instance_id}", response_model=AdapterInstanceOut)
async def get_instance(
    instance_id: uuid.UUID,
    _user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(lambda: get_db()),
) -> AdapterInstanceOut:
    row = await db.fetchone("SELECT * FROM adapter_instances WHERE id=?", (str(instance_id),))
    if row is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Instanz nicht gefunden")
    await _ensure_instance_read(db, _principal_from_dependency(_user), str(instance_id))
    instance = adapter_registry.get_instance_by_id(str(instance_id))
    return _instance_out(row, instance)


# Serializes the read-modify-write of a ONEWIRE instance's config JSON per
# instance_id, shared between update_instance() and onewire_set_alias(). Without
# this, an alias save (binding-form sensor scan) racing the general instance
# settings form's save both read the same pre-update config, and whichever
# UPDATE commits last silently overwrites the other's change — e.g. the
# settings form's own (already-fetched, now stale) copy of `aliases` clobbering
# an alias just persisted by onewire_set_alias(), or two overlapping alias
# saves each merging in only their own rom_id.
_ONEWIRE_CONFIG_LOCKS: dict[str, asyncio.Lock] = {}


@router.patch(
    "/instances/{instance_id}",
    response_model=AdapterInstanceOut,
    dependencies=[Depends(contract_audit("PATCH", "/api/v1/adapters/instances/{instance_id}"))],
)
async def update_instance(
    instance_id: uuid.UUID,
    body: AdapterInstanceUpdate,
    _user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(lambda: get_db()),
) -> AdapterInstanceOut:
    principal = _principal_from_dependency(_user)
    await _ensure_instance_write_grant(db, principal, str(instance_id))
    lock = _ONEWIRE_CONFIG_LOCKS.setdefault(str(instance_id), asyncio.Lock())
    async with lock:
        row = await db.fetchone("SELECT * FROM adapter_instances WHERE id=?", (str(instance_id),))
        if row is None:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Instanz nicht gefunden")
        await _ensure_instance_mutation(
            db,
            principal,
            str(instance_id),
            row["adapter_type"],
        )

        # Neue Werte bestimmen
        name_new = body.name if body.name is not None else row["name"]
        enabled_new = body.enabled if body.enabled is not None else bool(row["enabled"])
        config_raw = row["config"]
        if body.config is not None:
            config_new = body.config
            if row["adapter_type"] == "MESSAGE":
                stored_config = json.loads(config_raw) if config_raw else {}
                try:
                    config_new = _preserve_redacted_message_config_secrets(stored_config, body.config)
                    _reject_unresolved_redacted_message_config(config_new)
                except ValueError as exc:
                    raise HTTPException(status.HTTP_422_UNPROCESSABLE_CONTENT, str(exc)) from exc
            if row["adapter_type"] == "ONEWIRE":
                # `aliases` is maintained exclusively by onewire_set_alias() (the
                # binding-form sensor scan), never by this form — always keep the
                # currently-persisted value instead of the client's copy (which
                # may be stale, e.g. an alias was saved elsewhere after this form
                # was loaded), sharing _ONEWIRE_CONFIG_LOCKS so this can't race a
                # concurrent onewire_set_alias() either.
                stored_config = json.loads(config_raw) if config_raw else {}
                if "aliases" in stored_config:
                    config_new["aliases"] = stored_config["aliases"]
                else:
                    config_new.pop("aliases", None)
            cls = adapter_registry.get_class(row["adapter_type"])
            if cls:
                try:
                    cls.config_schema(**config_new)
                except Exception as exc:
                    raise HTTPException(
                        status.HTTP_422_UNPROCESSABLE_CONTENT,
                        f"Config-Validierungsfehler: {exc}",
                    ) from exc
            if row["adapter_type"] == "MESSAGE":
                await _validate_message_config_preserves_binding_targets(str(instance_id), config_new, db)
            config_raw = json.dumps(config_new)

        now = datetime.now(UTC).isoformat()
        await db.execute_and_commit(
            """UPDATE adapter_instances
               SET name=?, config=?, enabled=?, updated_at=?
               WHERE id=?""",
            (name_new, config_raw, int(enabled_new), now, str(instance_id)),
        )

        # Hot-reload: Instanz neu starten
        from obs.core.event_bus import get_event_bus

        if enabled_new:
            await adapter_registry.restart_instance(str(instance_id), get_event_bus(), db)
        else:
            await adapter_registry.stop_instance(str(instance_id))

        row = await db.fetchone("SELECT * FROM adapter_instances WHERE id=?", (str(instance_id),))
        instance = adapter_registry.get_instance_by_id(str(instance_id))
    return _instance_out(row, instance)


@router.delete(
    "/instances/{instance_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    dependencies=[Depends(contract_audit("DELETE", "/api/v1/adapters/instances/{instance_id}"))],
)
async def delete_instance(
    instance_id: uuid.UUID,
    _user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(lambda: get_db()),
) -> None:
    principal = _principal_from_dependency(_user)
    await _ensure_instance_write_grant(db, principal, str(instance_id))
    row = await db.fetchone("SELECT id, adapter_type FROM adapter_instances WHERE id=?", (str(instance_id),))
    if row is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Instanz nicht gefunden")
    await _ensure_instance_mutation(
        db,
        principal,
        str(instance_id),
        row["adapter_type"],
    )

    await adapter_registry.stop_instance(str(instance_id))
    # Bindings werden per DB (ON DELETE CASCADE via Trigger oder manuell) gelöscht
    async with db.transaction():
        await db.execute("DELETE FROM adapter_bindings WHERE adapter_instance_id=?", (str(instance_id),))
        await db.execute(
            "DELETE FROM authz_node_roles WHERE node_type='adapter_instance' AND node_id=?",
            (str(instance_id),),
        )
        await db.execute("DELETE FROM adapter_instances WHERE id=?", (str(instance_id),))


@router.post(
    "/instances/{instance_id}/test",
    response_model=TestResult,
    dependencies=[Depends(contract_audit("POST", "/api/v1/adapters/instances/{instance_id}/test"))],
)
async def test_instance(
    instance_id: uuid.UUID,
    body: TestRequest | None = None,
    request: Request = None,
    _user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(lambda: get_db()),
) -> TestResult:
    """Verbindungstest mit aktuellem oder gegebenem Config (ephemer, kein Persist)."""
    principal = _principal_from_dependency(_user)
    await _ensure_instance_write_grant(db, principal, str(instance_id))
    row = await db.fetchone("SELECT * FROM adapter_instances WHERE id=?", (str(instance_id),))
    if row is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Instanz nicht gefunden")
    await _ensure_instance_mutation(
        db,
        principal,
        str(instance_id),
        row["adapter_type"],
    )

    cls = adapter_registry.get_class(row["adapter_type"])
    if cls is None:
        return _failed_test_result(
            request,
            TestResult(
                success=False,
                detail=f"Adapter-Typ '{row['adapter_type']}' nicht registriert",
                detail_code="typeNotRegistered",
                detail_params={"type": row["adapter_type"]},
            ),
        )

    if body and body.config:
        config_dict = body.config  # bereits dict durch Pydantic
    else:
        raw = row["config"] or "{}"
        config_dict = json.loads(raw) if isinstance(raw, str) else raw

    try:
        cls.config_schema(**config_dict)
    except Exception as exc:
        logger.exception("Adapter config validation failed for instance %s", instance_id)
        return _failed_test_result(
            request,
            TestResult(success=False, detail=f"Config-Fehler: {exc}", detail_code="configError", detail_params={"error": str(exc)}),
        )

    from obs.core.event_bus import EventBus

    dummy_bus = EventBus()
    test_instance = cls(event_bus=dummy_bus, config=config_dict)
    try:
        await test_instance.connect()
        # Some adapters (e.g. MQTT) establish the connection in a background task
        # started by connect(). Poll briefly so that task gets a chance to run.
        deadline = asyncio.get_event_loop().time() + 5.0
        while not test_instance.connected and asyncio.get_event_loop().time() < deadline:
            await asyncio.sleep(0.1)
        connected = test_instance.connected
        await test_instance.disconnect()
        if connected:
            return TestResult(
                success=True,
                detail=f"Verbindung zu {row['adapter_type']} erfolgreich",
                detail_code="connectOk",
                detail_params={"type": row["adapter_type"]},
            )
        return _failed_test_result(request, TestResult(success=False, detail="Verbindungsversuch fehlgeschlagen", detail_code="connectFailed"))
    except Exception as exc:
        logger.exception("Verbindungstest für Instanz %s fehlgeschlagen", instance_id)
        return _failed_test_result(request, TestResult(success=False, detail=str(exc)))


@router.post(
    "/instances/{instance_id}/restart",
    response_model=AdapterInstanceOut,
    dependencies=[Depends(contract_audit("POST", "/api/v1/adapters/instances/{instance_id}/restart"))],
)
async def restart_instance_route(
    instance_id: uuid.UUID,
    _user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(lambda: get_db()),
) -> AdapterInstanceOut:
    principal = _principal_from_dependency(_user)
    await _ensure_instance_write_grant(db, principal, str(instance_id))
    row = await db.fetchone("SELECT * FROM adapter_instances WHERE id=?", (str(instance_id),))
    if row is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Instanz nicht gefunden")
    await _ensure_instance_mutation(
        db,
        principal,
        str(instance_id),
        row["adapter_type"],
    )

    from obs.core.event_bus import get_event_bus

    await adapter_registry.restart_instance(str(instance_id), get_event_bus(), db)

    row = await db.fetchone("SELECT * FROM adapter_instances WHERE id=?", (str(instance_id),))
    instance = adapter_registry.get_instance_by_id(str(instance_id))
    return _instance_out(row, instance)


@router.post(
    "/instances/{source_instance_id}/bindings/migrate",
    response_model=BindingMigrationResult,
    dependencies=[Depends(contract_audit("POST", "/api/v1/adapters/instances/{source_instance_id}/bindings/migrate"))],
)
async def migrate_instance_bindings(
    source_instance_id: uuid.UUID,
    body: BindingMigrationRequest,
    request: Request = None,
    _user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(lambda: get_db()),
) -> BindingMigrationResult:
    source_id = str(source_instance_id)
    target_id = str(body.target_instance_id)
    principal = _principal_from_dependency(_user)
    await _ensure_instance_write_grant(db, principal, source_id)
    await _ensure_instance_write_grant(db, principal, target_id)
    if source_id == target_id:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_CONTENT, "Quell- und Ziel-Instanz dürfen nicht identisch sein")

    source_row = await db.fetchone("SELECT id, adapter_type FROM adapter_instances WHERE id=?", (source_id,))
    if source_row is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Quell-Instanz nicht gefunden")

    target_row = await db.fetchone("SELECT id, adapter_type, config FROM adapter_instances WHERE id=?", (target_id,))
    if target_row is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Ziel-Instanz nicht gefunden")

    await _ensure_instance_mutation(db, principal, source_id, source_row["adapter_type"])
    await _ensure_instance_mutation(db, principal, target_id, target_row["adapter_type"])

    if source_row["adapter_type"] != target_row["adapter_type"]:
        raise HTTPException(
            status.HTTP_422_UNPROCESSABLE_CONTENT,
            "Migration ist nur zwischen Instanzen desselben Adapter-Typs erlaubt",
        )

    source_bindings = await db.fetchall(
        "SELECT id, datapoint_id, direction, config, enabled FROM adapter_bindings WHERE adapter_instance_id=? ORDER BY created_at",
        (source_id,),
    )
    target_bindings = await db.fetchall(
        "SELECT datapoint_id, config FROM adapter_bindings WHERE adapter_instance_id=?",
        (target_id,),
    )
    target_datapoint_ids = {row["datapoint_id"] for row in target_bindings}
    target_slugs = {_json_config(row["config"]).get("slug") for row in target_bindings} if source_row["adapter_type"] == "WEBHOOK" else set()

    migrated = 0
    skipped = 0
    total_source_bindings = len(source_bindings)
    now = datetime.now(UTC).isoformat()
    target_message_config = _json_config(target_row["config"]) if target_row["adapter_type"] == "MESSAGE" else None

    bindings_to_migrate = []
    for binding_row in source_bindings:
        if binding_row["datapoint_id"] in target_datapoint_ids:
            skipped += 1
            continue
        await _ensure_binding_mutation_scope(db, principal, uuid.UUID(binding_row["datapoint_id"]))
        # A slug is the public name of one endpoint per instance: moving a
        # binding next to one that already owns it would leave one URL dead
        # after the reload, so refuse the whole migration before any row moves.
        if source_row["adapter_type"] == "WEBHOOK":
            slug = _json_config(binding_row["config"]).get("slug")
            if slug in target_slugs:
                raise HTTPException(
                    status.HTTP_422_UNPROCESSABLE_CONTENT,
                    f"Der Slug '{slug}' ist in der Ziel-Instanz bereits vergeben",
                )
        if target_message_config is not None:
            _validate_adapter_binding(
                "MESSAGE",
                binding_row["direction"],
                _json_config(binding_row["config"]),
                enabled=bool(binding_row["enabled"]),
                instance_config=target_message_config,
            )
        bindings_to_migrate.append(binding_row)

    for binding_row in bindings_to_migrate:
        await db.execute(
            "UPDATE adapter_bindings SET adapter_instance_id=?, updated_at=? WHERE id=?",
            (target_id, now, binding_row["id"]),
        )
        target_datapoint_ids.add(binding_row["datapoint_id"])
        migrated += 1

    if migrated > 0 and not getattr(db, "in_transaction", False):
        await db.commit()

    await adapter_registry.reload_instance_bindings(source_id, db)
    await adapter_registry.reload_instance_bindings(target_id, db)

    result = BindingMigrationResult(
        source_instance_id=source_instance_id,
        target_instance_id=body.target_instance_id,
        total_source_bindings=total_source_bindings,
        migrated=migrated,
        skipped=skipped,
    )
    _bulk_summary(
        request,
        count=migrated,
        payload={"source_instance_id": source_id, "target_instance_id": target_id},
    )
    return result


@router.get("/instances/{instance_id}/bindings", response_model=list[InstanceBindingEntry])
async def list_instance_bindings(
    instance_id: uuid.UUID,
    _user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(lambda: get_db()),
) -> list[InstanceBindingEntry]:
    """Alle Bindings einer Adapter-Instanz, angereichert mit Datenpunkt-Namen."""
    instance_row = await db.fetchone("SELECT id FROM adapter_instances WHERE id=?", (str(instance_id),))
    if instance_row is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Instanz nicht gefunden")
    principal = _principal_from_dependency(_user)
    await _ensure_instance_read(db, principal, str(instance_id))
    rows = await db.fetchall(
        """SELECT ab.id, ab.datapoint_id, dp.name AS dp_name, ab.enabled, ab.config
           FROM adapter_bindings ab
           JOIN datapoints dp ON dp.id = ab.datapoint_id
           WHERE ab.adapter_instance_id = ?
           ORDER BY dp.name, ab.created_at""",
        (str(instance_id),),
    )
    allowed_dp_ids = await _filter_readable_datapoint_ids(db, principal, [row["datapoint_id"] for row in rows])
    return [
        InstanceBindingEntry(
            binding_id=uuid.UUID(row["id"]),
            datapoint_id=uuid.UUID(row["datapoint_id"]),
            datapoint_name=row["dp_name"],
            enabled=bool(row["enabled"]),
            config=json.loads(row["config"]) if row["config"] else {},
        )
        for row in rows
        if row["datapoint_id"] in allowed_dp_ids
    ]


class HolidayEntry(BaseModel):
    date: str
    name: str


@router.get("/instances/{instance_id}/holidays", response_model=list[HolidayEntry])
async def list_instance_holidays(
    instance_id: uuid.UUID,
    year: int = Query(default=0, description="Jahr (0 = aktuelles Jahr)"),
    _user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(lambda: get_db()),
) -> list[HolidayEntry]:
    """Alle Feiertage einer Zeitschaltuhr-Instanz für das angegebene Jahr (Library + benutzerdefiniert)."""
    from datetime import datetime as _dt

    row = await db.fetchone("SELECT * FROM adapter_instances WHERE id=?", (str(instance_id),))
    if row is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Instanz nicht gefunden")
    await _ensure_instance_read(db, _principal_from_dependency(_user), str(instance_id))
    if row["adapter_type"] != "ZEITSCHALTUHR":
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Nur für Zeitschaltuhr-Instanzen verfügbar")

    target_year = year if year > 0 else _dt.now().year  # noqa: DTZ005 -- default "current year" convenience only; explicit `year` always overrides

    instance = adapter_registry.get_instance_by_id(str(instance_id))
    if instance is not None and hasattr(instance, "get_holidays_for_year"):
        holidays = instance.get_holidays_for_year(target_year)
    else:
        # Instance not running — reconstruct adapter to query holidays
        from obs.adapters.zeitschaltuhr.adapter import ZeitschaltuhrAdapter

        raw_config = row["config"] or "{}"
        config_dict = json.loads(raw_config) if isinstance(raw_config, str) else raw_config
        from obs.core.event_bus import EventBus

        dummy = ZeitschaltuhrAdapter(event_bus=EventBus(), config=config_dict)
        holidays = dummy.get_holidays_for_year(target_year)

    return [HolidayEntry(date=h["date"], name=h["name"]) for h in holidays]


def _build_tls_context(cfg: Any) -> Any:
    """Return an ssl.SSLContext if cfg.tls is True, else None."""
    if not getattr(cfg, "tls", False):
        return None
    import ssl

    ctx = ssl.create_default_context()
    if getattr(cfg, "tls_insecure", False):
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
    return ctx


@router.get("/instances/{instance_id}/mqtt/browse", response_model=list[str])
async def mqtt_browse_topics(
    instance_id: uuid.UUID,
    timeout: int = 5,
    _user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(lambda: get_db()),
) -> list[str]:
    """Subscribe to # for up to `timeout` seconds (max 10) and return observed topics."""
    row = await db.fetchone("SELECT * FROM adapter_instances WHERE id=?", (str(instance_id),))
    if row is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Instanz nicht gefunden")
    await _ensure_instance_read(db, _principal_from_dependency(_user), str(instance_id))
    if row["adapter_type"] != "MQTT":
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Nur für MQTT-Instanzen verfügbar")

    raw_config = row["config"] or "{}"
    config_dict = json.loads(raw_config) if isinstance(raw_config, str) else raw_config

    from obs.adapters.mqtt.adapter import MqttAdapterConfig

    try:
        cfg = MqttAdapterConfig(**config_dict)
    except Exception as exc:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_CONTENT, f"Config-Fehler: {exc}") from exc

    try:
        import aiomqtt
    except ImportError:
        raise HTTPException(status.HTTP_503_SERVICE_UNAVAILABLE, "aiomqtt nicht installiert")

    scan_secs = min(max(timeout, 1), 10)
    tls_context = _build_tls_context(cfg)
    browse_id = f"obs-mqtt-{instance_id.hex[:8]}-browse"
    topics: set[str] = set()
    try:
        async with aiomqtt.Client(
            hostname=cfg.host,
            port=cfg.port,
            username=cfg.username,
            password=cfg.password,
            identifier=browse_id,
            tls_context=tls_context,
        ) as client:
            await client.subscribe("#")
            try:
                async with asyncio.timeout(scan_secs):
                    async for message in client.messages:
                        topics.add(str(message.topic))
            except TimeoutError:
                pass
    except Exception as exc:
        raise HTTPException(
            status.HTTP_503_SERVICE_UNAVAILABLE,
            f"MQTT-Verbindung fehlgeschlagen: {exc}",
        ) from exc

    return sorted(topics)


@router.get("/instances/{instance_id}/mqtt/sample")
async def mqtt_sample_payload(
    instance_id: uuid.UUID,
    topic: str,
    timeout: int = 5,
    _user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(lambda: get_db()),
) -> dict:
    """Subscribe to a specific topic and return the first received payload (useful for retained messages)."""
    row = await db.fetchone("SELECT * FROM adapter_instances WHERE id=?", (str(instance_id),))
    if row is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Instanz nicht gefunden")
    await _ensure_instance_read(db, _principal_from_dependency(_user), str(instance_id))
    if row["adapter_type"] != "MQTT":
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Nur für MQTT-Instanzen verfügbar")

    raw_config = row["config"] or "{}"
    config_dict = json.loads(raw_config) if isinstance(raw_config, str) else raw_config

    from obs.adapters.mqtt.adapter import MqttAdapterConfig

    try:
        cfg = MqttAdapterConfig(**config_dict)
    except Exception as exc:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_CONTENT, f"Config-Fehler: {exc}") from exc

    try:
        import aiomqtt
    except ImportError:
        raise HTTPException(status.HTTP_503_SERVICE_UNAVAILABLE, "aiomqtt nicht installiert")

    scan_secs = min(max(timeout, 1), 10)
    tls_context = _build_tls_context(cfg)
    sample_id = f"obs-mqtt-{instance_id.hex[:8]}-sample"
    try:
        async with aiomqtt.Client(
            hostname=cfg.host,
            port=cfg.port,
            username=cfg.username,
            password=cfg.password,
            identifier=sample_id,
            tls_context=tls_context,
        ) as client:
            await client.subscribe(topic)
            try:
                async with asyncio.timeout(scan_secs):
                    async for message in client.messages:
                        return {
                            "topic": str(message.topic),
                            "payload": message.payload.decode("utf-8", errors="replace"),
                        }
            except TimeoutError:
                pass
    except Exception as exc:
        raise HTTPException(
            status.HTTP_503_SERVICE_UNAVAILABLE,
            f"MQTT-Verbindung fehlgeschlagen: {exc}",
        ) from exc

    raise HTTPException(
        status.HTTP_404_NOT_FOUND,
        f"Kein Payload auf Topic '{topic}' innerhalb von {scan_secs} s empfangen",
    )


@router.get("/instances/{instance_id}/iobroker/states", response_model=list[IoBrokerStateOut])
async def iobroker_browse_states(
    instance_id: uuid.UUID,
    q: str = Query("", max_length=200),
    limit: int = Query(50, ge=1, le=100),
    _user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(lambda: get_db()),
) -> list[IoBrokerStateOut]:
    """Durchsuchbare ioBroker-State-Liste für Binding-Auswahl."""
    row = await db.fetchone("SELECT * FROM adapter_instances WHERE id=?", (str(instance_id),))
    if row is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Instanz nicht gefunden")
    await _ensure_instance_read(db, _principal_from_dependency(_user), str(instance_id))
    if row["adapter_type"] != "IOBROKER":
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Nur für IOBROKER-Instanzen verfügbar")

    instance = adapter_registry.get_instance_by_id(str(instance_id))
    if instance is None:
        raise HTTPException(status.HTTP_503_SERVICE_UNAVAILABLE, "ioBroker-Instanz ist nicht verbunden")
    if not hasattr(instance, "browse_states"):
        raise HTTPException(status.HTTP_501_NOT_IMPLEMENTED, "ioBroker-State-Browser nicht verfügbar")

    try:
        return [IoBrokerStateOut(**item) for item in await instance.browse_states(q, limit)]
    except Exception as exc:
        raise HTTPException(
            status.HTTP_503_SERVICE_UNAVAILABLE,
            f"ioBroker-State-Suche fehlgeschlagen: {exc}",
        ) from exc


@router.get("/instances/{instance_id}/onewire/browse", response_model=list[OneWireSensorOut])
async def onewire_browse_sensors(
    instance_id: uuid.UUID,
    _user: str = Depends(get_current_user),
    db: Database = Depends(lambda: get_db()),
) -> list[OneWireSensorOut]:
    """Live-Scan des owserver-Gerätebaums für die Binding-Sensor/Property-Auswahl (issue #6)."""
    row = await db.fetchone("SELECT * FROM adapter_instances WHERE id=?", (str(instance_id),))
    if row is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Instanz nicht gefunden")
    if row["adapter_type"] != "ONEWIRE":
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Nur für ONEWIRE-Instanzen verfügbar")

    instance = adapter_registry.get_instance_by_id(str(instance_id))
    if instance is None:
        raise HTTPException(status.HTTP_503_SERVICE_UNAVAILABLE, "1-Wire-Instanz ist nicht verbunden")
    if not hasattr(instance, "browse_sensors"):
        raise HTTPException(status.HTTP_501_NOT_IMPLEMENTED, "1-Wire-Sensor-Browser nicht verfügbar")
    if not getattr(instance, "has_proxy", instance.connected):
        # No proxy was ever obtained (e.g. owserver was unreachable at startup,
        # or pyownet isn't installed) — browse_sensors() would otherwise just
        # return [], which looks identical to "connected, zero devices" instead
        # of surfacing the actual connectivity problem.
        #
        # Deliberately not `instance.connected`: that flag can go stale (e.g. a
        # DEST-only binding's write failed and there's no poll loop to notice
        # owserver coming back since), which would permanently 503 an instance
        # that could otherwise scan successfully right now. `has_proxy` only
        # reflects whether connect() ever produced a live proxy object; a
        # scan attempt with a stale/broken proxy still fails via the except
        # block below.
        raise HTTPException(status.HTTP_503_SERVICE_UNAVAILABLE, "1-Wire-Instanz ist nicht verbunden")

    try:
        return [OneWireSensorOut(**item) for item in await instance.browse_sensors()]
    except Exception as exc:
        raise HTTPException(
            status.HTTP_503_SERVICE_UNAVAILABLE,
            f"1-Wire-Sensor-Scan fehlgeschlagen: {exc}",
        ) from exc


@router.patch("/instances/{instance_id}/onewire/aliases", response_model=OneWireAliasRequest)
@audit_application_contract(
    "PATCH",
    "/api/v1/adapters/instances/{instance_id}/onewire/aliases",
    principal_param="_user",
    resource_param="instance_id",
)
async def onewire_set_alias(
    instance_id: uuid.UUID,
    body: OneWireAliasRequest,
    request: Request = None,  # type: ignore[assignment]
    _user: str = Depends(get_admin_user),
    db: Database = Depends(lambda: get_db()),
) -> OneWireAliasRequest:
    """Persistiert einen ROM-ID → Klartext-Label Alias, gepflegt aus der Binding-Scan-UI (issue #6)."""
    lock = _ONEWIRE_CONFIG_LOCKS.setdefault(str(instance_id), asyncio.Lock())
    async with lock:
        row = await db.fetchone("SELECT * FROM adapter_instances WHERE id=?", (str(instance_id),))
        if row is None:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Instanz nicht gefunden")
        if row["adapter_type"] != "ONEWIRE":
            raise HTTPException(status.HTTP_400_BAD_REQUEST, "Nur für ONEWIRE-Instanzen verfügbar")

        config = json.loads(row["config"]) if row["config"] else {}
        aliases = dict(config.get("aliases") or {})
        aliases[body.rom_id] = body.label
        config["aliases"] = aliases

        cls = adapter_registry.get_class(row["adapter_type"])
        if cls:
            try:
                cls.config_schema(**config)
            except Exception as exc:
                raise HTTPException(
                    status.HTTP_422_UNPROCESSABLE_CONTENT,
                    f"Config-Validierungsfehler: {exc}",
                ) from exc

        now = datetime.now(UTC).isoformat()
        await db.execute_and_commit(
            "UPDATE adapter_instances SET config=?, updated_at=? WHERE id=?",
            (json.dumps(config), now, str(instance_id)),
        )

        from obs.core.event_bus import get_event_bus

        await adapter_registry.restart_instance(str(instance_id), get_event_bus(), db)

    if isinstance(db, Database):
        await write_application_success(
            db,
            request,
            _user,
            "PATCH",
            "/api/v1/adapters/instances/{instance_id}/onewire/aliases",
            resource_id=str(instance_id),
            commit=True,
        )
    return body


def _iobroker_obs_type(state_type: str | None) -> tuple[str, str | None]:
    t = (state_type or "").lower()
    if t == "boolean":
        return "BOOLEAN", "bool"
    if t == "number":
        return "FLOAT", "float"
    if t == "string":
        return "STRING", "string"
    return "STRING", None


def _iobroker_source_type(data_type: str) -> str | None:
    return {
        "BOOLEAN": "bool",
        "FLOAT": "float",
        "INTEGER": "int",
        "STRING": "string",
    }.get(data_type)


def _iobroker_direction(item: dict[str, Any], requested: str) -> str:
    if requested in ("SOURCE", "DEST", "BOTH"):
        return requested
    return "BOTH" if item.get("read", True) and item.get("write", False) else "SOURCE"


def _iobroker_name(item: dict[str, Any]) -> str:
    name = item.get("name")
    if name:
        return str(name)
    return str(item.get("id", "")).split(".")[-1] or str(item.get("id", "ioBroker State"))


def _iobroker_tags(item: dict[str, Any], extra_tags: list[str]) -> list[str]:
    parts = str(item.get("id", "")).split(".")
    tags = ["iobroker"]
    if parts:
        tags.append(parts[0])
    for key in ("role", "type"):
        if item.get(key):
            tags.append(str(item[key]))
    tags.extend(t.strip() for t in extra_tags if t.strip())
    seen: set[str] = set()
    return [t for t in tags if not (t in seen or seen.add(t))]


async def _iobroker_candidates(
    instance_id: str,
    body: IoBrokerImportRequest,
    db: Database,
) -> list[IoBrokerImportItem]:
    instance = adapter_registry.get_instance_by_id(instance_id)
    if instance is None:
        raise HTTPException(status.HTTP_503_SERVICE_UNAVAILABLE, "ioBroker-Instanz ist nicht verbunden")
    states = await instance.browse_states(body.prefix, min(max(body.limit, 1), 500))
    selected = set(body.states)
    if selected:
        states = [s for s in states if s["id"] in selected]

    rows = await db.fetchall(
        "SELECT config FROM adapter_bindings WHERE adapter_instance_id=?",
        (instance_id,),
    )
    existing_states: set[str] = set()
    for row in rows:
        try:
            cfg = json.loads(row["config"] or "{}")
            if cfg.get("state_id"):
                existing_states.add(str(cfg["state_id"]))
        except (json.JSONDecodeError, AttributeError):
            pass

    result: list[IoBrokerImportItem] = []
    for state in states:
        dp_type, _source_type = _iobroker_obs_type(state.get("type"))
        exists = state["id"] in existing_states
        result.append(
            IoBrokerImportItem(
                state_id=state["id"],
                name=_iobroker_name(state),
                data_type=dp_type,
                unit=state.get("unit"),
                direction=_iobroker_direction(state, body.direction),
                tags=_iobroker_tags(state, body.tags),
                exists=exists,
                reason="Binding existiert bereits" if exists else None,
            ),
        )
    return result


async def _ensure_iobroker_import_authority(
    db: Database,
    principal: Principal,
    instance_id: str,
) -> None:
    await _ensure_instance_write_grant(db, principal, instance_id)
    row = await db.fetchone("SELECT adapter_type FROM adapter_instances WHERE id=?", (instance_id,))
    if row is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Instanz nicht gefunden")
    if row["adapter_type"] != "IOBROKER":
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Nur für IOBROKER-Instanzen verfügbar")
    _ensure_adapter_delegates_operation(
        principal,
        row["adapter_type"],
        AdapterDelegationCapability.CREATE_DATAPOINT,
        AdapterDelegationCapability.LINK_BINDING,
    )


@router.post(
    "/instances/{instance_id}/iobroker/import-preview",
    response_model=IoBrokerImportResult,
    dependencies=[Depends(contract_audit("POST", "/api/v1/adapters/instances/{instance_id}/iobroker/import-preview"))],
)
async def iobroker_import_preview(
    instance_id: uuid.UUID,
    body: IoBrokerImportRequest,
    request: Request = None,
    _user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(lambda: get_db()),
) -> IoBrokerImportResult:
    principal = _principal_from_dependency(_user)
    await _ensure_iobroker_import_authority(db, principal, str(instance_id))
    result = IoBrokerImportResult(preview=await _iobroker_candidates(str(instance_id), body, db))
    _bulk_summary(request, count=len(result.preview), payload=body.model_dump())
    return result


@router.post(
    "/instances/{instance_id}/iobroker/import",
    response_model=IoBrokerImportResult,
    dependencies=[Depends(contract_audit("POST", "/api/v1/adapters/instances/{instance_id}/iobroker/import"))],
)
async def iobroker_import_states(
    instance_id: uuid.UUID,
    body: IoBrokerImportRequest,
    request: Request = None,
    _user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(lambda: get_db()),
) -> IoBrokerImportResult:
    principal = _principal_from_dependency(_user)
    await _ensure_iobroker_import_authority(db, principal, str(instance_id))

    from obs.api.v1.bindings import create_binding
    from obs.core.registry import get_registry
    from obs.models.binding import AdapterBindingCreate
    from obs.models.datapoint import DataPointCreate

    candidates = await _iobroker_candidates(str(instance_id), body, db)
    result = IoBrokerImportResult(preview=candidates)
    registry = get_registry()

    for item in candidates:
        if item.exists:
            result.skipped_existing += 1
            continue
        try:
            source_type = _iobroker_source_type(item.data_type)
            dp = await registry.create(
                DataPointCreate(
                    name=item.name,
                    data_type=item.data_type,
                    unit=item.unit,
                    tags=item.tags,
                    persist_value=body.persist_value,
                    record_history=body.record_history,
                ),
            )
            result.created_datapoints += 1
            if not principal.is_admin:
                await db.execute_and_commit(
                    """INSERT INTO authz_node_roles
                       (principal_type, principal_id, node_type, node_id, role, effect)
                       VALUES ('user', ?, 'datapoint', ?, 'operator', 'allow')""",
                    (principal.subject, str(dp.id)),
                )
            config: dict[str, Any] = {"state_id": item.state_id}
            if source_type:
                config["source_data_type"] = source_type
            await create_binding(
                dp.id,
                AdapterBindingCreate(
                    adapter_instance_id=instance_id,
                    direction=item.direction,
                    config=config,
                    enabled=True,
                ),
                principal,
                db,
            )
            result.created_bindings += 1
        except Exception as exc:
            logger.exception("ioBroker-Import fehlgeschlagen für State %s", item.state_id)
            result.errors.append(f"{item.state_id}: {exc}")
    _bulk_mutation_result(
        request,
        count=result.created_datapoints + result.created_bindings + result.skipped_existing,
        payload=body.model_dump(),
        errors=result.errors,
    )
    return result


# ---------------------------------------------------------------------------
# Anwesenheitssimulation: Datenpunkt-Selektor + Binding-Sync
# ---------------------------------------------------------------------------


class AnwesenheitHealthResult(BaseModel):
    healthy: bool
    message: str
    bindings_total: int = 0
    bindings_with_data: int = 0


@router.get("/instances/{instance_id}/anwesenheit/health", response_model=AnwesenheitHealthResult)
async def anwesenheit_health(
    instance_id: uuid.UUID,
    _user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(lambda: get_db()),
) -> AnwesenheitHealthResult:
    """Check whether history data is available for the configured offset window."""
    from datetime import datetime as _dt
    from datetime import timedelta

    row = await db.fetchone("SELECT * FROM adapter_instances WHERE id=?", (str(instance_id),))
    if row is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Instanz nicht gefunden")
    principal = _principal_from_dependency(_user)
    await _ensure_instance_read(db, principal, str(instance_id))
    if row["adapter_type"] != "ANWESENHEITSSIMULATION":
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Nur für ANWESENHEITSSIMULATION-Instanzen verfügbar")

    raw_config = row["config"] or "{}"
    config_dict = json.loads(raw_config) if isinstance(raw_config, str) else raw_config

    from obs.adapters.anwesenheit.adapter import AnwesenheitssimulationConfig

    try:
        cfg = AnwesenheitssimulationConfig(**config_dict)
    except (ValidationError, TypeError) as exc:
        return AnwesenheitHealthResult(healthy=False, message=f"Config-Fehler: {exc}")

    try:
        from obs.history.factory import get_history_plugin

        history = get_history_plugin()
    except RuntimeError:
        return AnwesenheitHealthResult(
            healthy=False, message="History-Plugin nicht verfügbar — bitte History-Backend in den Einstellungen konfigurieren"
        )

    binding_rows = await db.fetchall(
        "SELECT id, datapoint_id FROM adapter_bindings WHERE adapter_instance_id=? AND direction='SOURCE' AND enabled=1",
        (str(instance_id),),
    )
    allowed_dp_ids = await _filter_readable_datapoint_ids(db, principal, [row["datapoint_id"] for row in binding_rows])
    binding_rows = [row for row in binding_rows if row["datapoint_id"] in allowed_dp_ids]
    total = len(binding_rows)
    if total == 0:
        return AnwesenheitHealthResult(
            healthy=False,
            message="Keine aktiven Verknüpfungen konfiguriert — bitte zuerst Objekte über 'Objekte verwalten' hinzufügen",
            bindings_total=0,
            bindings_with_data=0,
        )

    now = _dt.now(tz=UTC)
    delta = timedelta(days=cfg.offset_days)
    hist_from = now - delta - timedelta(hours=12)
    hist_to = now - delta + timedelta(hours=12)

    with_data = 0
    for b_row in binding_rows:
        try:
            dp_id = uuid.UUID(b_row["datapoint_id"])
            records = await history.query(dp_id, hist_from, hist_to, limit=1)
            if records:
                with_data += 1
        except Exception:
            logger.exception("Anwesenheit-Health-Check: Historienabfrage für Binding %s fehlgeschlagen", b_row["id"])

    healthy = with_data > 0
    if healthy:
        msg = (
            f"{with_data} von {total} Objekt(en) haben historische Daten für den Versatz von {cfg.offset_days} Tag(en). "
            f"Die Simulation wird heute Ereignisse aus dem {cfg.offset_days}-Tage-Fenster wiedergeben."
        )
    else:
        msg = (
            f"Keine historischen Daten für den Versatz von {cfg.offset_days} Tag(en) gefunden. "
            f"Stellen Sie sicher, dass für die verknüpften Objekte die Historisierung aktiviert ist "
            f"und Aufzeichnungen aus dem Zeitraum vor {cfg.offset_days + 1} Tagen vorhanden sind."
        )

    return AnwesenheitHealthResult(
        healthy=healthy,
        message=msg,
        bindings_total=total,
        bindings_with_data=with_data,
    )


class AnwesenheitDatapointEntry(BaseModel):
    id: str
    name: str
    data_type: str
    has_binding: bool
    binding_id: str | None


class AnwesenheitSyncRequest(BaseModel):
    datapoint_ids: list[str]


class AnwesenheitSyncResult(BaseModel):
    created: int = 0
    removed: int = 0
    errors: list[str] = []


@router.get(
    "/instances/{instance_id}/anwesenheit/datapoints",
    response_model=list[AnwesenheitDatapointEntry],
)
async def anwesenheit_list_datapoints(
    instance_id: uuid.UUID,
    _user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(lambda: get_db()),
) -> list[AnwesenheitDatapointEntry]:
    """List all Boolean/Integer DataPoints with their binding status for this instance."""
    row = await db.fetchone("SELECT adapter_type FROM adapter_instances WHERE id=?", (str(instance_id),))
    if row is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Instanz nicht gefunden")
    principal = _principal_from_dependency(_user)
    await _ensure_instance_read(db, principal, str(instance_id))
    if row["adapter_type"] != "ANWESENHEITSSIMULATION":
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Nur für ANWESENHEIT-Instanzen verfügbar")

    from obs.core.registry import get_registry

    registry = get_registry()
    all_dps = registry.all()

    # Existing bindings for this instance
    binding_rows = await db.fetchall(
        "SELECT id, datapoint_id FROM adapter_bindings WHERE adapter_instance_id=?",
        (str(instance_id),),
    )
    bound_map: dict[str, str] = {r["datapoint_id"]: r["id"] for r in binding_rows}

    result: list[AnwesenheitDatapointEntry] = []
    candidate_ids = [str(dp.id) for dp in all_dps if dp.data_type in ("BOOLEAN", "INTEGER")]
    allowed_dp_ids = await _filter_readable_datapoint_ids(db, principal, candidate_ids)
    for dp in sorted(all_dps, key=lambda d: d.name.lower()):
        if dp.data_type not in ("BOOLEAN", "INTEGER"):
            continue
        dp_id_str = str(dp.id)
        if dp_id_str not in allowed_dp_ids:
            continue
        result.append(
            AnwesenheitDatapointEntry(
                id=dp_id_str,
                name=dp.name,
                data_type=dp.data_type,
                has_binding=dp_id_str in bound_map,
                binding_id=bound_map.get(dp_id_str),
            )
        )
    return result


@router.post(
    "/instances/{instance_id}/anwesenheit/sync-bindings",
    response_model=AnwesenheitSyncResult,
    dependencies=[Depends(contract_audit("POST", "/api/v1/adapters/instances/{instance_id}/anwesenheit/sync-bindings"))],
)
async def anwesenheit_sync_bindings(
    instance_id: uuid.UUID,
    body: AnwesenheitSyncRequest,
    request: Request = None,
    _user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(lambda: get_db()),
) -> AnwesenheitSyncResult:
    """Create missing bindings for selected DataPoints and remove bindings for deselected ones."""
    principal = _principal_from_dependency(_user)
    await _ensure_instance_write_grant(db, principal, str(instance_id))
    row = await db.fetchone("SELECT adapter_type FROM adapter_instances WHERE id=?", (str(instance_id),))
    if row is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Instanz nicht gefunden")
    if row["adapter_type"] != "ANWESENHEITSSIMULATION":
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Nur für ANWESENHEIT-Instanzen verfügbar")
    _ensure_adapter_delegates_operation(
        principal,
        row["adapter_type"],
        AdapterDelegationCapability.LINK_BINDING,
    )

    from obs.api.v1.bindings import create_binding, delete_binding
    from obs.models.binding import AdapterBindingCreate

    # Current bindings for this instance
    binding_rows = await db.fetchall(
        "SELECT id, datapoint_id FROM adapter_bindings WHERE adapter_instance_id=?",
        (str(instance_id),),
    )
    current: dict[str, str] = {r["datapoint_id"]: r["id"] for r in binding_rows}

    desired_ids = set(body.datapoint_ids)
    current_ids = set(current.keys())

    result = AnwesenheitSyncResult()

    # Create missing bindings
    for dp_id_str in desired_ids - current_ids:
        try:
            dp_uuid = uuid.UUID(dp_id_str)
            await create_binding(
                dp_uuid,
                AdapterBindingCreate(
                    adapter_instance_id=instance_id,
                    direction="SOURCE",
                    config={},
                    enabled=True,
                ),
                principal,
                db,
            )
            result.created += 1
        except Exception as exc:
            logger.exception("Anwesenheit-Sync: Anlegen der Bindung für DataPoint %s fehlgeschlagen", dp_id_str)
            result.errors.append(f"{dp_id_str}: {exc}")

    # Remove bindings for deselected DataPoints
    for dp_id_str in current_ids - desired_ids:
        try:
            binding_uuid = uuid.UUID(current[dp_id_str])
            dp_uuid = uuid.UUID(dp_id_str)
            await delete_binding(dp_uuid, binding_uuid, principal, db)
            result.removed += 1
        except Exception as exc:
            logger.exception("Anwesenheit-Sync: Entfernen der Bindung für DataPoint %s fehlgeschlagen", dp_id_str)
            result.errors.append(f"{dp_id_str}: {exc}")

    # Reload adapter bindings if the instance is running
    try:
        inst = adapter_registry.get_instance_by_id(instance_id)
        if inst is not None:
            await adapter_registry.reload_instance_bindings(instance_id, db)
    except Exception:
        # non-critical — bindings take effect on next restart
        logger.exception("Anwesenheit-Sync: Reload der Bindings für Instanz %s fehlgeschlagen", instance_id)

    _bulk_mutation_result(
        request,
        count=result.created + result.removed,
        payload=sorted(body.datapoint_ids),
        errors=result.errors,
    )
    return result


# ---------------------------------------------------------------------------
# SNMP Walk (Discovery)
# ---------------------------------------------------------------------------


class SnmpWalkEntry(BaseModel):
    oid: str
    value: str
    type: str


@router.get("/instances/{instance_id}/snmp/walk", response_model=list[SnmpWalkEntry])
async def snmp_walk(
    instance_id: uuid.UUID,
    host: str = Query(..., description="IP-Adresse oder DNS-Name des SNMP-Geräts"),
    oid: str = Query(default="1.3.6.1.2.1", description="Subtree-Root OID"),
    port: int = Query(default=161, ge=1, le=65535, description="UDP-Port"),
    timeout: float = Query(default=5.0, ge=0.5, le=30.0, description="Timeout pro Request (s)"),
    max_results: int = Query(default=50, ge=1, le=500, description="Einträge pro Seite"),
    start_oid: str | None = Query(default=None, description="Cursor für Paginierung (letzter OID der Vorseite)"),
    _user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(lambda: get_db()),
) -> list[SnmpWalkEntry]:
    """SNMP-Walk über einen OID-Teilbaum — nützlich für OID-Discovery beim Binding-Anlegen.

    Paginierung: start_oid auf den letzten OID der Vorseite setzen um weitere Einträge zu laden.
    """
    row = await db.fetchone("SELECT * FROM adapter_instances WHERE id=?", (str(instance_id),))
    if row is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Instanz nicht gefunden")
    await _ensure_instance_read(db, _principal_from_dependency(_user), str(instance_id))
    if row["adapter_type"] != "SNMP":
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Nur für SNMP-Instanzen verfügbar")

    instance = adapter_registry.get_instance_by_id(str(instance_id))
    if instance is None or not instance.connected:
        import json as _json

        from obs.adapters.snmp.adapter import SnmpAdapter
        from obs.core.event_bus import EventBus

        raw_config = row["config"] or "{}"
        config_dict = _json.loads(raw_config) if isinstance(raw_config, str) else raw_config
        dummy_bus = EventBus()
        instance = SnmpAdapter(event_bus=dummy_bus, config=config_dict)
        await instance.connect()
        if not instance.connected:
            raise HTTPException(
                status.HTTP_503_SERVICE_UNAVAILABLE,
                "SNMP Adapter konnte nicht verbunden werden (pysnmp installiert?)",
            )

    if not hasattr(instance, "snmp_walk"):
        raise HTTPException(status.HTTP_501_NOT_IMPLEMENTED, "snmp_walk nicht verfügbar")

    try:
        entries = await instance.snmp_walk(
            host=host,
            oid=oid,
            port=port,
            timeout=timeout,
            max_results=max_results,
            start_oid=start_oid,
        )
        return [SnmpWalkEntry(**e) for e in entries]
    except Exception as exc:
        raise HTTPException(
            status.HTTP_503_SERVICE_UNAVAILABLE,
            f"SNMP Walk fehlgeschlagen: {exc}",
        ) from exc


# ---------------------------------------------------------------------------
# WEBHOOK — ready-to-copy call URLs and token rotation (issue #1256)
# ---------------------------------------------------------------------------


class WebhookRejectionOut(BaseModel):
    """Why calls were turned away — the diagnostics behind an opaque 404."""

    total: int = 0
    counts: dict[str, int] = {}
    last_reason: str | None = None
    last_client_ip: str | None = None
    last_slug: str | None = None
    last_at: str | None = None


class WebhookBindingEntry(BaseModel):
    binding_id: str
    datapoint_id: str
    datapoint_name: str | None
    enabled: bool
    slug: str
    token: str
    methods: list[str]
    allowed_networks: list[str]
    value_source: str
    fixed_value: str
    value_param: str
    debounce_ms: int
    autoreset: bool
    autoreset_value: str
    autoreset_delay_ms: int
    # Relative paths — the GUI prefixes its own origin, because the server
    # cannot know the host name or port the device has to call.
    call_path: str
    call_path_token_in_path: str
    call_count: int
    publish_count: int
    last_called: str | None
    last_status: int | None
    rejections: WebhookRejectionOut = WebhookRejectionOut()


class WebhookOverview(BaseModel):
    """The instance's own webhook settings plus its bindings.

    The GUI needs the endpoint-wide settings alongside the bindings to build
    and judge a call URL; the allowlist itself lives on each binding.
    """

    instance_id: str
    running: bool
    path_prefix: str
    trust_forwarded_for: bool
    rate_limit_per_minute: int
    rejections: WebhookRejectionOut = WebhookRejectionOut()
    bindings: list[WebhookBindingEntry] = []


class WebhookTokenRotationResult(BaseModel):
    binding_id: str
    slug: str
    token: str
    call_path: str
    call_path_token_in_path: str


async def _filter_binding_manageable_datapoint_ids(db: Database, principal: Principal, dp_ids: list[str]) -> set[str]:
    allowed: set[str] = set()
    for dp_id in dict.fromkeys(dp_ids):
        try:
            await _ensure_binding_mutation_scope(db, principal, uuid.UUID(dp_id))
        except HTTPException:
            continue
        allowed.add(dp_id)
    return allowed


def _ensure_webhook_secret_user(principal: Principal) -> None:
    """Keep webhook bearer tokens away from API keys.

    Both the overview (which serves the token in clear text) and the rotation
    reply expose a secret that authorises its DataPoint anonymously and outlives
    the key that fetched it. API keys never receive adapter delegation, so a key
    must not read or rotate it however many grants it holds.
    """
    if principal.type != "user":
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Webhook-Token sind nur für Benutzer zugänglich")


async def _webhook_instance_row(db: Database, instance_id: uuid.UUID) -> Any:
    row = await db.fetchone("SELECT adapter_type, config FROM adapter_instances WHERE id=?", (str(instance_id),))
    if row is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Instanz nicht gefunden")
    if row["adapter_type"] != "WEBHOOK":
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Nur für WEBHOOK-Instanzen verfügbar")
    return row


def _webhook_path_prefix(instance_row: Any) -> str:
    from obs.adapters.webhook.adapter import DEFAULT_PATH_PREFIX, normalise_path_prefix

    raw = _json_config(instance_row["config"]).get("path_prefix") or DEFAULT_PATH_PREFIX
    try:
        return normalise_path_prefix(str(raw))
    except ValueError:
        # A stored prefix can only be invalid if it predates the current
        # validation; report the default rather than failing the listing.
        return DEFAULT_PATH_PREFIX


def _webhook_call_paths(prefix: str, slug: str, token: str) -> tuple[str, str]:
    return f"{prefix}/{slug}?token={token}", f"{prefix}/{slug}/{token}"


def _webhook_rejections_out(counters: Any) -> WebhookRejectionOut:
    """Map the adapter's in-memory rejection counters to the API shape."""
    if counters is None:
        return WebhookRejectionOut()
    last = counters.last
    return WebhookRejectionOut(
        total=counters.total,
        counts=dict(counters.counts),
        last_reason=last.reason.value if last else None,
        last_client_ip=last.client_ip if last else None,
        last_slug=last.slug if last else None,
        last_at=last.at.isoformat() if last else None,
    )


def _webhook_instance_settings(instance_row: Any) -> Any:
    """Parse the stored instance config, falling back to the defaults.

    An imported backup or a hand-edited row can hold a configuration the
    current validation would refuse; the overview reports defaults rather than
    failing, exactly like ``_webhook_path_prefix`` does for the prefix alone.
    """
    from obs.adapters.webhook.adapter import WebhookAdapterConfig

    try:
        return WebhookAdapterConfig(**_json_config(instance_row["config"]))
    except ValidationError:
        return WebhookAdapterConfig()


@router.get("/instances/{instance_id}/webhook/bindings", response_model=WebhookOverview)
async def webhook_list_bindings(
    instance_id: uuid.UUID,
    _user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(lambda: get_db()),
) -> WebhookOverview:
    """The instance's webhook settings plus its bindings' call URLs and counters.

    This is the only route that serves a binding token in clear text — the
    generic binding listing redacts it — so it requires the same WRITE grant on
    the adapter instance that creating the binding needed.  The token is a
    bearer secret for exactly one DataPoint, and whoever may hand it to a
    device may also read it back to build the URL.

    It also reports why calls were turned away.  A rejected call answers an
    indistinguishable 404 on purpose, which makes a misconfigured allowlist
    look exactly like a broken adapter — the counters and the address of the
    last rejection are what make that diagnosable from the GUI.
    """
    from obs.adapters.webhook.adapter import WebhookBindingConfig
    from obs.core.registry import get_registry

    principal = _principal_from_dependency(_user)
    _ensure_webhook_secret_user(principal)
    instance_row = await _webhook_instance_row(db, instance_id)
    await _ensure_instance_write_grant(db, principal, str(instance_id))

    settings = _webhook_instance_settings(instance_row)
    prefix = _webhook_path_prefix(instance_row)
    instance = adapter_registry.get_instance_by_id(str(instance_id))
    rows = await db.fetchall(
        "SELECT * FROM adapter_bindings WHERE adapter_instance_id=? AND adapter_type='WEBHOOK' ORDER BY created_at",
        (str(instance_id),),
    )
    # The entry carries the binding's bearer token, which authorises writes to
    # its DataPoint. READ access to that DataPoint is therefore not enough: the
    # caller needs the same right that changing the binding requires, or the
    # token would turn a read grant into an anonymous write path.
    allowed_dp_ids = await _filter_binding_manageable_datapoint_ids(db, principal, [row["datapoint_id"] for row in rows])

    registry = get_registry()
    result: list[WebhookBindingEntry] = []
    for row in rows:
        if row["datapoint_id"] not in allowed_dp_ids:
            continue
        try:
            config = WebhookBindingConfig(**_json_config(row["config"]))
        except ValidationError:
            logger.warning("WEBHOOK binding %s has an invalid configuration — skipped in listing", row["id"])
            continue
        stats = instance.stats_for(row["id"]) if instance is not None else None
        dp = registry.get(uuid.UUID(row["datapoint_id"]))
        call_path, call_path_in_path = _webhook_call_paths(prefix, config.slug, config.token)
        result.append(
            WebhookBindingEntry(
                binding_id=row["id"],
                datapoint_id=row["datapoint_id"],
                datapoint_name=dp.name if dp is not None else None,
                enabled=bool(row["enabled"]),
                slug=config.slug,
                token=config.token,
                methods=list(config.methods),
                allowed_networks=list(config.allowed_networks),
                value_source=config.value_source,
                fixed_value=config.fixed_value,
                value_param=config.value_param,
                debounce_ms=config.debounce_ms,
                autoreset=config.autoreset,
                autoreset_value=config.autoreset_value,
                autoreset_delay_ms=config.autoreset_delay_ms,
                call_path=call_path,
                call_path_token_in_path=call_path_in_path,
                call_count=stats.call_count if stats else 0,
                publish_count=stats.publish_count if stats else 0,
                last_called=stats.last_called.isoformat() if stats and stats.last_called else None,
                last_status=stats.last_status if stats else None,
                rejections=_webhook_rejections_out(stats.rejections if stats else None),
            )
        )
    return WebhookOverview(
        instance_id=str(instance_id),
        running=instance is not None,
        path_prefix=prefix,
        trust_forwarded_for=settings.trust_forwarded_for,
        rate_limit_per_minute=settings.rate_limit_per_minute,
        rejections=_webhook_rejections_out(instance.rejections if instance is not None else None),
        bindings=result,
    )


@router.post(
    "/instances/{instance_id}/webhook/bindings/{binding_id}/rotate-token",
    response_model=WebhookTokenRotationResult,
    dependencies=[Depends(contract_audit("POST", "/api/v1/adapters/instances/{instance_id}/webhook/bindings/{binding_id}/rotate-token"))],
)
async def webhook_rotate_token(
    instance_id: uuid.UUID,
    binding_id: uuid.UUID,
    request: Request = None,
    _user: Principal | str = Depends(get_current_principal),
    db: Database = Depends(lambda: get_db()),
) -> WebhookTokenRotationResult:
    """Issue a new token for one webhook binding, revoking the old one.

    Scoped to this binding on purpose: a device whose configuration leaked can
    be re-keyed without touching any other integration.  The new token is
    returned once in the response and never written to the audit log — the
    audit entry records only that the binding was rotated.
    """
    from obs.adapters.webhook.adapter import WebhookBindingConfig, generate_token
    from obs.core.registry import get_registry

    principal = _principal_from_dependency(_user)
    _ensure_webhook_secret_user(principal)
    instance_row = await _webhook_instance_row(db, instance_id)
    await _ensure_instance_write_grant(db, principal, str(instance_id))

    # The token is rewritten as part of the whole config object, exactly like a
    # binding PATCH does. Both hold the registry's external-write lock around
    # that read-modify-write, so a save that started before the rotation cannot
    # land afterwards and put the revoked token back.
    async with get_registry().external_write_lock:
        row = await db.fetchone(
            "SELECT * FROM adapter_bindings WHERE id=? AND adapter_instance_id=? AND adapter_type='WEBHOOK'",
            (str(binding_id), str(instance_id)),
        )
        if row is None:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Binding nicht gefunden")
        await _ensure_binding_mutation_scope(db, principal, uuid.UUID(row["datapoint_id"]))

        try:
            config = WebhookBindingConfig(**_json_config(row["config"]))
        except Exception as exc:
            raise HTTPException(status.HTTP_422_UNPROCESSABLE_CONTENT, f"Ungültige Binding-Config: {exc}") from exc

        rotated = config.model_copy(update={"token": generate_token()})
        await db.execute_and_commit(
            "UPDATE adapter_bindings SET config=?, updated_at=? WHERE id=?",
            (json.dumps(rotated.model_dump()), datetime.now(UTC).isoformat(), str(binding_id)),
        )
    await adapter_registry.reload_instance_bindings(str(instance_id), db)
    if request is not None:
        set_contract_audit_resource_id(request, str(binding_id))

    prefix = _webhook_path_prefix(instance_row)
    call_path, call_path_in_path = _webhook_call_paths(prefix, rotated.slug, rotated.token)
    return WebhookTokenRotationResult(
        binding_id=str(binding_id),
        slug=rotated.slug,
        token=rotated.token,
        call_path=call_path,
        call_path_token_in_path=call_path_in_path,
    )


# ---------------------------------------------------------------------------
# Typ-Routen (unverändert — Schema-Abfragen + Legacy-Config)
# ---------------------------------------------------------------------------


@router.get("/", response_model=list[AdapterStatusOut])
async def list_adapters(
    _user: str = Depends(get_current_user),
) -> list[AdapterStatusOut]:
    status_map = adapter_registry.get_status()
    return [AdapterStatusOut(adapter_type=k, **v) for k, v in status_map.items()]


@router.get("/knx/dpts")
async def list_knx_dpts(
    _user: str = Depends(get_current_user),
) -> list[dict]:
    """Alle registrierten KNX DPTs — gruppiert nach Familie (DPT1, DPT9, …)."""
    return [
        {
            "dpt_id": d.dpt_id,
            "name": d.name,
            "data_type": d.data_type,
            "unit": d.unit,
        }
        for d in sorted(DPTRegistry.all().values(), key=lambda x: x.dpt_id)
    ]


@router.get("/{adapter_type}/schema")
async def get_adapter_schema(
    adapter_type: str,
    _user: str = Depends(get_current_user),
) -> dict:
    cls = adapter_registry.get_class(adapter_type)
    if cls is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"Adapter '{adapter_type}' nicht registriert")
    schema = cls.config_schema.model_json_schema()
    schema["title"] = f"{adapter_type} Connection Config"
    return schema


@router.get("/{adapter_type}/binding-schema")
async def get_binding_schema(
    adapter_type: str,
    _user: str = Depends(get_current_user),
) -> dict:
    cls = adapter_registry.get_class(adapter_type)
    if cls is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"Adapter '{adapter_type}' nicht registriert")
    if not hasattr(cls, "binding_config_schema"):
        return {}
    schema = cls.binding_config_schema.model_json_schema()
    schema["title"] = f"{adapter_type} Binding Config"
    return schema


@router.post(
    "/{adapter_type}/test",
    response_model=TestResult,
    dependencies=[Depends(contract_audit("POST", "/api/v1/adapters/{adapter_type}/test"))],
)
async def test_adapter(
    adapter_type: str,
    body: TestRequest,
    request: Request = None,
    _user: str = Depends(get_admin_user),
) -> TestResult:
    cls = adapter_registry.get_class(adapter_type)
    if cls is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"Adapter '{adapter_type}' nicht registriert")
    try:
        cls.config_schema(**body.config)
    except ValidationError as exc:
        return _failed_test_result(
            request,
            TestResult(
                success=False,
                detail=f"Config-Validierungsfehler: {exc}",
                detail_code="configValidationError",
                detail_params={"error": str(exc)},
            ),
        )

    from obs.core.event_bus import EventBus

    dummy_bus = EventBus()
    test_instance = cls(event_bus=dummy_bus, config=body.config)
    try:
        await test_instance.connect()
        # Some adapters (e.g. MQTT) establish the connection in a background task
        # started by connect(). Poll briefly so that task gets a chance to run.
        deadline = asyncio.get_event_loop().time() + 5.0
        while not test_instance.connected and asyncio.get_event_loop().time() < deadline:
            await asyncio.sleep(0.1)
        connected = test_instance.connected
        await test_instance.disconnect()
        if connected:
            return TestResult(
                success=True,
                detail=f"Verbindung zu {adapter_type} erfolgreich",
                detail_code="connectOk",
                detail_params={"type": adapter_type},
            )
        return _failed_test_result(request, TestResult(success=False, detail="Verbindungsversuch fehlgeschlagen", detail_code="connectFailed"))
    except Exception as exc:
        logger.exception("Verbindungstest für Adapter-Typ %s fehlgeschlagen", adapter_type)
        return _failed_test_result(request, TestResult(success=False, detail=str(exc)))


@router.patch(
    "/{adapter_type}/config",
    response_model=AdapterConfigOut,
    dependencies=[Depends(contract_audit("PATCH", "/api/v1/adapters/{adapter_type}/config"))],
)
async def update_adapter_config(
    adapter_type: str,
    body: ConfigPatch,
    _user: str = Depends(get_admin_user),
    db: Database = Depends(lambda: get_db()),
) -> AdapterConfigOut:
    cls = adapter_registry.get_class(adapter_type)
    if cls is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"Adapter '{adapter_type}' nicht registriert")
    config_new = body.config
    if adapter_type == "MESSAGE":
        row = await db.fetchone("SELECT * FROM adapter_configs WHERE adapter_type=?", (adapter_type,))
        stored_config = json.loads(row["config"]) if row is not None and row["config"] else {}
        try:
            config_new = _preserve_redacted_message_config_secrets(stored_config, body.config)
            _reject_unresolved_redacted_message_config(config_new)
        except ValueError as exc:
            raise HTTPException(status.HTTP_422_UNPROCESSABLE_CONTENT, str(exc)) from exc
    try:
        cls.config_schema(**config_new)
    except Exception as exc:
        raise HTTPException(
            status.HTTP_422_UNPROCESSABLE_CONTENT,
            f"Config-Validierungsfehler: {exc}",
        ) from exc

    now = datetime.now(UTC).isoformat()
    await db.execute_and_commit(
        """INSERT INTO adapter_configs (adapter_type, config, enabled, updated_at)
           VALUES (?,?,?,?)
           ON CONFLICT(adapter_type) DO UPDATE
           SET config=excluded.config, enabled=excluded.enabled, updated_at=excluded.updated_at""",
        (adapter_type, json.dumps(config_new), int(body.enabled), now),
    )
    return AdapterConfigOut(
        adapter_type=adapter_type,
        config=_redact_instance_config(adapter_type, config_new),
        enabled=body.enabled,
        updated_at=now,
    )


@router.get("/{adapter_type}/config", response_model=AdapterConfigOut)
async def get_adapter_config(
    adapter_type: str,
    _user: str = Depends(get_current_user),
    db: Database = Depends(lambda: get_db()),
) -> AdapterConfigOut:
    row = await db.fetchone("SELECT * FROM adapter_configs WHERE adapter_type=?", (adapter_type,))
    if row is None:
        return AdapterConfigOut(adapter_type=adapter_type, config={}, enabled=True, updated_at=None)
    return AdapterConfigOut(
        adapter_type=adapter_type,
        config=_redact_instance_config(adapter_type, json.loads(row["config"])),
        enabled=bool(row["enabled"]),
        updated_at=row["updated_at"],
    )
