"""Pydantic models for Logic Engine graphs."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel

ControlClassName = Literal["room_local", "central_plant"]


class NodePosition(BaseModel):
    x: float
    y: float


class LogicNodeData(BaseModel):
    """Node-type-specific configuration stored in the node."""

    label: str = ""
    # type-specific fields — stored as arbitrary dict
    model_config = {"extra": "allow"}


class LogicNode(BaseModel):
    id: str
    type: str  # e.g. "and", "or", "datapoint_read"
    position: NodePosition
    data: dict[str, Any] = {}


class LogicEdge(BaseModel):
    id: str
    source: str
    target: str
    sourceHandle: str | None = None
    targetHandle: str | None = None


class FlowData(BaseModel):
    nodes: list[LogicNode] = []
    edges: list[LogicEdge] = []


class LogicGraphCreate(BaseModel):
    name: str
    description: str = ""
    enabled: bool = True
    flow_data: FlowData = FlowData()
    control_class: ControlClassName = "room_local"


class LogicGraphUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    enabled: bool | None = None
    flow_data: FlowData | None = None
    control_class: ControlClassName | None = None


class LogicGraphRun(BaseModel):
    """Ephemeral values used for one interactive debug execution."""

    input_overrides: dict[str, dict[str, Any]] = {}
    debug: bool = False


class LogicGraphDuplicate(BaseModel):
    """Optional override for the duplicate's name — falls back to the ``"Kopie von {name}"``
    default when omitted or blank."""

    name: str | None = None


class LogicGraphOut(BaseModel):
    id: str
    name: str
    description: str
    enabled: bool
    flow_data: FlowData
    created_at: str
    updated_at: str
    control_class: ControlClassName = "room_local"


class LogicGraphImport(BaseModel):
    """Import-Payload für einen exportierten Logic Graph."""

    obs_export: str  # muss "logic_graph" sein
    version: int
    name: str
    description: str = ""
    enabled: bool = True
    flow_data: FlowData
    control_class: ControlClassName = "room_local"


class NodeTypePort(BaseModel):
    id: str
    label: str
    type: str = "value"  # "value" | "trigger"


class NodeTypeDef(BaseModel):
    type: str  # unique identifier
    label: str  # display name
    category: str  # "logic" | "datapoint" | "timer" | "math" | "script" | "ai"
    description: str = ""
    inputs: list[NodeTypePort] = []
    outputs: list[NodeTypePort] = []
    config_schema: dict[str, Any] = {}  # JSON schema for node data
    color: str = "#475569"  # default node color (tailwind slate-600)
    has_external_side_effect: bool | None = None
    required_capability: str | None = None
    hidden_from_palette: bool = False
    legacy: bool = False
    # Heading anchor id in help/{en,de}/logic/blocks-<category>.md, resolvable at
    # runtime via GET /help/help-index.json -> .helpIds[help_id].{en,de}.
    help_id: str | None = None


class LogicRunPreflightCheck(BaseModel):
    target_type: str
    target_id: str
    node_ids: list[str] = []
    allowed: bool
    reason: str


class LogicRunPreflight(BaseModel):
    graph_id: str
    allowed: bool
    checks: list[LogicRunPreflightCheck]


class LogicUsageOut(BaseModel):
    """Describes a single usage of a DataPoint inside a logic graph."""

    graph_id: str
    graph_name: str
    graph_enabled: bool
    node_id: str
    node_type: str  # "datapoint_read" | "datapoint_write"
    direction: str  # "SOURCE" | "DEST" — from the DataPoint's perspective
