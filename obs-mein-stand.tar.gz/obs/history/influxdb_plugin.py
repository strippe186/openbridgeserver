"""InfluxDB History Plugin — Phase 5

Supports InfluxDB v1, v2, and v3.

Write uses the InfluxDB line protocol for all versions.
Query uses InfluxQL for all versions:
  v1 — basic auth (username/password) at /query?db=<database>
  v2 — Token auth, InfluxQL compat at /query?db=<bucket>
  v3 — Bearer token auth, InfluxQL compat at /query?db=<database>

Configuration keys (from app_settings):
  history.influx_url         e.g. "http://localhost:8086"
  history.influx_version     1 | 2 | 3  (default: 2)
  history.influx_token       Token/password for v2/v3
  history.influx_org         Organisation for v2 write
  history.influx_bucket      Bucket for v2 (used as db for queries too)
  history.influx_database    Database name for v1 / v3
  history.influx_username    Username for v1
  history.influx_password    Password for v1

Line protocol schema:
  obs,dp_id=<uuid> raw="<json>",quality="<q>",unit="<u>"[,v=<float>] <timestamp_ns>
"""

from __future__ import annotations

import json
import logging
import math
import time
import uuid
from datetime import UTC, datetime
from typing import Any

import httpx

from obs.core.json import json_dumps
from obs.history.base import HistoryPlugin

logger = logging.getLogger(__name__)

# Map interval strings to InfluxQL duration literals
_INFLUX_INTERVALS: dict[str, str] = {
    "1m": "1m",
    "5m": "5m",
    "15m": "15m",
    "30m": "30m",
    "1h": "1h",
    "6h": "6h",
    "12h": "12h",
    "1d": "1d",
}

_INFLUX_AGGFN: dict[str, str] = {
    "avg": "MEAN",
    "min": "MIN",
    "max": "MAX",
    "last": "LAST",
}
_WRITE_BACKOFF_INITIAL_SECONDS = 5.0
_WRITE_BACKOFF_MAX_SECONDS = 60.0


class InfluxDBHistoryPlugin(HistoryPlugin):
    """History stored in InfluxDB (v1, v2, or v3)."""

    def __init__(
        self,
        url: str,
        version: int,
        token: str,
        org: str,
        bucket: str,
        database: str,
        username: str,
        password: str,
    ) -> None:
        self._url = url.rstrip("/")
        self._version = int(version)
        self._token = token
        self._org = org
        self._bucket = bucket  # v2 write target / query db alias
        self._database = database  # v1/v3 db name
        self._username = username
        self._password = password
        self._client: httpx.AsyncClient | None = None
        self._write_backoff_until = 0.0
        self._write_backoff_seconds = _WRITE_BACKOFF_INITIAL_SECONDS
        self._write_skip_logged = False
        self.last_ping_error: str | None = None

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _write_url_params(self) -> tuple[str, dict]:
        """Return (url, query_params) for the line-protocol write endpoint."""
        if self._version == 1:
            return (
                f"{self._url}/write",
                {"db": self._database, "precision": "ns"},
            )
        if self._version == 2:
            return (
                f"{self._url}/api/v2/write",
                {"org": self._org, "bucket": self._bucket, "precision": "ns"},
            )
        # v3
        return (
            f"{self._url}/api/v3/write_lp",
            {"db": self._database, "precision": "nanosecond"},
        )

    def _query_url_params(self) -> tuple[str, dict]:
        """Return (url, base_query_params) for InfluxQL queries."""
        if self._version == 1:
            return f"{self._url}/query", {"db": self._database}
        if self._version == 2:
            # v2 InfluxQL compat: db = bucket name
            return f"{self._url}/query", {"db": self._bucket}
        # v3
        return f"{self._url}/query", {"db": self._database}

    def _headers(self, content_type: str = "application/json") -> dict:
        h: dict[str, str] = {"Accept": "application/json"}
        if content_type:
            h["Content-Type"] = content_type
        if self._version == 1:
            if self._username:
                import base64

                cred = base64.b64encode(f"{self._username}:{self._password}".encode()).decode()
                h["Authorization"] = f"Basic {cred}"
        elif self._version == 2:
            if self._token:
                h["Authorization"] = f"Token {self._token}"
        elif self._token:
            h["Authorization"] = f"Bearer {self._token}"
        return h

    def _get_write_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(timeout=10)
        return self._client

    async def disconnect(self) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    def _escape_tag(self, s: str) -> str:
        """Escape InfluxDB line-protocol tag value (no comma, space, equals)."""
        return s.replace(",", r"\,").replace(" ", r"\ ").replace("=", r"\=")

    def _escape_field_str(self, s: str) -> str:
        """Escape InfluxDB string field value (escape backslash and quote)."""
        return s.replace("\\", "\\\\").replace('"', '\\"')

    def _build_line(
        self,
        datapoint_id: uuid.UUID,
        value: Any,
        unit: str | None,
        quality: str,
        ts: datetime,
    ) -> str:
        ts_ns = int(ts.timestamp() * 1_000_000_000)

        dp_tag = self._escape_tag(str(datapoint_id))
        raw_str = self._escape_field_str(json_dumps(value))
        unit_str = self._escape_field_str(unit or "")
        quality_str = self._escape_field_str(quality)

        fields = [
            f'raw="{raw_str}"',
            f'quality="{quality_str}"',
            f'unit="{unit_str}"',
        ]
        try:
            v_float = float(value)
            if not math.isnan(v_float):
                fields.append(f"v={v_float}")
        except (TypeError, ValueError):
            pass

        return f"obs,dp_id={dp_tag} {','.join(fields)} {ts_ns}"

    def _parse_influxql_series(self, data: dict, raw_field: bool = True) -> list[dict]:
        """Parse the standard InfluxQL JSON response into our list-of-dicts format."""
        results = data.get("results", [])
        if not results:
            return []
        series = results[0].get("series", [])
        if not series:
            return []

        columns = series[0]["columns"]  # ["time", "raw"/"mean", "quality", "unit"]
        rows = series[0].get("values", [])

        col_idx = {c: i for i, c in enumerate(columns)}
        out = []
        for row in rows:
            ts = row[col_idx["time"]]
            if raw_field:
                raw = row[col_idx.get("raw", 0)] if "raw" in col_idx else None
                try:
                    v = json.loads(raw) if raw is not None else None
                except (json.JSONDecodeError, TypeError):
                    v = raw
                q = row[col_idx.get("quality", 0)] if "quality" in col_idx else ""
                u = row[col_idx.get("unit", 0)] if "unit" in col_idx else None
                out.append({"ts": ts, "v": v, "u": u or None, "q": q or ""})
            else:
                # Aggregate row: time + aggregated value
                value_columns = [c for c in columns if c not in ("time", "count")]
                val_col = value_columns[0] if value_columns else "mean"
                v = row[col_idx.get(val_col, 1)] if val_col in col_idx else None
                n = row[col_idx["count"]] if "count" in col_idx else None
                out.append({"bucket": ts, "v": v, "n": n})
        return out

    async def _run_influxql(self, q: str) -> dict:
        """Execute an InfluxQL query and return parsed JSON."""
        url, params = self._query_url_params()
        params = {**params, "q": q}
        headers = self._headers(content_type="")
        async with httpx.AsyncClient(timeout=30) as client:
            r = await client.get(url, params=params, headers=headers)
            r.raise_for_status()
            return r.json()

    # ------------------------------------------------------------------
    # HistoryPlugin interface
    # ------------------------------------------------------------------

    async def write(
        self,
        datapoint_id: uuid.UUID,
        value: Any,
        unit: str | None,
        quality: str,
        ts: datetime | None = None,
        source_adapter: str | None = None,
    ) -> None:
        ts_dt = ts or datetime.now(UTC)
        line = self._build_line(datapoint_id, value, unit, quality, ts_dt)

        url, params = self._write_url_params()
        headers = self._headers(content_type="text/plain; charset=utf-8")

        now = time.monotonic()
        if now < self._write_backoff_until:
            if not self._write_skip_logged:
                logger.warning(
                    "InfluxDB write suppressed for %.1fs after previous failure",
                    self._write_backoff_until - now,
                )
                self._write_skip_logged = True
            return

        try:
            client = self._get_write_client()
            r = await client.post(
                url,
                content=line.encode(),
                params=params,
                headers=headers,
            )
            r.raise_for_status()
            self._write_backoff_until = 0.0
            self._write_backoff_seconds = _WRITE_BACKOFF_INITIAL_SECONDS
            self._write_skip_logged = False
        except Exception:
            try:
                await self.disconnect()
            except Exception:
                logger.exception("InfluxDB disconnect after write failure also failed")
            self._write_backoff_until = time.monotonic() + self._write_backoff_seconds
            self._write_backoff_seconds = min(self._write_backoff_seconds * 2, _WRITE_BACKOFF_MAX_SECONDS)
            self._write_skip_logged = False
            logger.exception("InfluxDB write failed")
            raise

    async def query(
        self,
        datapoint_id: uuid.UUID,
        from_ts: datetime,
        to_ts: datetime,
        limit: int = 10000,
    ) -> list[dict]:
        from_rfc = _to_rfc3339(from_ts)
        to_rfc = _to_rfc3339(to_ts)
        dp = str(datapoint_id)

        q = (
            f'SELECT raw, quality, unit FROM "obs" '
            f"WHERE dp_id='{dp}' "
            f"AND time >= '{from_rfc}' AND time <= '{to_rfc}' "
            f"ORDER BY time DESC "
            f"LIMIT {limit}"
        )
        try:
            data = await self._run_influxql(q)
            return self._parse_influxql_series(data, raw_field=True)
        except Exception:
            logger.exception("InfluxDB query failed")
            return []

    async def aggregate(
        self,
        datapoint_id: uuid.UUID,
        fn: str,
        interval: str,
        from_ts: datetime,
        to_ts: datetime,
    ) -> list[dict]:
        influx_fn = _INFLUX_AGGFN.get(fn, "MEAN")
        influx_interval = _INFLUX_INTERVALS.get(interval, "1h")
        from_rfc = _to_rfc3339(from_ts)
        to_rfc = _to_rfc3339(to_ts)
        dp = str(datapoint_id)

        q = (
            f'SELECT {influx_fn}(v), COUNT(v) FROM "obs" '
            f"WHERE dp_id='{dp}' "
            f"AND time >= '{from_rfc}' AND time <= '{to_rfc}' "
            f"GROUP BY time({influx_interval}) fill(none)"
        )
        try:
            data = await self._run_influxql(q)
            return self._parse_influxql_series(data, raw_field=False)
        except Exception:
            logger.exception("InfluxDB aggregate failed")
            return []

    # ------------------------------------------------------------------
    # Connection test
    # ------------------------------------------------------------------

    async def ping(self) -> bool:
        """Return True if the InfluxDB instance is reachable and authenticated."""
        try:
            if self._version == 1:
                url = f"{self._url}/ping"
                async with httpx.AsyncClient(timeout=5) as client:
                    r = await client.get(url)
                    return r.status_code < 300
            elif self._version == 2:
                return await self._ping_v2()
            else:  # v3
                # Try a trivial InfluxQL query against the database
                data = await self._run_influxql(f'SHOW MEASUREMENTS ON "{self._database}" LIMIT 1')
                return "results" in data
        except Exception:
            logger.exception("InfluxDB ping failed")
            return False

    async def _ping_v2(self) -> bool:
        """Check reachability via /ping, then token, org and bucket via /api/v2/buckets.

        InfluxDB 2.x has no /api/v2/ping; that path answers 401/404 like any
        unknown route. On failure, ``last_ping_error`` says which step failed.
        """
        async with httpx.AsyncClient(timeout=5) as client:
            r = await client.get(f"{self._url}/ping")
            if r.status_code >= 300:
                self.last_ping_error = f"/ping returned HTTP {r.status_code}"
                return False
            r = await client.get(
                f"{self._url}/api/v2/buckets",
                params={"org": self._org, "name": self._bucket},
                headers=self._headers(content_type=""),
            )
        if r.status_code in (401, 403):
            self.last_ping_error = f"token rejected (HTTP {r.status_code})"
            return False
        if r.status_code == 404:
            self.last_ping_error = f"organization '{self._org}' not found"
            return False
        if r.status_code >= 300:
            self.last_ping_error = f"bucket lookup returned HTTP {r.status_code}"
            return False
        if not r.json().get("buckets"):
            self.last_ping_error = f"bucket '{self._bucket}' not found in organization '{self._org}'"
            return False
        return True


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _to_rfc3339(dt: datetime) -> str:
    """Convert datetime to RFC3339/ISO8601 with Z suffix."""
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    return dt.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
