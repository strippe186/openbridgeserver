"""Autobackup — /api/v1/config/autobackup/...

Täglich automatische JSON-Sicherung aller Konfigurationsdaten (Adapter, Objekte,
Logikmodul, Visu, NavLinks, AppSettings, Hierarchy, Icons).

Einstellungen werden in app_settings gespeichert:
  autobackup.enabled        = "1" | "0"
  autobackup.hour           = "0" … "23"  (Uhrzeit der täglichen Sicherung)
  autobackup.retention_days = "1" … "30"  (Anzahl Sicherungen aufbewahren)

Sicherungsdateien liegen in {db_dir}/autobackup/YYYYMMDD-HHMM[-N].json
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
from datetime import UTC, datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel

from obs.api.audit import AuditLogWriter, AuditOutcome, build_audit_context
from obs.api.auth import get_admin_user
from obs.db.database import Database, get_db

logger = logging.getLogger(__name__)

router = APIRouter(tags=["config"])

_BACKUP_STEM_RE = re.compile(r"\d{8}-\d{4}(?:-\d+)?")

# ---------------------------------------------------------------------------
# Modelle
# ---------------------------------------------------------------------------


class AutobackupConfig(BaseModel):
    enabled: bool
    hour: int  # 0–23
    retention_days: int  # 1–30


class AutobackupEntry(BaseModel):
    name: str  # z.B. "20240506-0300"
    created_at: str  # ISO-Timestamp aus dem Dateinamen
    size_bytes: int


# ---------------------------------------------------------------------------
# Hilfsfunktionen
# ---------------------------------------------------------------------------


def _autobackup_dir() -> Path:
    from obs.config import get_settings

    db_path = Path(get_settings().database.path)
    backup_dir = db_path.parent / "autobackup"
    backup_dir.mkdir(parents=True, exist_ok=True)
    return backup_dir


async def _load_config(db: Database) -> AutobackupConfig:
    rows = await db.fetchall("SELECT key, value FROM app_settings WHERE key LIKE 'autobackup.%'")
    settings = {r["key"]: r["value"] for r in rows}
    return AutobackupConfig(
        enabled=settings.get("autobackup.enabled", "0") == "1",
        hour=int(settings.get("autobackup.hour", "3")),
        retention_days=int(settings.get("autobackup.retention_days", "7")),
    )


async def _save_config(db: Database, cfg: AutobackupConfig) -> None:
    for key, value in [
        ("autobackup.enabled", "1" if cfg.enabled else "0"),
        ("autobackup.hour", str(cfg.hour)),
        ("autobackup.retention_days", str(cfg.retention_days)),
    ]:
        await db.execute_and_commit(
            "INSERT OR REPLACE INTO app_settings (key, value) VALUES (?,?)",
            (key, value),
        )


async def _application_timezone(db: Database) -> ZoneInfo:
    """Return the configured application timezone, with a safe default."""
    row = await db.fetchone("SELECT value FROM app_settings WHERE key = 'timezone'")
    try:
        return ZoneInfo(row["value"] if row else "Europe/Zurich")
    except (ZoneInfoNotFoundError, TypeError):
        return ZoneInfo("Europe/Zurich")


async def _application_now(db: Database) -> datetime:
    return datetime.now(UTC).astimezone(await _application_timezone(db))


def _list_backups() -> list[AutobackupEntry]:
    backup_dir = _autobackup_dir()
    entries: list[AutobackupEntry] = []
    # Prefer write time so suffixed backups from the same local minute appear
    # newest first.  The name provides a deterministic fallback for files
    # whose filesystem timestamps are identical.
    for f in sorted(backup_dir.glob("*.json"), key=lambda f: (f.stat().st_mtime_ns, f.stem), reverse=True):
        stem = f.stem  # z.B. "20240506-0300"
        if not _BACKUP_STEM_RE.fullmatch(stem):
            continue
        try:
            dt = datetime.strptime(stem[:13], "%Y%m%d-%H%M")  # noqa: DTZ007 -- filename encodes app-local wall-clock; no DB access here to resolve the configured tz
            created_at = dt.isoformat()
        except ValueError:
            created_at = stem
        entries.append(
            AutobackupEntry(
                name=stem,
                created_at=created_at,
                size_bytes=f.stat().st_size,
            )
        )
    return entries


def _prune_old_backups(retention_days: int) -> int:
    backup_dir = _autobackup_dir()
    # Filenames use application-local time for display and can therefore be
    # non-monotonic after a timezone change or during a repeated DST hour.
    # Retention must instead use the actual creation/write order.
    files = [f for f in backup_dir.glob("*.json") if _BACKUP_STEM_RE.fullmatch(f.stem)]
    files.sort(key=lambda f: (f.stat().st_mtime_ns, f.stem), reverse=True)
    deleted = 0
    for f in files[retention_days:]:
        deleted += _delete_backup_files(f.stem)
    return deleted


def _delete_backup_files(stem: str) -> int:
    backup_dir = _autobackup_dir()
    deleted = 0
    path = backup_dir / f"{stem}.json"
    try:
        if path.exists():
            path.unlink()
            deleted += 1
    except OSError:
        pass
    return deleted


async def _create_backup_now(db: Database) -> str:
    """Erstellt eine JSON-Sicherung und gibt den Dateinamen zurück."""
    from obs.api.v1.config import export_config

    # Export-Funktion direkt aufrufen (ohne HTTP-Request)
    export = await export_config(_user="autobackup", db=db)

    # Names shown in the UI should reflect the same application-local time as
    # the configured scheduler hour.
    ts = (await _application_now(db)).strftime("%Y%m%d-%H%M")
    backup_dir = _autobackup_dir()
    suffix = 0
    while True:
        name = ts if suffix == 0 else f"{ts}-{suffix}"
        backup_path = backup_dir / f"{name}.json"
        try:
            with backup_path.open("x", encoding="utf-8") as f:
                f.write(json.dumps(export.model_dump(), ensure_ascii=False, indent=2))
            break
        except FileExistsError:
            suffix += 1
    logger.info("Autobackup erstellt: %s (%d Bytes)", backup_path.name, backup_path.stat().st_size)
    return name


# ---------------------------------------------------------------------------
# API-Endpunkte
# ---------------------------------------------------------------------------


@router.get("/autobackup/config", response_model=AutobackupConfig)
async def get_autobackup_config(
    _admin: str = Depends(get_admin_user),
    db: Database = Depends(lambda: get_db()),
) -> AutobackupConfig:
    return await _load_config(db)


@router.put("/autobackup/config", response_model=AutobackupConfig)
async def set_autobackup_config(
    body: AutobackupConfig,
    request: Request = None,  # type: ignore[assignment]
    _admin: str = Depends(get_admin_user),
    db: Database = Depends(lambda: get_db()),
) -> AutobackupConfig:
    if not (0 <= body.hour <= 23):
        raise HTTPException(status_code=400, detail="hour muss zwischen 0 und 23 liegen.")
    if not (1 <= body.retention_days <= 30):
        raise HTTPException(status_code=400, detail="retention_days muss zwischen 1 und 30 liegen.")
    async with db.transaction():
        await _save_config(db, body)
        writer = AuditLogWriter(db, build_audit_context(request, _admin))
        await writer.write_contract("PUT", "/api/v1/config/autobackup/config", resource_id="global", commit=False)
    # Scheduler über Konfigurationsänderung informieren
    _notify_config_change()
    return body


@router.get("/autobackup/list", response_model=list[AutobackupEntry])
async def list_autobackups(
    _admin: str = Depends(get_admin_user),
) -> list[AutobackupEntry]:
    return _list_backups()


@router.post("/autobackup/run", status_code=status.HTTP_200_OK)
async def run_autobackup_now(
    request: Request = None,  # type: ignore[assignment]
    _admin: str = Depends(get_admin_user),
    db: Database = Depends(lambda: get_db()),
) -> dict:
    """Autobackup sofort manuell auslösen."""
    writer = AuditLogWriter(db, build_audit_context(request, _admin))
    try:
        name = await _create_backup_now(db)
        cfg = await _load_config(db)
        deleted = _prune_old_backups(cfg.retention_days)
    except Exception:
        await writer.write_contract("POST", "/api/v1/config/autobackup/run", outcome=AuditOutcome.FAILED)
        raise
    await writer.write_contract("POST", "/api/v1/config/autobackup/run", resource_id=name)
    return {"ok": True, "name": name, "old_backups_deleted": deleted}


@router.post("/autobackup/restore/{name}", status_code=status.HTTP_200_OK)
async def restore_autobackup(
    name: str,
    request: Request = None,  # type: ignore[assignment]
    _admin: str = Depends(get_admin_user),
    db: Database = Depends(lambda: get_db()),
) -> dict:
    """Autobackup-Sicherung wiederherstellen (Upsert-Semantik, wie JSON-Import)."""
    writer = AuditLogWriter(db, build_audit_context(request, _admin))

    async def audit_failed(resource_id: str | None = None) -> None:
        await writer.write_contract("POST", "/api/v1/config/autobackup/restore/{name}", resource_id=resource_id, outcome=AuditOutcome.FAILED)

    # Dateinamen strikt validieren (erwartetes Format: YYYYMMDD-HHMM[-N])
    safe_name = Path(name).name
    if not _BACKUP_STEM_RE.fullmatch(safe_name):
        await audit_failed()
        raise HTTPException(status_code=400, detail="Ungültiger Sicherungsname.")

    base_dir = _autobackup_dir().resolve()
    allowed_backups = {p.stem: p for p in base_dir.glob("*.json") if p.is_file() and _BACKUP_STEM_RE.fullmatch(p.stem)}
    backup_path = allowed_backups.get(safe_name)
    if backup_path is None:
        await audit_failed(safe_name)
        raise HTTPException(status_code=404, detail=f"Sicherung '{safe_name}' nicht gefunden.")

    try:
        content = json.loads(backup_path.read_text(encoding="utf-8"))
    except Exception as exc:
        await audit_failed(safe_name)
        raise HTTPException(status_code=400, detail=f"Sicherungsdatei ungültig: {exc}") from exc

    from obs.api.v1.config import ConfigExport, ImportResult, import_config

    try:
        body = ConfigExport.model_validate(content)
    except Exception as exc:
        await audit_failed(safe_name)
        raise HTTPException(status_code=400, detail=f"Sicherungsformat ungültig: {exc}") from exc

    result: ImportResult = await import_config(body=body, _user="autobackup-restore", db=db)
    outcome = AuditOutcome.FAILED if result.errors else AuditOutcome.SUCCESS
    await writer.write_contract(
        "POST",
        "/api/v1/config/autobackup/restore/{name}",
        resource_id=safe_name,
        outcome=outcome,
        details={
            "counts": {
                "datapoints": result.datapoints_created + result.datapoints_updated,
                "bindings": result.bindings_created + result.bindings_updated,
                "visu_nodes": result.visu_nodes_upserted,
            },
            "error_count": len(result.errors),
        },
    )
    return {
        "ok": True,
        "name": safe_name,
        "datapoints": result.datapoints_created + result.datapoints_updated,
        "bindings": result.bindings_created + result.bindings_updated,
        "visu_nodes": result.visu_nodes_upserted,
        "errors": result.errors,
    }


@router.delete("/autobackup/{name}", status_code=status.HTTP_200_OK)
async def delete_autobackup(
    name: str,
    request: Request = None,  # type: ignore[assignment]
    _admin: str = Depends(get_admin_user),
    db: Database = Depends(lambda: get_db()),
) -> dict:
    """Eine einzelne Autobackup-Sicherung löschen."""
    writer = AuditLogWriter(db, build_audit_context(request, _admin))

    async def audit_failed(resource_id: str | None = None) -> None:
        await writer.write_contract("DELETE", "/api/v1/config/autobackup/{name}", resource_id=resource_id, outcome=AuditOutcome.FAILED)

    safe_name = Path(name).name
    if not _BACKUP_STEM_RE.fullmatch(safe_name):
        await audit_failed()
        raise HTTPException(status_code=400, detail="Ungültiger Sicherungsname.")

    # Allowlist: nur Namen löschen, die als vorhandene Backups gelistet sind.
    existing_backups = _list_backups()
    matched = next((entry for entry in existing_backups if entry.name == safe_name), None)
    if matched is None:
        await audit_failed(safe_name)
        raise HTTPException(status_code=404, detail=f"Sicherung '{safe_name}' nicht gefunden.")

    base_dir = _autobackup_dir().resolve()
    backup_path = (base_dir / f"{matched.name}.json").resolve()
    try:
        backup_path.relative_to(base_dir)
    except ValueError:
        await audit_failed(safe_name)
        raise HTTPException(status_code=400, detail="Ungültiger Sicherungspfad.")

    if not backup_path.exists():
        await audit_failed(safe_name)
        raise HTTPException(status_code=404, detail=f"Sicherung '{safe_name}' nicht gefunden.")
    _delete_backup_files(matched.name)
    if backup_path.exists():
        await audit_failed(safe_name)
        raise HTTPException(status_code=500, detail=f"Sicherung '{safe_name}' konnte nicht gelöscht werden.")
    await writer.write_contract("DELETE", "/api/v1/config/autobackup/{name}", resource_id=safe_name)
    return {"ok": True, "name": safe_name}


# ---------------------------------------------------------------------------
# Hintergrund-Scheduler
# ---------------------------------------------------------------------------

_config_changed_event: asyncio.Event | None = None


def _notify_config_change() -> None:
    if _config_changed_event is not None:
        _config_changed_event.set()


class AutobackupScheduler:
    def __init__(self, db: Database) -> None:
        self._db = db
        self._task: asyncio.Task | None = None

    def start(self) -> None:
        global _config_changed_event
        _config_changed_event = asyncio.Event()
        self._task = asyncio.create_task(self._loop(), name="autobackup-scheduler")
        logger.info("Autobackup-Scheduler gestartet.")

    async def stop(self) -> None:
        if self._task and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        logger.info("Autobackup-Scheduler gestoppt.")

    async def _loop(self) -> None:
        last_backup_day: str | None = None

        while True:
            try:
                cfg = await _load_config(self._db)

                if not cfg.enabled:
                    # Deaktiviert: alle 5 Minuten prüfen ob Konfiguration geändert wurde
                    try:
                        await asyncio.wait_for(
                            asyncio.shield(_config_changed_event.wait()),
                            timeout=300,
                        )
                        _config_changed_event.clear()
                    except (TimeoutError, asyncio.CancelledError) as exc:
                        if isinstance(exc, asyncio.CancelledError):
                            raise
                    continue

                now = await _application_now(self._db)
                today = now.date().isoformat()

                # Prüfen ob heute schon gesichert wurde
                if last_backup_day == today and now.hour >= cfg.hour:
                    # Warten bis morgen um cfg.hour
                    tomorrow = (now + timedelta(days=1)).replace(hour=cfg.hour, minute=0, second=0, microsecond=0)

                    wait_s = max(60.0, (tomorrow - now).total_seconds())
                    logger.debug("Autobackup: nächste Sicherung in %.0fs um %s", wait_s, tomorrow.isoformat())
                    try:
                        await asyncio.wait_for(
                            asyncio.shield(_config_changed_event.wait()),
                            timeout=min(wait_s, 270),
                        )
                        _config_changed_event.clear()
                    except (TimeoutError, asyncio.CancelledError) as exc:
                        if isinstance(exc, asyncio.CancelledError):
                            raise
                    continue

                # Ist es Zeit für die Sicherung?
                if now.hour >= cfg.hour and last_backup_day != today:
                    try:
                        await _create_backup_now(self._db)
                        deleted = _prune_old_backups(cfg.retention_days)
                        last_backup_day = today
                        if deleted:
                            logger.info("Autobackup: %d alte Sicherung(en) gelöscht.", deleted)
                    except Exception:
                        logger.exception("Autobackup fehlgeschlagen")

                # Jede Minute prüfen (oder auf Konfigurationsänderung warten)
                try:
                    await asyncio.wait_for(
                        asyncio.shield(_config_changed_event.wait()),
                        timeout=60,
                    )
                    _config_changed_event.clear()
                except (TimeoutError, asyncio.CancelledError) as exc:
                    if isinstance(exc, asyncio.CancelledError):
                        raise

            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("Autobackup-Scheduler Fehler")
                await asyncio.sleep(60)


_scheduler: AutobackupScheduler | None = None


def init_autobackup_scheduler(db: Database) -> AutobackupScheduler:
    global _scheduler
    _scheduler = AutobackupScheduler(db)
    _scheduler.start()
    return _scheduler


def get_autobackup_scheduler() -> AutobackupScheduler:
    if _scheduler is None:
        raise RuntimeError("AutobackupScheduler nicht initialisiert.")
    return _scheduler
