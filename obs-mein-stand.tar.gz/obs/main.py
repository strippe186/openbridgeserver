"""open bridge server entry point — startup and graceful shutdown.

Startup-Sequenz:
  1. Database (SQLite + migrations)
  2. EventBus
  3. MQTT Client
  4. DataPoint Registry (load from DB)
  5. WebSocket Manager (register with EventBus)
  6. Write Router (MQTT dp/+/set → adapter.write)
  7. Adapters (load configs + bindings, connect all)
"""

from __future__ import annotations

import logging
import os
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded

from obs import __version__

logger = logging.getLogger(__name__)

# Mirrors uvicorn's own exit code for a failed application startup.
_STARTUP_FAILED_EXIT_CODE = 3


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None]:
    from obs.adapters import registry as adapter_registry
    from obs.api.setup import announce_setup_mode
    from obs.api.v1.websocket import init_ws_manager
    from obs.config import get_settings
    from obs.core.event_bus import DataValueEvent, init_event_bus
    from obs.core.mqtt_client import init_mqtt_client
    from obs.core.registry import init_registry
    from obs.core.write_router import init_write_router
    from obs.db.database import get_db, init_db
    from obs.history.factory import init_history_plugin

    settings = get_settings()

    configured_log_level = settings.server.log_level.upper()
    log_level = getattr(logging, configured_log_level, logging.INFO)
    logging.basicConfig(level=log_level, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")

    import asyncio

    from obs.log_buffer import LogBufferHandler

    LogBufferHandler.install(asyncio.get_event_loop(), level=log_level)
    # Runs after uvicorn configured its loggers, whichever way the server was started.
    from obs.adapters.webhook.access_log import install_webhook_access_log_filter

    install_webhook_access_log_filter()
    logger.info(f"open bridge server v{__version__} starting …")

    # 1. Database
    db = await init_db(settings.database.path)
    from obs.message_archive import init_message_archive_store

    await init_message_archive_store(settings)
    persistent_log_level = await _read_persistent_log_level(db)
    if persistent_log_level and persistent_log_level != configured_log_level:
        log_level = getattr(logging, persistent_log_level, log_level)
        logging.getLogger().setLevel(log_level)
        try:
            from obs.log_buffer import set_log_buffer_level

            set_log_buffer_level(persistent_log_level)
        except Exception:
            logger.exception("Failed to apply persistent log level")
        logger.info("Applied persistent log level from app_settings: %s", persistent_log_level)
    await announce_setup_mode(db, settings.server.port)

    # Rebuild Mosquitto passwd file from DB on every startup (keeps it in sync).
    # SIGHUP is sent after MQTT connects (see below) so Mosquitto reloads cleanly.
    from obs.core.mqtt_passwd import (
        rebuild_passwd_file,
    )
    from obs.core.mqtt_passwd import (
        reload_mosquitto as _reload_mqtt,
    )

    _m = settings.mosquitto
    await rebuild_passwd_file(db, _m.passwd_file, _m.service_username, _m.service_password)

    # 2. EventBus
    bus = init_event_bus()

    # 3. MQTT Client
    mqtt = init_mqtt_client(
        host=settings.mqtt.host,
        port=settings.mqtt.port,
        username=settings.mqtt.username,
        password=settings.mqtt.password,
    )

    # 4. DataPoint Registry
    registry = await init_registry(db, mqtt, bus)
    bus.subscribe(DataValueEvent, registry.handle_value_event)

    # 5. RingBuffer — config is persisted in app_settings (see persisted_config.py).
    # Defaults apply only when nothing has been configured via the API yet.
    await _init_persisted_ringbuffer(db, bus, settings.database.path, DataValueEvent)

    # 6. History plugin
    await init_history_plugin(db)
    from obs.history.factory import handle_value_event as history_handler

    bus.subscribe(DataValueEvent, history_handler)

    # 7. WebSocket Manager
    ws_manager = init_ws_manager()
    bus.subscribe(DataValueEvent, ws_manager.handle_value_event)

    # 7b. Visu alarms — conditions start from the current values, nothing is raised at startup
    from obs.visu_alarms import init_visu_alarm_engine, reload_visu_alarms

    alarm_engine = init_visu_alarm_engine(registry.get_value)
    await reload_visu_alarms(db)
    bus.subscribe(DataValueEvent, alarm_engine.handle_value_event)

    # 6. Write Router
    #    Path A: MQTT dp/{uuid}/set → adapters (external commands)
    #    Path B: DataValueEvent → DEST/BOTH bindings (cross-protocol propagation)
    write_router = init_write_router(db, registry, event_bus=bus)
    mqtt.on_write_request(write_router.handle)
    bus.subscribe(DataValueEvent, write_router.handle_value_event)

    # 7. MQTT connect
    await mqtt.start()
    # Reload Mosquitto after connecting so user accounts take effect immediately.
    await _reload_mqtt(_m.reload_command, _m.reload_pid)

    # 8. Adapters — import triggers @register, then start_all loads DB configs + bindings
    import obs.adapters.anwesenheit.adapter
    import obs.adapters.homeassistant.adapter
    import obs.adapters.iobroker.adapter
    import obs.adapters.knx.adapter
    import obs.adapters.message.adapter
    import obs.adapters.modbus_rtu.adapter
    import obs.adapters.modbus_tcp.adapter
    import obs.adapters.mqtt.adapter
    import obs.adapters.onewire.adapter
    import obs.adapters.snmp.adapter
    import obs.adapters.webhook.adapter
    import obs.adapters.zeitschaltuhr.adapter  # noqa: F401

    await adapter_registry.start_all(bus, db, value_getter=registry.get_value)

    # 9. Logic Engine
    from obs.logic.manager import init_logic_manager

    logic_mgr = init_logic_manager(db=db, event_bus=bus, registry=registry)
    await logic_mgr.start()

    # 10. Autobackup-Scheduler
    from obs.api.v1.autobackup import init_autobackup_scheduler

    autobackup_scheduler = init_autobackup_scheduler(db=db)

    # 11. DB-Wartung — periodischer WAL-TRUNCATE-Checkpoint (siehe issue #908)
    from obs.db.maintenance import init_db_maintenance_scheduler

    db_maintenance_scheduler = init_db_maintenance_scheduler(db=db)

    logger.info(
        "open bridge server ready — %d datapoints, %d adapters registered",
        registry.count(),
        len(adapter_registry.all_types()),
    )
    try:
        from obs.message_archive import get_message_archive_service

        await get_message_archive_service().record(
            "system",
            type="system",
            severity="info",
            source="system.startup",
            title="OBS started",
            message=f"open bridge server v{__version__} ready",
            payload={"datapoints": registry.count(), "adapters_registered": len(adapter_registry.all_types())},
        )
    except Exception:
        logger.exception("Failed to write startup event to message archive")

    yield  # ← application running

    # Shutdown (reverse order)
    await db_maintenance_scheduler.stop()
    await autobackup_scheduler.stop()
    await logic_mgr.stop()
    await adapter_registry.stop_all()
    await mqtt.stop()
    await _stop_optional_ringbuffer()
    from obs.message_archive import close_message_archive_store

    await close_message_archive_store()
    await get_db().disconnect()
    logger.info("open bridge server stopped.")


async def _init_persisted_ringbuffer(db, bus, database_path: str, data_value_event_type) -> None:
    from obs.ringbuffer.persisted_config import (
        LEGACY_DECISION_PENDING,
        LEGACY_DECISIONS_PROTECTED,
        ensure_legacy_migration_decision,
        finalize_committed_migration_decision,
        load_persisted_ringbuffer_config,
    )
    from obs.ringbuffer.ringbuffer import (
        _is_sqlite_memory_path,
        default_ringbuffer_disk_path,
        init_ringbuffer,
        reset_ringbuffer,
        set_ringbuffer_enabled,
    )

    rb_path = default_ringbuffer_disk_path(database_path)
    # storage_path an den Loader durchreichen (#951 [P3]): fehlt die Config-Zeile,
    # unterscheidet er anhand vorhandenen Ringbuffer-Storages Upgrade (10 MiB) von
    # Fresh-Install (100 MiB).
    rb_cfg = await load_persisted_ringbuffer_config(db, storage_path=rb_path)
    if not rb_cfg["enabled"]:
        reset_ringbuffer()
        set_ringbuffer_enabled(False)
        return
    set_ringbuffer_enabled(True)

    # Memory-DB-Pfade (``:memory:`` bzw. ``file:...mode=memory``) sind nicht
    # segmentierbar (Codex #951): der segmentierte Startup leitet aus dem Disk-Pfad
    # ein reales ``*_segments``-Verzeichnis ab und schriebe Manifest-/Segment-Dateien
    # auf die Platte, während das Memory-Cleanup ein No-op ist. Konsistent zur
    # API-seitigen Normalisierung (memory ⇒ nicht segmentiert) hier erzwingen.
    segmented = rb_cfg.get("segmented", False) and not _is_sqlite_memory_path(rb_path)

    # Migrations-Assistent (#964): liegt eine Legacy-Single-DB vor und wurde noch
    # nie entschieden, wird ``pending`` persistiert. Ohne informierte Entscheidung
    # (pending/skipped) bleibt das attachte Legacy-Segment retention-geschützt.
    try:
        decision = await ensure_legacy_migration_decision(db, legacy_db_path=rb_path if segmented else None)
    except Exception:
        # Die Reparatur eines mitkopierten Terminalmarkers ist best-effort. Bei
        # einem transienten app-DB-Schreibfehler konservativ wie ``pending``
        # starten: so bleibt eine attachte Legacy-Quelle im Speicher geschützt,
        # während der Status-Endpoint den Write später erneut versucht.
        logger.exception(
            "RingBuffer: Startup-Abgleich der Legacy-Entscheidung fehlgeschlagen "
            "(Server startet retention-geschützt, Retry beim nächsten Status-Poll)"
        )
        decision = LEGACY_DECISION_PENDING

    rb = await init_ringbuffer(
        storage="file",
        max_entries=rb_cfg["max_entries"],
        disk_path=rb_path,
        max_file_size_bytes=rb_cfg["max_file_size_bytes"],
        max_age=rb_cfg["max_age"],
        # Segmentierter Store (#919) — OPT-IN; Default AUS = unveränderter Legacy-Pfad.
        segmented=segmented,
        segment_max_bytes=rb_cfg.get("segment_max_bytes"),
        segment_max_rows=rb_cfg.get("segment_max_rows"),
        segment_max_age=rb_cfg.get("segment_max_age"),
        legacy_retention_protected=decision in LEGACY_DECISIONS_PROTECTED,
    )
    # Ist ein Offline-Migrations-Commit durch (Kopien promotet, Legacy detached), aber die
    # ``migrated``-Entscheidung wurde nie terminal persistiert (im Commit-Fenster unterbrochen
    # und vom Startup-Reconciler vollendet, oder eine frühere ``on_success``-Persistenz schlug
    # fehl), state-basiert nachziehen (#968, Codex :449/:326). No-op, wenn bereits terminal oder
    # noch eine Legacy-Quelle attached ist. Best-effort wie der Runtime-Config-Pfad (#968, Codex
    # :231): ein transienter app-DB-Schreibfehler (locked/voll) darf den Boot NICHT blockieren –
    # der Datenpfad ist bereits committed, der nächste ``/migration``-Poll zieht die Entscheidung
    # nach.
    try:
        await finalize_committed_migration_decision(db, rb)
    except Exception:
        logger.exception(
            "RingBuffer: Startup-Finalisierung der Migrations-Entscheidung fehlgeschlagen (Server startet, Retry beim nächsten Status-Poll)"
        )
    bus.subscribe(data_value_event_type, rb.handle_value_event)


async def _stop_optional_ringbuffer() -> None:
    from obs.ringbuffer.ringbuffer import get_optional_ringbuffer

    active_rb = get_optional_ringbuffer()
    if active_rb is not None:
        await active_rb.stop()


def create_app() -> FastAPI:
    from pathlib import Path

    from fastapi.responses import FileResponse
    from fastapi.staticfiles import StaticFiles

    from obs.api.auth import limiter as auth_limiter
    from obs.api.router import router
    from obs.config import get_settings

    settings = get_settings()

    app = FastAPI(
        title="open bridge server",
        description="Open-Source Multiprotocol Server for Building Automation",
        version=__version__,
        license_info={"name": "MIT"},
        lifespan=lifespan,
    )

    # Rate limiter state (used by @limiter.limit decorators in auth.py)
    app.state.limiter = auth_limiter
    app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

    from fastapi import Request
    from fastapi.responses import JSONResponse, RedirectResponse

    # ── WEBHOOK adapter trigger endpoint (issue #1256) ────────────────────
    # Registered *before* the CORS middleware and _setup_gate: Starlette runs the
    # last-added middleware first, so this puts the webhook gate innermost.
    #   * CORS wraps it, which means a browser caller on an allowed origin gets
    #     the allow-origin header on the trigger response and not only on the
    #     preflight (a response returned from here never reaches inner layers).
    #   * The setup gate stays the outermost middleware: an installation that
    #     has not been claimed yet must not expose any entry point, not even one
    #     guarded by a per-binding token.
    #
    # A middleware rather than a route because each WEBHOOK instance picks its
    # own path prefix at runtime; see obs/api/webhook.py for the full reasoning.
    @app.middleware("http")
    async def _webhook_gate(request: Request, call_next):
        from obs.api.webhook import handle_webhook_request

        response = await handle_webhook_request(request)
        if response is not None:
            return response
        return await call_next(request)

    # CORS — configure allowed origins via config.yaml or OBS_CORS__ORIGINS env var
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors.origins,
        allow_credentials=settings.cors.allow_credentials,
        allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
        allow_headers=["Authorization", "X-API-Key", "Content-Type", "If-Match"],
        expose_headers=["ETag"],
    )

    app.include_router(router, prefix="/api/v1")

    @app.middleware("http")
    async def _setup_gate(request: Request, call_next):
        """Reduce the whole HTTP surface to the setup page while no owner exists.

        OPTIONS passes through so the CORS layer can still answer preflights;
        the request it belongs to is blocked all the same.
        """
        from obs.api.setup import path_is_allowed_during_setup, setup_required

        if not setup_required() or request.method == "OPTIONS" or path_is_allowed_during_setup(request.url.path):
            return await call_next(request)
        if request.url.path.startswith("/api/"):
            return JSONResponse(
                {"detail": "open bridge server is not set up yet — create the first owner at /setup.", "setup_required": True},
                status_code=503,
            )
        return RedirectResponse("/setup", status_code=303)

    def _spa_index_response(index: Path) -> FileResponse:
        return FileResponse(
            str(index),
            headers={
                "Cache-Control": "no-cache, no-store, must-revalidate",
                "Pragma": "no-cache",
                "Expires": "0",
            },
        )

    # ── Serve Vue Admin-GUI (gui_dist → /) ────────────────────────────────
    # NOTE: We deliberately avoid a catch-all @app.get("/{path:path}") route
    # because it causes 405 Method Not Allowed for POST/PATCH requests to API
    # endpoints — FastAPI finds a path match (the catch-all) but no method match.
    # Instead we use a 404 exception handler that only intercepts truly unknown
    # paths and serves index.html for non-API routes (Vue Router history mode).
    _gui_dist = Path(__file__).parent.parent / "gui_dist"
    if _gui_dist.is_dir():
        _assets = _gui_dist / "assets"
        if _assets.is_dir():
            app.mount("/assets", StaticFiles(directory=_assets), name="assets")

        @app.get("/favicon.svg", include_in_schema=False)
        async def favicon():
            return FileResponse(_gui_dist / "favicon.svg")

        @app.get("/manifest.webmanifest", include_in_schema=False)
        async def admin_manifest():
            return FileResponse(_gui_dist / "manifest.webmanifest")

        @app.get("/apple-touch-icon.png", include_in_schema=False)
        async def admin_apple_touch_icon():
            return FileResponse(_gui_dist / "apple-touch-icon.png")

        @app.get("/obs_logo_light.svg", include_in_schema=False)
        async def obs_logo_light():
            return FileResponse(_gui_dist / "obs_logo_light.svg")

        @app.get("/obs_logo_dark.svg", include_in_schema=False)
        async def obs_logo_dark():
            return FileResponse(_gui_dist / "obs_logo_dark.svg")

    # ── Serve Visu SPA (frontend_dist → /visu) ────────────────────────────
    _visu_dist = Path(__file__).parent.parent / "frontend_dist"
    if _visu_dist.is_dir():
        _visu_assets = _visu_dist / "assets"
        if _visu_assets.is_dir():
            app.mount("/visu/assets", StaticFiles(directory=_visu_assets), name="visu_assets")

        @app.get("/visu/favicon.svg", include_in_schema=False)
        async def visu_favicon():
            return FileResponse(_visu_dist / "favicon.svg")

        @app.get("/visu/manifest.webmanifest", include_in_schema=False)
        async def visu_manifest():
            return FileResponse(_visu_dist / "manifest.webmanifest")

        @app.get("/visu/apple-touch-icon.png", include_in_schema=False)
        async def visu_apple_touch_icon():
            return FileResponse(_visu_dist / "apple-touch-icon.png")

        @app.get("/visu/{path:path}", include_in_schema=False)
        async def visu_spa(path: str):
            """Alle /visu/... Pfade → index.html (Vue Router history mode)."""
            index = _visu_dist / "index.html"
            if index.exists():
                return _spa_index_response(index)
            return JSONResponse({"detail": "Visu nicht gebaut"}, status_code=404)

    # ── Serve Help site (help_dist → /help) ────────────────────────────────
    # VitePress renders a static multi-page site (a real .html file per route),
    # unlike the Vue Admin-GUI/Visu SPAs — html=True lets StaticFiles resolve
    # directory requests to their index.html without the SPA fallback trick above.
    #
    # Mounted unconditionally (unlike gui_dist/frontend_dist above) via a small
    # wrapper that re-checks help_dist/'s existence on every request instead of
    # once at startup: help/ is a separate VitePress project (`cd help && npm
    # run build`), not built by any Python-side step, and there's no reliable
    # way to guarantee that build finishes before the backend starts in every
    # dev workflow (issue #1179 — a PyCharm "before launch" step for this
    # turned out not to be awaited reliably). A plain `StaticFiles(...)` would
    # either raise at construction (check_dir=True, the default) or raise on
    # its own first-request check_config() if the directory doesn't exist yet
    # — this wrapper defers that to a per-request is_dir() check instead, so
    # /help starts working the moment the directory appears on disk, before or
    # after the backend started, with no restart required.
    _help_dist = Path(__file__).parent.parent / "help_dist"

    class _LazyHelpStatic:
        def __init__(self, directory: Path) -> None:
            self._directory = directory
            self._static: StaticFiles | None = None

        async def __call__(self, scope, receive, send) -> None:
            if not self._directory.is_dir():
                response = JSONResponse({"detail": "Not found"}, status_code=404)
                await response(scope, receive, send)
                return
            if self._static is None:
                self._static = StaticFiles(directory=self._directory, html=True, check_dir=False)
            await self._static(scope, receive, send)

    @app.api_route("/help", methods=["GET", "HEAD"], include_in_schema=False)
    async def help_bare_path():
        # A bare "/help" (no trailing slash) is a distinct request from
        # "/help/..." — Starlette's Mount below redirects it to "/help/"
        # before ever reaching _LazyHelpStatic, which would mask a missing
        # help_dist/ behind a 307 instead of the same JSON 404 every other
        # /help/... path gets. Registered before the mount so this exact
        # route wins over Mount's own redirect for this one path. Must accept
        # HEAD explicitly — unlike a plain Mount, an @app.get()-only route
        # does not also answer HEAD, so an availability probe using HEAD
        # would otherwise get a bare 405 instead of following the redirect
        # (Codex review on PR #1180).
        if not _help_dist.is_dir():
            return JSONResponse({"detail": "Not found"}, status_code=404)
        return RedirectResponse(url="/help/")

    @app.api_route("/help/", methods=["GET", "HEAD"], include_in_schema=False)
    async def help_root_path():
        # The help site has no unprefixed "root" locale (every locale,
        # including German, lives under its own /help/<lang>/ prefix — see
        # help/.vitepress/config.mts) — VitePress does not build an index.html
        # at help_dist/index.html, and does not redirect the bare site root to
        # a default locale on its own. Redirect to German explicitly, mirroring
        # help_bare_path()'s guard: this exact route wins over the mount below
        # for "/help/" specifically, same reasoning as the bare "/help" route.
        if not _help_dist.is_dir():
            return JSONResponse({"detail": "Not found"}, status_code=404)
        return RedirectResponse(url="/help/de/")

    app.mount("/help", _LazyHelpStatic(_help_dist), name="help")
    if not _help_dist.is_dir():
        logger.warning(
            "help_dist/ not found at %s yet — /help returns 404 until it is built "
            "(cd help && npm run build) or the packaged app bundle is used; no restart "
            "needed once it appears.",
            _help_dist,
        )

    # ── 404-Handler für alles andere ──────────────────────────────────────
    @app.exception_handler(404)
    async def spa_404_handler(request: Request, exc):
        """Return index.html for unknown non-API, non-visu paths (Admin-GUI routing).
        Return JSON 404 for unknown /api/... paths.
        """
        if request.url.path.startswith("/api/"):
            return JSONResponse({"detail": "Not found"}, status_code=404)
        if request.url.path.startswith("/visu/"):
            # Bereits durch visu_spa abgedeckt — sollte nicht hier landen
            return JSONResponse({"detail": "Not found"}, status_code=404)
        if request.url.path == "/help" or request.url.path.startswith("/help/"):
            # _LazyHelpStatic already 404s directly (JSON) when help_dist/
            # doesn't exist at all — this handler is only reached once the
            # directory exists but StaticFiles itself can't resolve the
            # request (no matching page and no local 404.html). That's not
            # only the "no dist" case it was assumed to be: a help_dist/
            # mid-build (e.g. index.html already written, 404.html not yet)
            # hits it too, and without this guard it fell through to the
            # Admin-GUI SPA shell as a misleading 200 instead of the JSON 404
            # the help store's loadIndex() needs to know to retry (Codex
            # review on PR #1180 — this guard was previously removed here as
            # "dead code", which the partial-build case disproves).
            return JSONResponse({"detail": "Not found"}, status_code=404)
        if _gui_dist.is_dir():
            index = _gui_dist / "index.html"
            if index.exists():
                return _spa_index_response(index)
        return JSONResponse({"detail": "Not found"}, status_code=404)

    return app


async def _read_persistent_log_level(db: object) -> str | None:
    try:
        row = await db.fetchone("SELECT value FROM app_settings WHERE key='server.log_level'")
    except Exception:
        logger.exception("Could not read persisted log level — using default")
        return None
    if row is None:
        return None
    level = str(row["value"] or "").upper()
    if level in {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}:
        return level
    return None


async def main() -> None:
    from obs.config import get_settings

    settings = get_settings()
    app = create_app()

    config = uvicorn.Config(
        app,
        host=settings.server.host,
        port=settings.server.port,
        log_level=settings.server.log_level.lower(),
        loop="asyncio",
    )
    server = uvicorn.Server(config)
    try:
        await server.serve()
    except SystemExit as exc:
        # Uvicorn meldet einen fehlgeschlagenen Application-Startup per
        # sys.exit(3) *innerhalb* von serve() (uvicorn.server.Server.startup).
        await _abort_failed_startup(exc.code if isinstance(exc.code, int) else _STARTUP_FAILED_EXIT_CODE)
        return  # _abort_failed_startup() kehrt im Betrieb nicht zurueck.
    if not server.started:
        # Kein Listener, aber auch kein SystemExit — z. B. Signal waehrend des
        # Startups. Derselbe Hänger, dieselbe Behandlung.
        await _abort_failed_startup()


async def _abort_failed_startup(exit_code: int = _STARTUP_FAILED_EXIT_CODE) -> None:
    """Terminate the process when the lifespan failed instead of hanging forever.

    Uvicorn returns from ``serve()`` after a failed startup, but the interpreter
    then waits for the *non-daemon* worker threads that aiosqlite starts per
    connection (``Thread(target=_connection_worker_thread)``).  The database is
    opened before the fail-closed owner check, so a fresh install would keep a
    live-but-unserving process: ``docker ps`` shows "Up … (unhealthy)" forever,
    no restart policy fires and systemd still considers obs.service running.

    Close what startup managed to open, then leave hard — a startup that failed
    has no other resources worth unwinding, and ``os._exit`` cannot be blocked
    by a thread that never joins.
    """
    try:
        from obs.message_archive import close_message_archive_store

        await close_message_archive_store()
    except Exception:
        logger.exception("Could not close the message archive during startup abort")
    try:
        from obs.db.database import get_db

        await get_db().disconnect()
    except Exception:
        logger.exception("Could not close the database during startup abort")
    logger.error("open bridge server startup failed — exiting (see the traceback above).")
    logging.shutdown()
    os._exit(exit_code)
