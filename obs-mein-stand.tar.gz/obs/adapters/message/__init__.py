"""MESSAGE notification adapter package."""
